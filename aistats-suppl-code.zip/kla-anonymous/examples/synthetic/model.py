"""One mixer between an embedding with a constant channel and a linear readout."""
import torch
from torch import nn
from kla import build_mixer


class MemoryModel(nn.Module):
    def __init__(self, spec, config, d_model):
        super().__init__()
        if d_model < 2:
            raise ValueError('d_model must be at least 2')
        self.embed = nn.Embedding(spec.vocab, d_model - 1)
        self.layer = build_mixer(d_model, config)
        self.readout = nn.Linear(d_model, spec.topics)

    def forward(self, x):
        h = self.embed(x)
        h = torch.cat((h, torch.ones_like(h[..., :1])), dim=-1)
        return self.readout(self.layer(h))

    def freeze_memory(self):
        if self.layer.config.selective:
            raise ValueError('the frozen arm is defined only for static exact KLA')
        names = {'delta', 'lambda_log', 'sigma2_log', 'obs_noise_bias'}
        frozen = []
        for name, parameter in self.layer.named_parameters():
            if name in names or name.startswith('var_expand.'):
                parameter.requires_grad_(False)
                frozen.append('layer.' + name)
        return sorted(frozen)


def dynamics(model):
    return {name: dict(min=float(value.min()), median=float(value.median()), max=float(value.max()))
            for name, value in model.layer.dynamics_summary().items()}
