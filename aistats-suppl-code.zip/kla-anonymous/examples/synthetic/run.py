"""Train one topic-recall run; use --profile smoke for a small CPU check."""
from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass, fields
import json
import math
from pathlib import Path

import torch
from torch.nn import functional as F

from kla import KLAConfig
from examples.synthetic.data import Spec, batch
from examples.synthetic.model import MemoryModel, dynamics


@dataclass
class Run:
    profile: str = 'paper'
    model: str = 'exact'
    init: str = 'halflife'
    arm: str = 'trainable'
    seed: int = 42
    lag: int = 256
    seq_len: int | None = None
    dof: int = 4
    d_model: int = 64
    d_state: int = 32
    steps: int = 6000
    batch_size: int = 16
    lr: float = 1e-3
    eval_every: int = 100
    patience: int = 10
    n_val: int = 64
    n_test: int = 128
    dt_min: float = 1e-3
    dt_max: float = .1
    horizon_min: float = 8.0
    horizon_max: float = 8192.0
    kappa_min: float = 1.0
    kappa_max: float = 1.0
    device: str = 'cpu'
    backend: str = 'auto'

    def validate(self):
        if self.model not in ('exact', 'kalman_bucy') or self.arm not in ('frozen', 'trainable'):
            raise ValueError('invalid model or arm')
        if self.arm == 'frozen' and self.model != 'exact':
            raise ValueError('frozen is only supported for exact KLA')
        if self.init not in ('loguniform', 'halflife') or self.device not in ('cpu', 'cuda'):
            raise ValueError('invalid initialization or device')
        if self.profile not in ('smoke', 'paper'):
            raise ValueError('invalid profile')
        if any(getattr(self, name) < 1 for name in ('steps', 'batch_size', 'eval_every', 'n_val', 'n_test')):
            raise ValueError('training counts must be positive')
        if self.d_model < 2 or self.patience < 0 or not math.isfinite(self.lr) or self.lr <= 0:
            raise ValueError('invalid width, patience, or learning rate')

    def mixer_config(self):
        factory = KLAConfig.exact if self.model == 'exact' else KLAConfig.kalman_bucy
        return factory(d_state=self.d_state, expand=2, backend=self.backend,
                       use_gating=False, value_rank='conv', var_rank='auto',
                       dt_init_mode=self.init, dt_min=self.dt_min, dt_max=self.dt_max,
                       dt_init_floor=min(1e-4, self.dt_min),
                       halflife_min=self.horizon_min, halflife_max=self.horizon_max,
                       process_noise_kappa_min=self.kappa_min, process_noise_kappa_max=self.kappa_max)


def loss(prediction, target, mask):
    return F.cross_entropy(prediction[:, mask].flatten(0, 1), target[:, mask].flatten())

@torch.no_grad()
def evaluate(model, spec, cfg, split, count):
    model.eval()
    error = current_error = total = 0
    for start in range(0, count, cfg.batch_size):
        x, target, mask, current = batch(spec, split, cfg.seed, start,
                                         min(cfg.batch_size, count - start), cfg.device)
        prediction = model(x)
        y = target[:, mask]
        total += y.numel()
        error += (prediction[:, mask].argmax(-1) != y).sum().item()
        current_error += (current[:, mask] != y).sum().item()
    return dict(value=error / total, chance=1 - 1 / spec.topics,
                current_topic_oracle=current_error / total)

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def train(cfg, output):
    cfg.validate()
    spec = Spec(lag=cfg.lag, seq_len=cfg.seq_len, dof=cfg.dof)
    cfg.seq_len = spec.seq_len
    mixer = cfg.mixer_config()
    if cfg.device == 'cuda' and not torch.cuda.is_available():
        raise ValueError('CUDA requested but unavailable')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    torch.manual_seed(cfg.seed)
    model = MemoryModel(spec, mixer, cfg.d_model).to(cfg.device)
    frozen = model.freeze_memory() if cfg.arm == 'frozen' else []
    optimizer = torch.optim.Adam([p for p in model.parameters() if p.requires_grad], lr=cfg.lr)
    config = dict(run=asdict(cfg), mixer=asdict(mixer), data=asdict(spec))
    write_json(output / 'config.json', config)
    initial = dynamics(model)
    history, best_value, best_step, best_state, stale = [], math.inf, 0, None, 0
    for step in range(cfg.steps + 1):
        train_loss = None
        if step:
            model.train()
            x, target, mask, _ = batch(spec, 'train', cfg.seed, (step - 1) * cfg.batch_size,
                                        cfg.batch_size, cfg.device)
            optimizer.zero_grad(set_to_none=True)
            objective = loss(model(x), target, mask)
            if not torch.isfinite(objective):
                raise RuntimeError('nonfinite training loss')
            objective.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, error_if_nonfinite=True)
            optimizer.step()
            train_loss = float(objective.detach())
        if step % cfg.eval_every == 0 or step == cfg.steps:
            value = evaluate(model, spec, cfg, 'val', cfg.n_val)['value']
            if not math.isfinite(value):
                raise RuntimeError('nonfinite validation metric')
            row = dict(step=step, train_loss=train_loss, validation=value)
            history.append(row)
            with (output / 'history.jsonl').open('a') as stream:
                stream.write(json.dumps(row, allow_nan=False) + '\n')
            print(f'step={step} validation={value:.6f}', flush=True)
            if value < best_value:
                best_value, best_step, stale = value, step, 0
                best_state = {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}
            else:
                stale += 1
            if cfg.patience and stale >= cfg.patience:
                break
    final = dynamics(model)
    model.load_state_dict(best_state)
    test = evaluate(model, spec, cfg, 'test', cfg.n_test)
    result = dict(schema_version=1, config=config,
                  metric='error_rate',
                  best_step=best_step, best_validation=best_value, completed_steps=step,
                  test=test, frozen_parameters=frozen,
                  parameters=sum(p.numel() for p in model.parameters()),
                  dynamics=dict(initial=initial, final=final, best=dynamics(model)),
                  data={split: spec.manifest(split, cfg.seed, count) for split, count in
                        [('train', step * cfg.batch_size), ('val', cfg.n_val), ('test', cfg.n_test)]})
    torch.save(best_state, output / 'model_best.pt')
    write_json(output / 'result.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', choices=['smoke', 'paper'], default='smoke')
    parser.add_argument('--output', type=Path, required=True)
    choices = dict(model=['exact', 'kalman_bucy'],
                   init=['loguniform', 'halflife'], arm=['trainable', 'frozen'], device=['cpu', 'cuda'])
    for field in fields(Run):
        if field.name == 'profile':
            continue
        default = getattr(Run(), field.name)
        parser.add_argument('--' + field.name.replace('_', '-'),
                            type=int if field.name == 'seq_len' else type(default),
                            choices=choices.get(field.name), default=None)
    args = vars(parser.parse_args())
    output, profile = args.pop('output'), args.pop('profile')
    defaults = dict(profile=profile)
    if profile == 'smoke':
        defaults.update(lag=8, d_model=8, d_state=4, steps=20, batch_size=4,
                        n_val=8, n_test=8, eval_every=5, patience=0)
    defaults.update({key: value for key, value in args.items() if value is not None})
    train(Run(**defaults), output)


if __name__ == '__main__':
    main()
