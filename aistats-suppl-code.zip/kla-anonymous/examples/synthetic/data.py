"""Deterministic lagged-topic recall, generated on CPU."""
from dataclasses import asdict, dataclass
import hashlib
import json

import torch


@dataclass(frozen=True)
class Spec:
    lag: int = 256
    seq_len: int | None = None
    dof: int = 4
    topics: int = 8
    tokens_per_topic: int = 4
    noise: float = .5

    def __post_init__(self):
        if self.lag < 1 or not 1 <= self.dof <= self.lag:
            raise ValueError('need 1 <= dof <= lag')
        if self.seq_len is None:
            object.__setattr__(self, 'seq_len', min(4 * self.lag, 16384))
        if self.seq_len <= self.lag:
            raise ValueError('seq_len must exceed lag')
        if self.topics < 2 or self.tokens_per_topic < 1 or not 0 <= self.noise < 1:
            raise ValueError('invalid topic count, vocabulary block size, or noise')

    @property
    def vocab(self):
        return self.topics * self.tokens_per_topic

    def sample_seed(self, split, seed, index):
        if split not in ('train', 'val', 'test') or index < 0:
            raise ValueError('invalid split or sample index')
        # Keyed this way so existing per-example random streams stay fixed.
        spec = dict(lag=self.lag, seq_len=self.seq_len, dof=self.dof)
        key = dict(v=1, spec=spec, split=split, seed=seed, index=index)
        spec.update(n_regimes=self.topics, emit_per_regime=self.tokens_per_topic, emit_noise=self.noise)
        key['task'] = 'regime'
        digest = hashlib.sha256(json.dumps(key, sort_keys=True).encode()).digest()
        return int.from_bytes(digest[:8], 'big') & 0x7FFF_FFFF_FFFF_FFFF

    def manifest(self, split, seed, count):
        body = dict(generator_version=1, spec=asdict(self), split=split, seed=seed, count=count)
        body['fingerprint'] = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
        return body


def sample(spec, split, seed, index):
    """Return input and undelayed latent target; neither depends on global RNG."""
    g = torch.Generator().manual_seed(spec.sample_seed(split, seed, index))
    t = spec.seq_len
    switch = torch.rand(t, generator=g) < spec.dof / spec.lag
    switch[0] = False
    offsets = torch.randint(1, spec.topics, (t,), generator=g) * switch.long()
    z = (torch.randint(0, spec.topics, (1,), generator=g) + offsets.cumsum(0)) % spec.topics
    noisy = torch.rand(t, generator=g) < spec.noise
    own = z * spec.tokens_per_topic + torch.randint(0, spec.tokens_per_topic, (t,), generator=g)
    uniform = torch.randint(0, spec.vocab, (t,), generator=g)
    return torch.where(noisy, uniform, own), z


def batch(spec, split, seed, start, count, device='cpu'):
    if count < 1:
        raise ValueError('batch count must be positive')
    pairs = [sample(spec, split, seed, i) for i in range(start, start + count)]
    x = torch.stack([p[0] for p in pairs]).to(device)
    current = torch.stack([p[1] for p in pairs]).to(device)
    target = torch.zeros_like(current)
    target[:, spec.lag:] = current[:, :-spec.lag]
    mask = torch.arange(spec.seq_len, device=device) >= spec.lag
    return x, target, mask, current
