"""Minimal synthetic topic-recall experiments."""
