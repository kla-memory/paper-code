"""Group completed runs by configuration; optionally plot validation curves."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics


def collect(paths):
    groups = {}
    for path in sorted(set(paths)):
        result = json.loads(path.read_text())
        if result.get('metric') != 'error_rate':
            raise ValueError('expected a topic-recall error_rate result')
        config = json.loads(json.dumps(result['config']))
        seed = config['run'].pop('seed')
        key = json.dumps(config, sort_keys=True)
        group = groups.setdefault(key, dict(config=config, runs={}))
        if seed in group['runs']:
            raise ValueError('duplicate seed for the same configuration')
        history = [json.loads(line) for line in (path.parent / 'history.jsonl').read_text().splitlines()]
        group['runs'][seed] = dict(result=result, history=history)
    return groups


def summarize(paths, output, plot=False):
    groups = collect(paths)
    if not groups:
        raise ValueError('no completed result.json files found')
    if plot:
        try:
            import matplotlib
            matplotlib.use('Agg')
            from matplotlib import pyplot as plt
        except ImportError as error:
            raise ValueError('plotting needs the plot extra: uv sync --extra plot') from error
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    rows, figures = [], {}
    for key, group in sorted(groups.items()):
        cfg, runs = group['config']['run'], group['runs']
        values = [run['result']['test']['value'] for run in runs.values()]
        group_id = hashlib.sha256(key.encode()).hexdigest()[:10]
        metric = next(iter(runs.values()))['result']['metric']
        rows.append(dict(group=group_id, task='topic', model=cfg['model'], init=cfg['init'],
                         arm=cfg['arm'], lag=cfg['lag'], kappa_min=cfg['kappa_min'],
                         kappa_max=cfg['kappa_max'], seeds=' '.join(map(str, sorted(runs))),
                         n=len(values), metric=metric, test_mean=statistics.mean(values),
                         test_std=statistics.stdev(values) if len(values) > 1 else ''))
        if plot:
            figure_key = cfg['lag']
            if figure_key not in figures:
                figures[figure_key] = plt.subplots(figsize=(8, 4.5))
            fig, ax = figures[figure_key]
            curves = [{row['step']: row['validation'] for row in run['history']} for run in runs.values()]
            steps = sorted(set.intersection(*(set(curve) for curve in curves)))
            mean = [statistics.mean(curve[step] for curve in curves) for step in steps]
            label = f"{cfg['model']} / {cfg['init']} / {cfg['arm']} / {group_id} (n={len(runs)})"
            line, = ax.plot(steps, mean, label=label)
            for curve in curves:
                ax.plot(list(curve), list(curve.values()), color=line.get_color(), alpha=.2, linewidth=.7)
            ax.set(xlabel='Training step', ylabel='Validation ' + metric.replace('_', ' '),
                   title=f"Topic recall, lag {cfg['lag']} (lower is better)")
    with (output / 'summary.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    # Preserve full grouping settings without recording local input paths.
    configs = {hashlib.sha256(key.encode()).hexdigest()[:10]: value['config'] for key, value in groups.items()}
    (output / 'groups.json').write_text(json.dumps(configs, indent=2, allow_nan=False) + '\n')
    if plot:
        for lag, (fig, ax) in figures.items():
            ax.legend(fontsize=6)
            fig.tight_layout()
            fig.savefig(output / f'curves-topic-lag{lag}.png', dpi=160,
                        metadata={'Software': 'kla'})
            plt.close(fig)
    for row in rows:
        print(f"{row['group']} {row['task']} {row['model']} {row['init']} {row['arm']} "
              f"lag={row['lag']} n={row['n']} {row['metric']}={row['test_mean']:.6f}")
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results', type=Path, help='directory containing completed runs')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--plot', action='store_true')
    args = parser.parse_args()
    summarize(args.results.rglob('result.json'), args.output, args.plot)


if __name__ == '__main__':
    main()
