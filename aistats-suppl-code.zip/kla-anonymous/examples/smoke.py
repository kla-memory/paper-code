"""Run both supported mixers through forward, backward, and chunked inference."""
from __future__ import annotations

import argparse

import torch

from kla import KLAConfig, build_mixer


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', choices=('cpu', 'cuda'), default='cpu')
    parser.add_argument('--init', choices=('loguniform', 'halflife'), default='loguniform')
    args = parser.parse_args()
    torch.manual_seed(0)
    for name, factory in [('exact', KLAConfig.exact), ('kalman_bucy', KLAConfig.kalman_bucy)]:
        cfg = factory(d_state=8, expand=1, backend='auto', dt_init_mode=args.init)
        layer = build_mixer(32, cfg).to(args.device)
        x = torch.randn(2, 17, 32, device=args.device, requires_grad=True)
        y = layer(x)
        y.square().mean().backward()
        assert torch.isfinite(y).all() and torch.isfinite(x.grad).all()
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in layer.parameters())
        layer.eval()
        with torch.no_grad():
            full = layer(x)
            first, state = layer(x[:, :7], return_state=True)
            rest, state = layer(x[:, 7:], state=state)
            chunked = torch.cat((first, rest), dim=1)
            torch.testing.assert_close(full, chunked, atol=2e-5, rtol=2e-4)
        count = sum(p.numel() for p in layer.parameters())
        print(f'{name}: {tuple(y.shape)}, {count:,} parameters; forward/backward/chunking OK')


if __name__ == '__main__':
    main()
