"""The layer's fresh posterior prior matches its exact reference initializer."""

import pytest
import torch
import torch.nn.functional as F

from kla import KLAConfig, KLALayer, KLASelectiveLayer
from kla.ops import kla_step


@pytest.mark.parametrize("layer_type", [KLALayer, KLASelectiveLayer])
@pytest.mark.parametrize("r_eff", [1.0, 2.5])
@pytest.mark.parametrize("dt", [1e-8, 0.1])
def test_reference_prior_uses_stable_target_formula(layer_type, r_eff, dt):
    cfg = KLAConfig(
        d_state=3, expand=1, backend="torch", obs_noise_init="auto",
        process_noise_param="sigma2", process_noise_coupling="exact",
        process_noise_r0=r_eff,
        process_noise_kappa_min=0.25, process_noise_kappa_max=0.25,
        dt_min=dt, dt_max=dt, dt_init_floor=dt,
    )
    layer = layer_type(4, cfg)
    state = layer.init_state(2).ssm
    u = layer.lambda_log.exp() * (F.softplus(layer.delta) + 1e-7)
    expected = (1 / r_eff) / (-torch.expm1(-0.25 * u))
    torch.testing.assert_close(state.lam, expected.expand(2, -1, -1))
    assert torch.isfinite(state.lam).all()
    assert torch.count_nonzero(state.eta) == 0
    assert not state.lam.requires_grad
    # A returned state must not alias the checkpoint buffer or other batches.
    state.lam[0].zero_()
    torch.testing.assert_close(layer.init_state(1).ssm.lam[0], expected)
    torch.testing.assert_close(state.lam[1], expected)


@pytest.mark.parametrize("layer_type", [KLALayer, KLASelectiveLayer])
@pytest.mark.parametrize("param", ["sigma2"])
@pytest.mark.parametrize("disc", ["ou"])
def test_sampled_spectrum_stays_at_reference_fixed_point(layer_type, param, disc):
    cfg = KLAConfig(
        d_state=3, expand=1, backend="torch", obs_noise_init="auto",
        process_noise_param=param, process_noise_coupling="exact",
        process_noise_kappa_min=0.25, process_noise_kappa_max=4.0,
        process_noise_r0=2.5, discretization=disc, sigma2_min=0,
    )
    layer = layer_type(4, cfg)
    state = layer.init_state(2).ssm
    initial_lam = state.lam.clone()
    if layer_type is KLASelectiveLayer:
        a, q = layer._compute_aq(torch.randn(2, 1, 4))
        a, q = a[:, 0], q[:, 0]
    else:
        a, q = layer._compute_aq()
    # Constant reference information phi = k^2 * Lambda_v, cellwise.
    k = torch.full((2, 3), 3 ** -0.5)
    lv = torch.full((2, 4), 3 / 2.5)
    for _ in range(5):
        _, _, state = kla_step(torch.randn(2, 4), lv, k, k, a, q, state)
        torch.testing.assert_close(state.lam, initial_lam, rtol=2e-6, atol=0)


@pytest.mark.parametrize("layer_type", [KLALayer, KLASelectiveLayer])
@pytest.mark.parametrize("checkpoint", [False, True])
def test_fresh_forward_and_carried_state_use_same_prior(layer_type, checkpoint):
    layer = layer_type(4, KLAConfig(
        d_state=3, expand=1, backend="torch", obs_noise_init="auto",
        process_noise_param="sigma2", checkpoint_ssm=checkpoint,
    ))
    x = torch.randn(2, 7, 4)
    full, full_state = layer(x, return_state=True)
    explicit, _ = layer(x, state=layer.init_state(2))
    first, state = layer(x[:, :3], return_state=True)
    rest, state = layer(x[:, 3:], state=state)
    torch.testing.assert_close(full, explicit)
    torch.testing.assert_close(full, torch.cat([first, rest], dim=1))
    torch.testing.assert_close(full_state.ssm.lam, state.ssm.lam)
    torch.testing.assert_close(full_state.ssm.eta, state.ssm.eta)
    full.sum().backward()
    assert all(p.grad is None or torch.isfinite(p.grad).all() for p in layer.parameters())


@pytest.mark.parametrize("layer_type", [KLALayer, KLASelectiveLayer])
def test_reference_prior_survives_checkpoint_and_parameter_updates(layer_type):
    cfg = KLAConfig(d_state=3, obs_noise_init="auto", process_noise_kappa_max=4)
    layer = layer_type(4, cfg)
    reference = layer.init_state(1).ssm.lam.clone()
    with torch.no_grad():
        layer.delta.add_(1)
        layer.lambda_log.add_(0.5)
    restored = layer_type(4, cfg)
    restored.load_state_dict(layer.state_dict())
    torch.testing.assert_close(restored.init_state(1).ssm.lam, reference)


@pytest.mark.parametrize("kwargs", [
    {"process_noise_coupling": "none"},
    {"process_noise_coupling": "heuristic"},
    {"process_noise_mode": "zero"},
])
def test_nonexact_regimes_are_rejected(kwargs):
    with pytest.raises(ValueError, match="not supported"):
        KLAConfig(d_state=3, obs_noise_init="auto", **kwargs)
