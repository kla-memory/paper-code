"""Public contract for the two supported models."""
import dataclasses
import json

import pytest
import torch

from kla import KLAConfig, KLALayer, KLASelectiveLayer, build_mixer


@pytest.mark.parametrize("factory,layer_type", [
    (KLAConfig.exact, KLALayer), (KLAConfig.kalman_bucy, KLASelectiveLayer),
])
@pytest.mark.parametrize("init", ["loguniform", "halflife"])
@pytest.mark.parametrize("kappa", [(1.0, 1.0), (0.05, 0.3)])
def test_supported_models_initialize_and_backpropagate(factory, layer_type, init, kappa):
    cfg = factory(d_state=4, expand=1.0, backend="torch", dt_init_mode=init,
                  halflife_min=4.0, halflife_max=4096.0,
                  process_noise_kappa_min=kappa[0], process_noise_kappa_max=kappa[1])
    # Public configs must remain serializable, including explicit fixed settings.
    cfg = KLAConfig(**json.loads(json.dumps(dataclasses.asdict(cfg))))
    layer = build_mixer(8, cfg)
    assert type(layer) is layer_type
    assert layer.initial_precision is not None
    assert layer.sigma2_log.requires_grad
    assert layer.sigma2_floor.item() == 0.0
    if isinstance(layer, KLASelectiveLayer):
        assert not hasattr(layer, "sel_up_p")
        assert torch.count_nonzero(layer.sel_up_a.weight) == 0
        assert torch.count_nonzero(layer.sel_up_a.bias) == 0
    summary = layer.dynamics_summary()
    assert summary["kappa"].min() >= kappa[0] * 0.98
    assert summary["kappa"].max() <= kappa[1] * 1.02
    if init == "halflife":
        assert summary["half_life"].min() >= 4.0 * 0.98
        assert summary["half_life"].max() <= 4096.0 * 1.02
    x = torch.randn(2, 7, 8, requires_grad=True)
    y = layer(x)
    assert y.shape == x.shape and torch.isfinite(y).all()
    y.square().mean().backward()
    assert x.grad is not None and torch.isfinite(x.grad).all()
    assert layer.sigma2_log.grad is not None and torch.isfinite(layer.sigma2_log.grad).all()


@pytest.mark.parametrize("init", ["loguniform", "halflife"])
def test_zero_clock_preserves_static_model(init):
    kw = dict(d_state=4, expand=1.0, backend="torch", dt_init_mode=init,
              process_noise_kappa_min=0.05, process_noise_kappa_max=0.3)
    static = build_mixer(8, KLAConfig.exact(**kw))
    clock = build_mixer(8, KLAConfig.kalman_bucy(**kw))
    static.load_state_dict({k: v for k, v in clock.state_dict().items() if k in static.state_dict()})
    x = torch.randn(2, 11, 8)
    y_static, state_static = static(x, return_state=True)
    y_clock, state_clock = clock(x, return_state=True)
    torch.testing.assert_close(y_static, y_clock, atol=2e-5, rtol=2e-5)
    torch.testing.assert_close(state_static.ssm.lam, state_clock.ssm.lam)
    torch.testing.assert_close(state_static.ssm.eta, state_clock.ssm.eta, atol=2e-5, rtol=2e-5)


@pytest.mark.parametrize("field,value", [
    ("process_noise_coupling", "none"), ("process_noise_coupling", "heuristic"),
    ("process_noise_coupling", "auto"), ("process_noise_init", "heuristic"),
    ("process_noise_init", 0.1), ("process_noise_min", 0.001),
    ("process_noise_max", 0.1), ("process_noise_kappa_tie_p", 0.01),
    ("process_noise_param", "raw"), ("process_noise_param", "log"),
    ("process_noise_mode", "zero"), ("process_noise_mode", "fixed"),
    ("reference_prior", False), ("process_noise_cp", 2.0),
    ("sigma2_min", 0.01), ("sigma2_max", 1.0),
    ("decay_a_init_mode", "hippo"), ("discretization", "zoh"),
    ("clock_p_gain", True), ("clock_full_warp", False),
    ("selective_static", "static_ap_dmodel"),
    ("scale_mode", "mamba_clock"), ("scale_mode", "bounded_log"),
    ("scale_mode", "exp"), ("scale_mode", "additive_residual"),
    ("scale_bound_p", 3.0), ("selective_residual_init", "kaiming"),
])
@pytest.mark.parametrize("factory", [KLAConfig.exact, KLAConfig.kalman_bucy])
def test_unsupported_variants_are_rejected(factory, field, value):
    with pytest.raises((ValueError, TypeError), match=field):
        factory(**{field: value})


@pytest.mark.parametrize("layer_type", [KLALayer, KLASelectiveLayer])
def test_direct_construction_revalidates_mutated_config(layer_type):
    cfg = KLAConfig(backend="torch")
    cfg.clock_p_gain = True
    with pytest.raises(ValueError, match="clock_p_gain"):
        layer_type(8, cfg)


@pytest.mark.parametrize("kwargs,field", [
    ({"process_noise_kappa_min": 0}, "kappa"),
    ({"process_noise_kappa_max": float("inf")}, "kappa"),
    ({"dt_min": 1e-5}, "dt_init_floor"),
    ({"dt_min": 0.2}, "dt_max"),
    ({"dt_init_mode": "halflife", "halflife_min": 0}, "halflife"),
    ({"dt_init_mode": "halflife", "halflife_max": float("inf")}, "halflife"),
    ({"dt_init_mode": "halflife", "dt_init_per_cell": False}, "dt_init_per_cell"),
])
def test_invalid_initialization_ranges_fail_early(kwargs, field):
    with pytest.raises(ValueError, match=field):
        KLAConfig(**kwargs)


def test_halflife_ignores_timestep_range_and_floor():
    cfg = KLAConfig.exact(dt_init_mode="halflife", dt_min=1e-8,
                          dt_max=1e-9, dt_init_floor=1.0, backend="torch", d_state=4)
    layer = build_mixer(8, cfg)
    assert torch.isfinite(layer.initial_precision).all()


def test_default_is_explicit_exact_and_none_floor_alias_remains_supported():
    assert KLAConfig() == KLAConfig.exact()
    assert KLAConfig().process_noise_coupling == "exact"
    layer = build_mixer(8, KLAConfig(sigma2_min=None, backend="torch", d_state=4))
    assert layer.sigma2_floor.item() == 0.0
