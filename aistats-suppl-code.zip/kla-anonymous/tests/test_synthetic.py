"""Synthetic data semantics, isolation, frozen parameters, and saved-run validity."""
from dataclasses import replace
import json

import pytest
import torch

from examples.synthetic.data import Spec, batch, sample
from examples.synthetic.model import MemoryModel
from examples.synthetic.run import Run, evaluate, loss, train
from examples.synthetic.summarize import collect, summarize


def test_deterministic_data_and_split_isolation():
    spec = Spec(lag=8)
    first = batch(spec, 'train', 42, 0, 3)
    torch.manual_seed(77)
    second = batch(spec, 'train', 42, 0, 3)
    assert all(torch.equal(a, b) for a, b in zip(first, second))
    assert torch.equal(first[0][1], sample(spec, 'train', 42, 1)[0])
    assert not torch.equal(first[0], batch(spec, 'test', 42, 0, 3)[0])
    assert len({spec.sample_seed(s, 42, i) for s in ('train', 'val', 'test') for i in range(10)}) == 30
    x, target, mask, current = first
    assert mask.sum() == spec.seq_len - spec.lag
    assert not mask[:spec.lag].any()
    assert torch.equal(target[:, spec.lag:], current[:, :-spec.lag])


def test_topic_semantics():
    spec = Spec(lag=4, dof=4, noise=0)
    tokens, latent = sample(spec, 'train', 42, 0)
    assert torch.equal(tokens // spec.tokens_per_topic, latent)
    assert (latent[1:] != latent[:-1]).all()
    assert 0 <= tokens.min() and tokens.max() < spec.vocab


def test_loss_ignores_unscored_prefix():
    spec = Spec(lag=8)
    _, target, mask, _ = batch(spec, 'train', 42, 0, 2)
    pred = torch.randn(2, spec.seq_len, spec.topics, requires_grad=True)
    value = loss(pred, target, mask)
    value.backward()
    assert torch.count_nonzero(pred.grad[:, :spec.lag]) == 0
    assert torch.count_nonzero(pred.grad[:, spec.lag:]) > 0


def test_frozen_arm_preserves_memory_but_trains_readout():
    spec = Spec(lag=8)
    cfg = Run(d_model=8, d_state=4)
    model = MemoryModel(spec, cfg.mixer_config(), cfg.d_model)
    frozen = model.freeze_memory()
    before = {name: p.clone() for name, p in model.named_parameters()}
    assert {'layer.delta', 'layer.lambda_log', 'layer.sigma2_log', 'layer.obs_noise_bias',
            'layer.var_expand.weight'} <= set(frozen)
    opt = torch.optim.Adam([p for p in model.parameters() if p.requires_grad], lr=.01)
    x, y, mask, _ = batch(spec, 'train', 42, 0, 2)
    loss(model(x), y, mask).backward()
    opt.step()
    for name, p in model.named_parameters():
        if name in frozen:
            assert p.grad is None and torch.equal(before[name], p)
    assert not torch.equal(before['readout.weight'], model.readout.weight)


@pytest.mark.parametrize('model_name', ['exact', 'kalman_bucy'])
def test_run_checkpoint_selection_and_evaluation(tmp_path, model_name):
    cfg = Run(profile='smoke', model=model_name, lag=8, d_model=8, d_state=4,
              steps=3, batch_size=2, eval_every=1, n_val=3, n_test=3, patience=0)
    output = tmp_path / 'run'
    result = train(cfg, output)
    history = [json.loads(row) for row in (output / 'history.jsonl').read_text().splitlines()]
    assert result['best_validation'] == min(row['validation'] for row in history)
    assert result['best_step'] == min(history, key=lambda row: row['validation'])['step']
    spec = Spec(**result['config']['data'])
    restored = MemoryModel(spec, cfg.mixer_config(), cfg.d_model)
    restored.load_state_dict(torch.load(output / 'model_best.pt', weights_only=True))
    assert evaluate(restored, spec, cfg, 'test', cfg.n_test) == result['test']
    # Metric aggregation must not weight a short final batch like a full batch.
    single_batch = evaluate(restored, spec, replace(cfg, batch_size=3), 'test', cfg.n_test)
    assert single_batch['value'] == pytest.approx(result['test']['value'], abs=2e-6)
    encoded = (output / 'result.json').read_text()
    assert str(tmp_path) not in encoded and 'hostname' not in encoded
    with pytest.raises(FileExistsError):
        train(cfg, output)


def test_summary_separates_models_and_rejects_duplicate_seeds(tmp_path):
    paths = []
    for seed, model, value in [(42, 'exact', .5), (43, 'exact', .3), (42, 'kalman_bucy', .7)]:
        folder = tmp_path / f'{model}-{seed}'
        folder.mkdir()
        config = {'run': vars(Run(model=model, seed=seed)), 'data': {}, 'mixer': {}}
        (folder / 'result.json').write_text(json.dumps(dict(config=config,
            metric='error_rate', test={'value': value})))
        (folder / 'history.jsonl').write_text(json.dumps(dict(step=0, validation=value)) + '\n')
        paths.append(folder / 'result.json')
    rows = summarize(paths, tmp_path / 'summary')
    exact = next(row for row in rows if row['model'] == 'exact')
    assert exact['n'] == 2 and exact['test_mean'] == pytest.approx(.4)
    duplicate = tmp_path / 'duplicate'
    duplicate.mkdir()
    (duplicate / 'result.json').write_bytes(paths[0].read_bytes())
    (duplicate / 'history.jsonl').write_bytes((paths[0].parent / 'history.jsonl').read_bytes())
    with pytest.raises(ValueError, match='duplicate seed'):
        collect([*paths, duplicate / 'result.json'])


def test_rejects_invalid_protocol():
    with pytest.raises(ValueError, match='seq_len'):
        Spec(lag=8, seq_len=8)
    with pytest.raises(ValueError, match='frozen'):
        Run(model='kalman_bucy', arm='frozen').validate()


def test_summary_rejects_other_metrics(tmp_path):
    path = tmp_path / 'result.json'
    path.write_text(json.dumps({'metric': 'unsupported'}))
    with pytest.raises(ValueError, match='topic-recall'):
        collect([path])
