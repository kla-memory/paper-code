"""Exact horizon initialization, reference precision, and dynamics diagnostics."""
from __future__ import annotations

import math

import pytest
import torch

from kla import KLAConfig
from kla.layers.kla_layer import KLALayer

D_MODEL, S = 32, 8
M = 2 * D_MODEL
LN2 = math.log(2.0)


def _cfg(**kw):
    base = dict(d_state=S, backend="torch", decay_a_init_mode="unit",
                process_noise_coupling="exact", obs_noise_init="auto")
    base.update(kw)
    return KLAConfig(**base)


def _u(layer):
    delta = torch.nn.functional.softplus(layer.delta.float()) + 1e-7
    return layer.lambda_log.float().exp() * delta


# ------------------------------------------------------------ halflife init

def test_halflife_realises_the_prescribed_horizon_constant_kappa():
    torch.manual_seed(0)
    lay = KLALayer(D_MODEL, _cfg(dt_init_mode="halflife", halflife_min=8.0, halflife_max=8192.0,
                                 process_noise_kappa_min=1.0, process_noise_kappa_max=1.0))
    d = lay.dynamics_summary()
    torch.testing.assert_close(d["kappa"], torch.ones(M, S), rtol=1e-3, atol=1e-3)
    H = d["half_life"]
    assert H.min() >= 8.0 * 0.99 and H.max() <= 8192.0 * 1.01
    assert H.unique().numel() == M * S                     # one draw per cell
    # log-uniform: median near the geometric mean of the range
    assert 150 < H.median().item() < 700
    torch.testing.assert_close(H, LN2 / (2.0 * _u(lay)), rtol=1e-3, atol=0)


def test_halflife_with_kappa_spread_shares_one_kappa_across_delta_p_and_prior():
    torch.manual_seed(0)
    lay = KLALayer(D_MODEL, _cfg(dt_init_mode="halflife", halflife_min=16.0, halflife_max=1024.0,
                                 process_noise_kappa_min=0.3, process_noise_kappa_max=3.0))
    d = lay.dynamics_summary()
    kappa, u = d["kappa"], d["u"]
    assert kappa.min() >= 0.3 * 0.98 and kappa.max() <= 3.0 * 1.02
    assert kappa.std() > 0.3                               # a real spread
    H = LN2 / ((1.0 + kappa) * u)                          # from p's kappa and Delta's u ...
    assert H.min() >= 16.0 * 0.98 and H.max() <= 1024.0 * 1.02   # ... lands in the H range only if they agree
    # the reference prior was built from the same kappa: phi0 / (1 - exp(-kappa u))
    expected = 1.0 / (-torch.expm1(-kappa * u))
    torch.testing.assert_close(lay.initial_precision.float(), expected, rtol=2e-3, atol=0)
    assert getattr(lay, "_init_kappa", None) is None       # transient, cleared after reset


def test_halflife_ignores_the_dt_ladder_and_floor():
    torch.manual_seed(0)
    lay = KLALayer(D_MODEL, _cfg(dt_init_mode="halflife", halflife_min=4096.0, halflife_max=65536.0,
                                 process_noise_kappa_min=1.0, process_noise_kappa_max=1.0,
                                 dt_min=1e-3, dt_init_floor=1e-4))
    delta = torch.nn.functional.softplus(lay.delta.float())
    assert delta.max() < 1e-4                               # far below dt_min and the floor


def test_halflife_trains_end_to_end():
    torch.manual_seed(0)
    lay = KLALayer(D_MODEL, _cfg(dt_init_mode="halflife"))
    y = lay(torch.randn(2, 16, D_MODEL))
    y = y[0] if isinstance(y, tuple) else y
    y.pow(2).mean().backward()
    assert torch.isfinite(lay.delta.grad).all() and torch.isfinite(lay.sigma2_log.grad).all()


# --------------------------------------------------------- dynamics_summary

@pytest.mark.parametrize("kappa", [0.1, 1.0, 3.0])
def test_summary_recovers_configured_kappa_on_exact_init(kappa):
    torch.manual_seed(0)
    lay = KLALayer(D_MODEL, _cfg(process_noise_kappa_min=kappa, process_noise_kappa_max=kappa,
                                 dt_min=1e-4, dt_max=1e-1))
    d = lay.dynamics_summary()
    assert set(d) == {"u", "a_bar", "p_bar", "gain", "kappa", "half_life", "precision"}
    assert all(v.shape == (M, S) for v in d.values())
    torch.testing.assert_close(d["kappa"], torch.full((M, S), kappa), rtol=2e-3, atol=0)
    torch.testing.assert_close(d["half_life"], LN2 / ((1 + kappa) * d["u"]), rtol=1e-4, atol=0)
    torch.testing.assert_close(d["gain"], -torch.expm1(-kappa * d["u"]), rtol=2e-3, atol=0)
    torch.testing.assert_close(d["precision"], lay.initial_precision.float(), rtol=2e-3, atol=0)


def test_summary_phi0_argument_moves_the_operating_point():
    torch.manual_seed(0)
    lay = KLALayer(D_MODEL, _cfg())
    k1 = lay.dynamics_summary(phi0=1.0)["kappa"]
    k4 = lay.dynamics_summary(phi0=4.0)["kappa"]
    assert (k4 > k1).all()                                  # a sharper sensor overwrites more


def test_halflife_layer_builds_on_the_meta_device():
    """Meta construction and materialization must produce a valid filter bank."""
    cfg = _cfg(dt_init_mode="halflife", halflife_min=4.0, halflife_max=4096.0)
    with torch.device("meta"):
        lay = KLALayer(D_MODEL, cfg)
    assert lay.delta.is_meta
    lay = lay.to_empty(device="cpu")
    torch.manual_seed(0)
    lay.reset_parameters()
    h = lay.dynamics_summary()["half_life"]
    assert torch.isfinite(h).all() and 3.9 < h.min() < 8 and 2000 < h.max() <= 4100
