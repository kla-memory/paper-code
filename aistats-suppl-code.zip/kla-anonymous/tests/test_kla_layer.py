"""Flag-space and statefulness tests for the unified KLALayer."""


import math

import pytest
import torch

from kla import KLAConfig, KLALayer, build_mixer


def _decode_parity(layer: KLALayer, x: torch.Tensor) -> float:
    layer.eval()
    with torch.no_grad():
        full = layer(x)
        full = full[0] if isinstance(full, tuple) else full
        state = layer.init_state(x.shape[0], device=x.device)
        outs = []
        for t in range(x.shape[1]):
            out, state = layer(x[:, t : t + 1], state=state)
            out = out[0] if isinstance(out, tuple) else out
            outs.append(out)
        inc = torch.cat(outs, dim=1)
    return (full - inc).abs().max().item()


@pytest.mark.parametrize("factory", [KLAConfig.exact, KLAConfig.kalman_bucy])
def test_core_models_train_and_decode(device, factory):
    cfg = factory(d_state=4)
    layer = build_mixer(32, cfg).to(device)
    x = torch.randn(2, 16, 32, device=device)
    y = layer(x)
    assert y.shape == x.shape and torch.isfinite(y).all()
    y.sum().backward()
    assert all(p.grad is None or torch.isfinite(p.grad).all() for p in layer.parameters())
    assert _decode_parity(layer, x) < 1e-4


@pytest.mark.parametrize(
    "kwargs",
    [
        dict(use_conv=False),
        dict(use_gating=False),
        dict(use_lambda_skip=False),
        dict(lambda_skip_mode="vector"),
        dict(qk_norm=False),
        dict(obs_noise_init=1.0),
        dict(obs_noise_init=1.0, var_rank="full"),
        dict(obs_noise_init=0.5, value_rank="conv", var_rank="auto"),
        dict(process_noise_kappa_min=0.03, process_noise_kappa_max=3.0),
        dict(process_noise_r0=2.0),
        dict(obs_var_max=10.0),
        dict(decode_from_prior=True),
        dict(checkpoint_ssm=True),
        dict(scan_impl="doubling"),
        dict(scan_impl="sequential"),
        dict(expand=1.5),
        dict(bias=True),
    ],
)
def test_flag_space(device, kwargs):
    layer = KLALayer(32, KLAConfig(d_state=4, **kwargs)).to(device)
    x = torch.randn(2, 12, 32, device=device)
    y = layer(x)
    y = y[0] if isinstance(y, tuple) else y
    y.sum().backward()
    assert torch.isfinite(y).all()
    assert _decode_parity(layer, x) < 1e-4


def test_return_variance(device):
    layer = KLALayer(32, KLAConfig(d_state=4, return_variance=True)).to(device)
    x = torch.randn(2, 12, 32, device=device)
    y, y_var = layer(x)
    assert y.shape == y_var.shape == x.shape
    assert (y_var >= 0).all()


def test_chunked_prefill_matches_full(device):
    layer = KLALayer(32, KLAConfig(d_state=4)).to(device).eval()
    x = torch.randn(2, 24, 32, device=device)
    with torch.no_grad():
        full = layer(x)
        state = layer.init_state(2, device=device)
        y1, state = layer(x[:, :10], state=state)
        y2, state = layer(x[:, 10:], state=state)
    torch.testing.assert_close(torch.cat([y1, y2], 1), full, atol=1e-4, rtol=1e-4)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
def test_bf16_autocast():
    layer = KLALayer(64, KLAConfig(d_state=8)).cuda()
    x = torch.randn(2, 32, 64, device="cuda")
    with torch.autocast("cuda", dtype=torch.bfloat16):
        y = layer(x)
    assert torch.isfinite(y).all()
    y.float().sum().backward()


# ---------------------------------------------------------------------------
# obs_noise_init: the silent observation-noise head
# ---------------------------------------------------------------------------

def _sigma_v_at_init(layer, x):
    z = layer.in_proj(x)
    if layer.config.use_gating:
        z, _ = z.chunk(2, dim=-1)
    if layer.conv is not None:
        z, _ = layer.conv(z, None)
    _, lambda_v, _, _ = layer._project_sensors(z)
    return 1.0 / lambda_v


@pytest.mark.parametrize("kwargs", [
    dict(value_rank="conv", var_rank="auto"),   # low-rank observation head
    dict(var_rank="full"),                    # no separate out projection
])
def test_obs_noise_init_pins_sigma_v_for_every_token(kwargs):
    """With the head silenced, sigma_v == r0 exactly, per token and channel.

    Exactly, not in expectation: softplus is convex, so a random head's mean
    variance sits above its median softplus(0). Zeroing the output weight is what
    removes that gap -- the bias alone sets the value, whatever z is.
    """
    r0 = 1.0
    layer = KLALayer(64, KLAConfig(d_state=8, obs_noise_init=r0, **kwargs))
    torch.manual_seed(0)
    sig = _sigma_v_at_init(layer, torch.randn(2, 32, 64) * 3.0)   # loud input
    assert torch.allclose(sig, torch.full_like(sig, r0), atol=1e-6, rtol=0)


def test_obs_noise_init_off_adds_no_tensor():
    """Checkpoints trained without the knob must keep loading: no new key.
    obs_noise_init="auto" is now the default, so "off" has to be explicit."""
    layer = KLALayer(64, KLAConfig(d_state=8, obs_noise_init=None))
    assert layer.obs_noise_bias is None
    assert not any("obs_noise" in k for k in layer.state_dict())
    # ...and a random head is genuinely token-dependent (the thing the knob removes)
    sig = _sigma_v_at_init(layer, torch.randn(2, 32, 64))
    assert sig.std() > 1e-3


def test_obs_noise_init_branch_can_wake_up():
    """Silent, not dead: the zeroed output weight still receives gradient."""
    layer = KLALayer(64, KLAConfig(d_state=8, obs_noise_init=1.0, value_rank="conv", var_rank="auto"))
    layer(torch.randn(2, 32, 64)).square().sum().backward()
    assert layer.var_expand.weight.grad.abs().max() > 0
    assert layer.obs_noise_bias.grad is not None


def _tiny_sequence_model(mixer_cfg):
    from kla.configs import ModelConfig
    from kla.models.sequence_model import SequenceModel
    return SequenceModel(ModelConfig(vocab_size=64, d_model=32, n_layers=1), mixer=mixer_cfg)


def test_obs_noise_init_survives_the_model_init_walk():
    """SequenceModel re-inits every unflagged Linear with normal(0.02); the
    silenced weight is flagged _no_reinit so r0 holds inside a full model."""
    from kla.models.sequence_model import SequenceModel
    cfg = KLAConfig(d_state=8, obs_noise_init=1.0, value_rank="conv", var_rank="auto")
    model = _tiny_sequence_model(cfg)
    layers = [m for m in model.modules() if isinstance(m, KLALayer)]
    assert layers, "no KLALayer found in the model"
    sig = _sigma_v_at_init(layers[0], torch.randn(2, 16, layers[0].in_proj.in_features))
    assert torch.allclose(sig, torch.full_like(sig, 1.0), atol=1e-6, rtol=0)


@pytest.mark.parametrize("bad", [1e-5, 0.0, -1.0])
def test_obs_noise_init_below_the_floor_is_refused(bad):
    with pytest.raises(ValueError, match="obs_noise_init"):
        KLALayer(64, KLAConfig(d_state=8, obs_noise_init=bad))


def test_obs_noise_init_auto_is_one_over_d_state():
    layer = KLALayer(64, KLAConfig(d_state=8, obs_noise_init="auto"))
    sig = _sigma_v_at_init(layer, torch.randn(2, 32, 64))
    assert torch.allclose(sig, torch.full_like(sig, 1 / 8), atol=1e-7, rtol=0)


# ---------------------------------------------------------------------------
# process_noise_coupling: p tied to each cell's own leak u = |a| Delta
# ---------------------------------------------------------------------------

def _coupled_layer(**kw):
    # Avoid cancellation near unit decay in the float32 DARE round trip.
    kw.setdefault("dt_min", 1e-3)
    cfg = KLAConfig(d_state=8, process_noise_param="sigma2", obs_noise_init="auto", **kw)
    torch.manual_seed(0)
    layer = KLALayer(64, cfg)
    a, p = layer._continuous_params()
    u = a.abs() * (torch.nn.functional.softplus(layer.delta.float()) + 1e-7)
    return layer, u, p


def test_kappa_spectrum_spans_the_band_per_cell():
    layer, _, _ = _coupled_layer(process_noise_kappa_min=0.03, process_noise_kappa_max=3.0)
    kappa = layer.dynamics_summary()["kappa"]
    assert kappa.min() >= 0.03 * .999 and kappa.max() <= 3.0 * 1.001
    assert kappa.max() / kappa.min() > 90
    assert kappa.log().std() > .5


def test_decay_starts_at_unit_magnitude():
    layer = KLALayer(64, KLAConfig(d_state=8, backend="torch", decay_a_init_mode="unit"))
    torch.testing.assert_close(layer.lambda_log, torch.zeros_like(layer.lambda_log))


def test_delta_draw_per_cell_by_default_and_per_channel_on_request():
    """``dt_init_per_cell=True`` (default) gives every (channel,
    state) cell its own Delta; ``False`` shares one draw across a channel's
    states. Unit decay then gives one initial decay rate per channel."""
    M, S = 128, 8
    torch.manual_seed(0)
    per_cell = KLALayer(64, KLAConfig(d_state=S, backend="torch"))
    d = torch.nn.functional.softplus(per_cell.delta.float())
    assert d.unique().numel() == M * S                # every cell its own draw
    assert (d.std(dim=-1) > 0).all()                  # distinct per-state draws on either ladder
    torch.manual_seed(0)
    per_channel = KLALayer(64, KLAConfig(d_state=S, backend="torch", dt_init_per_cell=False))
    d = torch.nn.functional.softplus(per_channel.delta.float())
    assert (d.std(dim=-1) < 1e-6).all()               # constant across S, per channel
    assert d[:, 0].unique().numel() == M              # one draw per channel
    for lay in (per_cell, per_channel):               # both inside the configured range
        d = torch.nn.functional.softplus(lay.delta.float())
        assert d.min() >= lay.config.dt_min * 0.999 and d.max() <= lay.config.dt_max * 1.001


def test_kappa_min_equals_max_is_the_constant_case():
    """No separate 'mode': a constant is the range collapsed to a point. The
    explicit range (0.3 .. 3.0) is a real spread, not a constant."""
    from kla.layers.common import kappa_init

    default = kappa_init((4, 8), KLAConfig(d_state=8, process_noise_kappa_min=0.3, process_noise_kappa_max=3.0))
    assert default.min() >= 0.3 * (1 - 1e-5) and default.max() <= 3.0 * (1 + 1e-5)
    assert default.max() / default.min() > 2                    # a spread, not one value
    same = kappa_init((4, 8), KLAConfig(d_state=8, process_noise_kappa_min=2.5,
                                        process_noise_kappa_max=2.5))
    torch.testing.assert_close(same, torch.full((4, 8), 2.5))
    balanced = kappa_init((4, 8), KLAConfig(d_state=8, process_noise_kappa_min=1.0,
                                            process_noise_kappa_max=1.0))
    torch.testing.assert_close(balanced, torch.ones(4, 8))


@pytest.mark.parametrize("kwargs,match", [
    (dict(process_noise_kappa_min=0.0, process_noise_kappa_max=1.0), "process_noise_kappa_min"),
    (dict(process_noise_kappa_min=-1.0, process_noise_kappa_max=1.0), "process_noise_kappa_min"),
    (dict(process_noise_kappa_min=2.0, process_noise_kappa_max=1.0), "process_noise_kappa_min"),
])
def test_kappa_range_is_validated(kwargs, match):
    from kla.layers.common import kappa_init

    with pytest.raises(ValueError, match=match):
        kappa_init((4, 8), KLAConfig(d_state=8, **kwargs))


def _dare_gain(a_bar, p_bar, r):
    """Closed-form scalar DARE fixed point: s = abar^2 s r/(s+r) + p_bar, K = s/(s+r)."""
    b = r * (1 - a_bar ** 2) - p_bar
    s = (-b + torch.sqrt(b * b + 4 * p_bar * r)) / 2
    return s / (s + r)


@pytest.mark.parametrize("kappa", [0.03, 1.0, 3.0])
def test_exact_coupling_recovers_kappa_at_the_dare_fixed_point(kappa):
    """Prediction 4: solve the DARE per cell on the layer's own (abar, pbar) and
    the recovered role -log(1-K)/u must equal the target kappa at every u --
    including the dt_max = 0.3 rungs."""
    layer, u, _ = _coupled_layer(process_noise_coupling="exact",
                                 process_noise_kappa_min=kappa, process_noise_kappa_max=kappa,
                                 dt_max=0.3)
    a_bar, p_bar = layer._compute_aq()
    K = _dare_gain(a_bar.double(), p_bar.double(), r=1.0)   # r_eff = 1 in the r0 = 1/S gauge
    kappa_hat = -torch.log1p(-K) / u.double()
    assert torch.allclose(kappa_hat, torch.full_like(kappa_hat, kappa), rtol=1e-4, atol=0)


def test_p_exact_init_is_overflow_safe_and_matches_the_exponential_form():
    """Eq. 4.8's sinh product overflows float32 for large u even when the answer fits
    (u=100, kappa=0.01 -> 1.72; u=60, kappa=1 -> 1.14e26); the expm1 form must not."""
    from kla.layers.common import p_exact_init

    def ref(u, k):                           # float64 Eq. 4.5: (1-e^-c)(e^c - e^-2u)
        u, k = u.double(), k.double()
        return (1 - torch.exp(-k * u)) * (torch.exp(k * u) - torch.exp(-2 * u))

    u = torch.tensor([100.0, 60.0, 1e-6, 1e-3, 0.1, 1.0, 10.0, 300.0, 5.0, 1e-4])
    k = torch.tensor([0.01, 1.0, 0.03, 3.0, 1.0, 1.0, 3.0, 0.01, 10.0, 0.001])
    uu, kk = torch.meshgrid(u, k, indexing="ij")
    uu, kk = uu.flatten(), kk.flatten()
    got, want = p_exact_init(uu, kk).double(), ref(uu, kk)
    fits = want < torch.finfo(torch.float32).max * 0.5
    assert torch.isfinite(got[fits]).all(), "overflowed although the answer fits float32"
    torch.testing.assert_close(got[fits], want[fits], rtol=2e-5, atol=0.0)
    for u_, k_, expect in ((100.0, 0.01, 1.71828), (60.0, 1.0, 1.1420e26)):
        out = p_exact_init(torch.tensor([u_]), torch.tensor([k_])).item()
        assert abs(out / expect - 1) < 1e-4, (u_, k_, out)
    # phi0 scales it as 1/phi0
    torch.testing.assert_close(p_exact_init(u[:4], k[:4], phi0=4.0), p_exact_init(u[:4], k[:4]) / 4)


@pytest.mark.parametrize("head", [dict(value_rank="conv", var_rank="auto"), dict(var_rank="full")])
@pytest.mark.parametrize("r0", ["auto", 0.5])
def test_obs_noise_init_pins_sigma_v_with_projection_biases(head, r0):
    """bias=True: the head's own bias must not add to obs_noise_bias. Before it was zeroed,
    sigma_v ranged 0.216-0.310 (full) and 0.124-0.552 (low rank) around a 0.25 target."""
    from kla.models.sequence_model import SequenceModel

    layer = KLALayer(64, KLAConfig(d_state=4, obs_noise_init=r0, bias=True, **head))
    want = 1 / 4 if r0 == "auto" else r0
    x = torch.randn(2, 32, 64)
    sig = _sigma_v_at_init(layer, x)
    assert torch.allclose(sig, torch.full_like(sig, want), atol=1e-6, rtol=0)
    # ...and it survives the model-level init walk, which re-inits every unflagged Linear.
    layer.apply(lambda m: SequenceModel._init_weights(None, m))
    sig = _sigma_v_at_init(layer, x)
    assert torch.allclose(sig, torch.full_like(sig, want), atol=1e-6, rtol=0)
