"""Forward/backward parity against the sequential reference for shipped backends."""

import copy
import dataclasses
import math
import textwrap

import pytest
import torch

from kla.configs import KLAConfig
from kla.layers.kla_layer import KLALayer
from kla.ops import KLAState, init_state, kla_scan, kla_scan_reference

# Input order accepted by every backend, used to label gradient comparisons.
INPUT_NAMES = ("v", "lambda_v", "k", "q", "a", "p")


@dataclasses.dataclass(frozen=True)
class Profile:
    """Per-backend accuracy contract."""

    name: str
    fwd_atol: float
    fwd_rtol: float
    exact_grads: tuple[str, ...]
    """Inputs whose gradient the backend computes exactly (tight threshold)."""
    exact_grad_tol: float = 2e-3
    returns_state: bool = True
    supports_initial_state: bool = True


PROFILES = {
    "torch": Profile("torch", 2e-4, 1e-4, exact_grads=INPUT_NAMES),
    **{name: Profile(name, 1e-4, 1e-4, exact_grads=INPUT_NAMES,
                     exact_grad_tol=2e-3, supports_initial_state=False)
       for name in ("cuda", "cuda_static", "cuda_static_fast")},
}
ALL_BACKENDS = list(PROFILES)


def make_inputs(device, B=2, L=64, M=16, S=8, requires_grad=False):
    """Well-conditioned inputs: lambda_v and p strictly positive, a inside (0, 1)."""
    g = torch.Generator(device="cpu").manual_seed(0)

    def to(t):
        return t.to(device).requires_grad_(requires_grad)

    return (
        to(torch.randn(B, L, M, generator=g)),  # v
        to(torch.rand(B, L, M, generator=g) + 0.5),  # lambda_v (Λ^v > 0)
        to(torch.randn(B, L, S, generator=g) * 0.3),  # k
        to(torch.randn(B, L, S, generator=g) * 0.3),  # q
        to(torch.rand(M, S, generator=g) * 0.5 + 0.4),  # a
        to(torch.rand(M, S, generator=g) * 0.05 + 0.01),  # p
    )


def run_backend(backend, inputs, **kwargs):
    """Run a supported backend; only absent CUDA devices are skipped."""
    return kla_scan(*inputs, backend=backend, **kwargs)


def rel_err(got, ref):
    """Max abs deviation normalized by the reference's own scale.

    Gradients of the static ``a``/``p`` accumulate over batch x time, so their
    absolute magnitude says nothing on its own — normalizing by ``ref`` keeps one
    threshold meaningful across all six inputs.
    """
    return ((got - ref).abs().max() / (ref.abs().max() + 1.0)).item()


def device_for(backend):
    """torch is the CPU baseline; the kernel backends require a GPU."""
    if backend == "torch":
        return "cpu"
    if not torch.cuda.is_available():
        pytest.skip(f"backend {backend!r} needs CUDA")
    return "cuda"


def report(title, rows, why=None):
    """Print per-input error measurements; run pytest with -s to display them."""
    width = max((len(r[0]) for r in rows), default=0)
    print(f"\n  {title}")
    for label, value, note in rows:
        print(f"    {label:<{width}}  {value:>10.3e}   {note}")
    if why:
        print(textwrap.indent(textwrap.fill(" ".join(why.split()), 88), "    | "))


# --------------------------------------------------------------------- forward


@pytest.mark.parametrize("backend", ALL_BACKENDS)
def test_forward_matches_reference(backend):
    """y and y_var from each backend must match the sequential reference."""
    prof = PROFILES[backend]
    device = device_for(backend)
    inputs = make_inputs(device)

    y, y_var, _ = run_backend(backend, inputs)
    y_ref, y_var_ref, _ = kla_scan_reference(*inputs)

    d_y = (y - y_ref).abs().max().item()
    d_var = (y_var - y_var_ref).abs().max().item()
    report(
        f"{backend}: forward deviation vs the sequential reference",
        [
            ("max|dy|", d_y, f"atol {prof.fwd_atol:g}"),
            ("max|dy_var|", d_var, f"rtol {prof.fwd_rtol:g}"),
        ],
        why=f"""
        PASS means agreement to {max(d_y, d_var):.1e} between two *different*
        algorithms, not two runs of one: the reference is a sequential python loop over
        kla_step, while {backend} is a parallel associative scan
        ({'in log space' if backend == 'torch' else 'in linear space, trace-normalized'}).
        Only the algebra is shared, so agreement at float32 noise level says the
        parallel form is genuinely equivalent rather than merely self-consistent.
        """,
    )

    torch.testing.assert_close(y, y_ref, atol=prof.fwd_atol, rtol=prof.fwd_rtol)
    torch.testing.assert_close(y_var, y_var_ref, atol=prof.fwd_atol, rtol=prof.fwd_rtol)
    assert (y_var >= 0).all(), "read-out variance must be non-negative"


@pytest.mark.parametrize("backend", ALL_BACKENDS)
def test_final_state_matches_reference(backend):
    """The carried (lambda, eta) state must match, for backends that return it."""
    prof = PROFILES[backend]
    device = device_for(backend)
    inputs = make_inputs(device)

    _, _, state = run_backend(backend, inputs)
    if not prof.returns_state:
        assert state is None, f"{backend} documents state=None (older kernel)"
        return

    _, _, ref = kla_scan_reference(*inputs)
    torch.testing.assert_close(state.lam, ref.lam, atol=1e-3, rtol=1e-4)
    torch.testing.assert_close(state.eta, ref.eta, atol=1e-3, rtol=1e-4)


@pytest.mark.parametrize("backend", ALL_BACKENDS)
def test_chunked_state_carry(backend):
    """Splitting the sequence and threading state must equal one full scan."""
    prof = PROFILES[backend]
    device = device_for(backend)
    v, lambda_v, k, q, a, p = make_inputs(device)
    if not prof.supports_initial_state:
        pytest.skip(f"{backend} does not accept a carried initial state")

    y_full, _, _ = run_backend(backend, (v, lambda_v, k, q, a, p))
    mid = v.shape[1] // 2
    head = (v[:, :mid], lambda_v[:, :mid], k[:, :mid], q[:, :mid], a, p)
    tail = (v[:, mid:], lambda_v[:, mid:], k[:, mid:], q[:, mid:], a, p)

    y1, _, state = run_backend(backend, head)
    y2, _, _ = run_backend(backend, tail, initial_state=state)

    torch.testing.assert_close(
        torch.cat([y1, y2], 1), y_full, atol=prof.fwd_atol, rtol=prof.fwd_rtol
    )


# -------------------------------------------------------------------- backward


@pytest.mark.parametrize("backend", ALL_BACKENDS)
def test_backward_matches_reference(backend):
    """All six scan-input gradients match the sequential reference."""
    prof = PROFILES[backend]
    inputs = make_inputs(device_for(backend), requires_grad=True)
    refs = tuple(t.detach().clone().requires_grad_(True) for t in inputs)
    y, y_var, _ = run_backend(backend, inputs)
    yr, vr, _ = kla_scan_reference(*refs)
    (y.square().sum() + y_var.sum()).backward()
    (yr.square().sum() + vr.sum()).backward()
    errors = {}
    for name, got, ref in zip(INPUT_NAMES, inputs, refs):
        assert got.grad is not None and torch.isfinite(got.grad).all(), name
        errors[name] = rel_err(got.grad, ref.grad)
    report(f"{backend}: gradient error", [(name, err, f"budget {prof.exact_grad_tol}")
                                          for name, err in errors.items()])
    assert all(error < prof.exact_grad_tol for error in errors.values()), errors


@pytest.mark.parametrize("backend", ALL_BACKENDS)
def test_gradient_descent_reduces_loss(backend):
    """Ten projected Adam steps must reduce loss through the scan.

    This low-level test optimizes discrete inputs directly, so it projects
    precision, process variance, and decay back onto their valid domains.
    Layers instead enforce these constraints through their parameterization.
    """
    device = device_for(backend)
    inputs = make_inputs(device, requires_grad=True)
    _, lambda_v, _, _, a, p = inputs
    target = torch.randn(2, 64, 16, device=device)

    opt = torch.optim.Adam(inputs, lr=1e-2)
    losses = []
    for _ in range(10):
        opt.zero_grad()
        y, _, _ = kla_scan(*inputs, backend=backend)
        loss = (y - target).pow(2).mean()
        loss.backward()
        opt.step()
        with torch.no_grad():  # project back onto the valid domain
            lambda_v.clamp_(min=1e-3)
            p.clamp_(min=1e-6)
            a.clamp_(min=1e-3, max=0.999)
        losses.append(loss.item())

    assert all(math.isfinite(x) for x in losses), f"{backend}: non-finite loss: {losses}"
    assert losses[-1] < losses[0], f"{backend}: loss did not decrease: {losses}"


@pytest.mark.parametrize("bad_p", [0.0, -0.05])
@pytest.mark.parametrize("backend", ALL_BACKENDS)
def test_non_positive_process_noise_stays_finite(backend, bad_p):
    """The low-level scan floors non-positive noise inputs to stay finite.

    These are scan-API edge cases; the retained layers learn positive sigma2.
    """
    device = device_for(backend)
    v, lambda_v, k, q, a, p = make_inputs(device)
    p = torch.full_like(p, bad_p)

    y, y_var, _ = run_backend(backend, (v, lambda_v, k, q, a, p))
    assert torch.isfinite(y).all(), f"{backend}: non-finite y at p={bad_p}"
    assert torch.isfinite(y_var).all(), f"{backend}: non-finite y_var at p={bad_p}"


@pytest.mark.parametrize("backend", ALL_BACKENDS)
def test_near_zero_decay_stays_finite(backend):
    """Almost-complete forgetting must not overflow the precision recurrence."""
    v, lambda_v, k, q, a, p = make_inputs(device_for(backend))
    a = torch.full_like(a, 1e-10)
    y, y_var, _ = run_backend(backend, (v, lambda_v, k, q, a, p))
    assert torch.isfinite(y).all(), f"{backend}: non-finite y at a=1e-10"
    assert torch.isfinite(y_var).all(), f"{backend}: non-finite variance at a=1e-10"


@pytest.mark.parametrize("backend", ALL_BACKENDS)
def test_high_information_tokens_are_not_clipped(backend):
    """Large observation precision must retain the reference mean and variance."""
    v, lambda_v, k, q, a, p = make_inputs(device_for(backend))
    lambda_v = lambda_v * 1e4
    phi_max = (lambda_v.unsqueeze(-1) * k.square().unsqueeze(-2)).max().item()
    assert phi_max > 1e3
    y, var, _ = run_backend(backend, (v, lambda_v, k, q, a, p))
    yr, vr, _ = kla_scan_reference(v, lambda_v, k, q, a, p)
    assert rel_err(y, yr) < 5e-3
    assert rel_err(var, vr) < 5e-3


# Layer-level gradients for both timestep recipes and a nonconstant kappa bank.
P_ARMS = {
    "exact": {},
    "halflife": dict(dt_init_mode="halflife"),
    "kappa_spread": dict(process_noise_kappa_min=.05, process_noise_kappa_max=.3),
}
KERNEL_BACKENDS = [b for b in ALL_BACKENDS if b != "torch"]


def rel_l2(got, ref):
    """||got - ref|| / ||ref||: scale-invariant comparison of parameter gradients."""
    return ((got - ref).norm() / ref.norm().clamp_min(1e-30)).item()


def make_layer_pair(backend, arm, device, d_model=32, seed=0):
    """(torch-reference layer, backend layer) with identical weights and inputs."""
    torch.manual_seed(seed)
    cfg = KLAConfig(d_state=8, backend="torch", return_variance=True, **P_ARMS[arm])
    ref = KLALayer(d_model, cfg).to(device)
    got = copy.deepcopy(ref)
    got.config = dataclasses.replace(cfg, backend=backend)
    x = torch.randn(2, 64, d_model, device=device, generator=torch.Generator(device).manual_seed(seed))
    return ref, got, x


def layer_grad_errors(backend, arm, device):
    """-> {param name: rel_l2 of the backend's gradient vs the torch reference}."""
    ref, got, x = make_layer_pair(backend, arm, device)
    x_ref = x.clone().requires_grad_(True)
    x_got = x.clone().requires_grad_(True)

    out_ref, var_ref = ref(x_ref)
    out_got, var_got = got(x_got)

    # Forward must agree before the gradients mean anything.
    torch.testing.assert_close(out_got, out_ref, atol=1e-3, rtol=1e-3)
    torch.testing.assert_close(var_got, var_ref, atol=1e-3, rtol=1e-3)

    # Square the mean to keep the read-out path in the loss, sum the variance to
    # keep the precision path in it -- same recipe as the op-level test.
    (out_ref.square().sum() + var_ref.sum()).backward()
    (out_got.square().sum() + var_got.sum()).backward()

    errs = {"x": rel_l2(x_got.grad, x_ref.grad)}
    for (name, p_ref), (_, p_got) in zip(ref.named_parameters(), got.named_parameters()):
        assert p_got.grad is not None, f"{backend}/{arm}: no gradient reached {name}"
        assert torch.isfinite(p_got.grad).all(), f"{backend}/{arm}: non-finite d{name}"
        errs[name] = rel_l2(p_got.grad, p_ref.grad)
    return errs


@pytest.mark.parametrize("backend", KERNEL_BACKENDS)
@pytest.mark.parametrize("arm", list(P_ARMS))
def test_layer_parameter_gradients_match_reference(backend, arm):
    errors = layer_grad_errors(backend, arm, device_for(backend))
    assert "sigma2_log" in errors
    budget = PROFILES[backend].exact_grad_tol
    for name, error in errors.items():
        assert error < budget, f"{backend}/{arm}: d{name} error {error} >= {budget}"


def test_jit_cxx_standard_follows_torch_version(monkeypatch):
    """torch >= 2.13 extension headers need C++20; older builds keep C++17."""
    import torch

    from kla.ops import cuda_backend

    for version, expected in (("2.10.0+cu126", "c++17"), ("2.13.0+cu126", "c++20"),
                              ("2.13.0a0+git1234", "c++20"), ("3.0.0", "c++20")):
        monkeypatch.setattr(torch, "__version__", version)
        assert cuda_backend._cxx_std() == expected, version
        flags = cuda_backend._nvcc_flags("static_fast")
        assert f"-std={expected}" in flags and sum(f.startswith("-std=") for f in flags) == 1
