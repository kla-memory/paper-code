"""Learned stationary variance: OU mapping, limiting behavior, and gradients."""
import math

import pytest
import torch
import torch.nn.functional as F

from kla import KLAConfig, build_mixer


@pytest.fixture(params=[KLAConfig.exact, KLAConfig.kalman_bucy], ids=['exact', 'kalman_bucy'])
def layer(request):
    return build_mixer(16, request.param(d_state=8, backend='torch', return_variance=True))


def dynamics(layer):
    return layer._compute_aq(torch.zeros(1, 1, layer.d_inner)) if layer.config.selective else layer._compute_aq()


def test_sigma2_matches_continuous_ou_solution(layer):
    # Vary learned decay and variance away from initialization, then compare
    # against the continuous OU solution evaluated in float64.
    with torch.no_grad():
        layer.lambda_log.normal_(0, .5)
        layer.sigma2_log.normal_(-4, .5)
    a_bar, p_bar = dynamics(layer)
    delta = (F.softplus(layer.delta.float()) + 1e-7).double()
    rate, noise = layer._continuous_params()
    u = delta * rate.double()
    expected_a = u.exp()
    expected_p = noise.double() * torch.expm1(2 * u) / (2 * rate.double())
    torch.testing.assert_close(a_bar.double(), expected_a.expand_as(a_bar), rtol=1e-6, atol=1e-8)
    torch.testing.assert_close(p_bar.double(), expected_p.expand_as(p_bar), rtol=1e-6, atol=1e-10)


def test_small_sigma2_keeps_positive_noise_and_nonzero_gradient(layer):
    with torch.no_grad():
        layer.lambda_log.copy_(torch.linspace(-4, 2, layer.d_inner)[:, None].expand_as(layer.lambda_log))
        layer.sigma2_log.fill_(-40)
    _, noise = dynamics(layer)
    assert (noise > 0).all()
    noise.sum().backward()
    assert torch.isfinite(layer.sigma2_log.grad).all()
    assert (layer.sigma2_log.grad > 0).all()
    assert layer.sigma2_floor.item() == 0


def test_long_memory_sends_process_variance_to_zero(layer):
    with torch.no_grad():
        layer.sigma2_log.fill_(math.log(.01))
        layer.lambda_log.fill_(-30)
    a_bar, p_bar = dynamics(layer)
    torch.testing.assert_close(a_bar, torch.ones_like(a_bar))
    assert torch.isfinite(p_bar).all() and (p_bar >= 0).all()
    assert p_bar.max().item() < 1e-10
    torch.testing.assert_close(layer._sigma2(), torch.full_like(layer.sigma2_log, .01))


def test_state_dict_key_and_end_to_end_gradients(layer):
    keys = layer.state_dict().keys()
    assert 'sigma2_log' in keys and 'p_log' not in keys and 'process_noise' not in keys
    y, var = layer(torch.randn(2, 32, 16))
    (y.square().mean() + var.mean()).backward()
    for parameter in (layer.sigma2_log, layer.lambda_log, layer.delta):
        assert parameter.grad is not None and torch.isfinite(parameter.grad).all()


@pytest.mark.parametrize('legacy_name', ['p_log', 'process_noise'])
def test_legacy_noise_checkpoint_cannot_be_silently_reinterpreted(layer, legacy_name):
    state = layer.state_dict()
    state[legacy_name] = state.pop('sigma2_log')
    with pytest.raises(RuntimeError, match='sigma2_log'):
        layer.load_state_dict(state)
