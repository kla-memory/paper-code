"""Regression coverage for the retained Kalman–Bucy implementation."""
import copy

import pytest
import torch

from kla import KLAConfig, build_mixer


def clock_layer(**kwargs):
    layer = build_mixer(8, KLAConfig.kalman_bucy(
        d_state=4, expand=1, backend='torch', dt_init_mode='halflife',
        process_noise_kappa_min=.05, process_noise_kappa_max=.3, **kwargs))
    with torch.no_grad():
        layer.sel_up_a.weight.normal_(0, .2)
        layer.sel_up_a.bias.normal_(0, .2)
    return layer


@pytest.mark.parametrize('checkpoint', [False, True])
def test_active_clock_chunking_and_checkpoint_backward(checkpoint):
    torch.manual_seed(91)
    layer = clock_layer(checkpoint_ssm=checkpoint)
    reference = copy.deepcopy(layer)
    reference.config.checkpoint_ssm = False
    x = torch.randn(2, 17, 8, requires_grad=True)
    xr = x.detach().clone().requires_grad_()
    y, state = layer(x, return_state=True)
    yr, sr = reference(xr, return_state=True)
    first, carried = layer(x[:, :6], return_state=True)
    rest, carried = layer(x[:, 6:], state=carried)
    torch.testing.assert_close(y, torch.cat((first, rest), dim=1))
    torch.testing.assert_close(state.ssm.lam, carried.ssm.lam)
    torch.testing.assert_close(state.ssm.eta, carried.ssm.eta)
    torch.testing.assert_close(y, yr)
    y.square().mean().backward()
    yr.square().mean().backward()
    torch.testing.assert_close(x.grad, xr.grad)
    for p, pr in zip(layer.parameters(), reference.parameters()):
        if pr.grad is not None:
            torch.testing.assert_close(p.grad, pr.grad)
    assert torch.count_nonzero(layer.sel_up_a.weight.grad)


@pytest.mark.parametrize('factory', [KLAConfig.exact, KLAConfig.kalman_bucy])
def test_meta_reset_and_checkpoint_roundtrip(factory):
    cfg = factory(d_state=4, expand=1, backend='torch', dt_init_mode='halflife')
    with torch.device('meta'):
        layer = build_mixer(8, cfg)
    layer.to_empty(device='cpu')
    layer.reset_parameters()
    restored = build_mixer(8, cfg)
    restored.load_state_dict(layer.state_dict())
    x = torch.randn(2, 5, 8)
    assert torch.isfinite(layer(x)).all()
    torch.testing.assert_close(layer(x), restored(x))


def test_old_clock_checkpoint_retains_active_bottleneck():
    layer = clock_layer()
    old = layer.state_dict()
    old['sel_down.weight'] = torch.cat((old['sel_down.weight'], torch.randn_like(old['sel_down.weight'])))
    restored = clock_layer()
    restored.load_state_dict(old)
    x = torch.randn(2, 9, 8)
    torch.testing.assert_close(layer(x), restored(x))
    old['sel_up_p.weight'] = torch.zeros_like(old['sel_up_a.weight'])
    with pytest.raises(RuntimeError, match='noise controller'):
        restored.load_state_dict(old, strict=False)


def test_nonzero_variance_floor_checkpoint_rejected():
    layer = clock_layer()
    checkpoint = layer.state_dict()
    checkpoint['sigma2_floor'] = torch.tensor(.1)
    with pytest.raises(RuntimeError, match='zero sigma2_floor'):
        layer.load_state_dict(checkpoint)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='requires CUDA and its compiler')
@pytest.mark.parametrize('backend', ['cuda_clock', 'cuda_clock_fast'])
def test_fused_active_clock_matches_torch(backend):
    torch.manual_seed(11)
    reference = clock_layer().cuda()
    fused = copy.deepcopy(reference)
    fused.config.backend = backend
    x = torch.randn(2, 137, 8, device='cuda', requires_grad=True)
    xf = x.detach().clone().requires_grad_()
    y, state = reference(x, return_state=True)
    yf, sf = fused(xf, return_state=True)
    torch.testing.assert_close(yf, y, rtol=2e-3, atol=2e-4)
    torch.testing.assert_close(sf.ssm.lam, state.ssm.lam, rtol=2e-3, atol=2e-4)
    torch.testing.assert_close(sf.ssm.eta, state.ssm.eta, rtol=2e-3, atol=2e-4)
    y.square().mean().backward()
    yf.square().mean().backward()
    torch.testing.assert_close(xf.grad, x.grad, rtol=3e-3, atol=2e-5)
    for name, p in reference.named_parameters():
        if p.grad is not None:
            torch.testing.assert_close(dict(fused.named_parameters())[name].grad, p.grad,
                                       rtol=3e-3, atol=2e-5)
