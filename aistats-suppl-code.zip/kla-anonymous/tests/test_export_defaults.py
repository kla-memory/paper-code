"""Package defaults, backend aliases, and carried-state dispatch."""
import math

import torch

from kla import KLAConfig, KLALayer


def test_defaults_are_the_exact_preset():
    cfg = KLAConfig()
    assert cfg.d_state == 32 and cfg.expand == 2.0
    assert cfg.process_noise_param == "sigma2"
    assert cfg.process_noise_coupling == "exact"
    assert cfg.process_noise_kappa_min == cfg.process_noise_kappa_max == 1.0
    assert cfg.decay_a_init_mode == "unit"
    assert cfg.dt_init_per_cell is True
    assert (cfg.dt_min, cfg.dt_max) == (1e-4, 0.1)
    assert cfg.reference_prior is True and cfg.obs_noise_init == "auto" and cfg.qk_norm is True
    assert (cfg.value_rank, cfg.var_rank) == ("conv", "auto")


def test_default_layer_starts_at_kappa_one_on_the_long_ladder():
    torch.manual_seed(0)
    layer = KLALayer(64, KLAConfig(d_state=8))
    s = layer.dynamics_summary()
    assert torch.allclose(s["kappa"], torch.ones_like(s["kappa"]), rtol=1e-2, atol=0)  # fp32 DARE round trip
    # unit |a| and per-cell Delta: u spans the ladder [1e-4, 1e-1] within each channel
    assert torch.allclose(torch.exp(layer.lambda_log.float()), torch.ones_like(layer.lambda_log.float()))
    u = s["u"]
    assert u.min() >= 1e-4 * 0.999 and u.max() <= 0.1 * 1.001
    assert (u.amax(dim=1) / u.amin(dim=1) > 2).all()       # distinct draws per channel, not one Delta per channel
    # the longest half-life at kappa = 1 is ln2 / (2 u_min) ~ 3,466 tokens
    assert abs(s["half_life"].max().item() - math.log(2) / (2 * u.min().item())) / s["half_life"].max().item() < 1e-3
    assert layer.initial_precision is not None                # reference prior saved


def test_cuda_alias_and_backup_select_distinct_builds(monkeypatch):
    from kla.ops import cuda_backend, kla_ops

    calls = []
    monkeypatch.setattr(cuda_backend, "kla_scan_cuda", lambda *a, **kw: calls.append(
        kw.get("kernel_version", cuda_backend.DEFAULT_KERNEL_VERSION)))
    for name in ("cuda", "cuda_static", "cuda_static_fast"):
        kla_ops._BACKENDS[name]()
    assert calls == ["static", "static", "static_fast"]
    assert set(cuda_backend.KERNEL_VERSIONS) == {
        "static", "static_fast", "clock", "clock_fast"}
    assert "-DKLA_BWD_COALESCED_ATOMICS=1" in cuda_backend._nvcc_flags("static")
    assert "-DKLA_BWD_COALESCED_ATOMICS=1" not in cuda_backend._nvcc_flags("static_fast")


def test_auto_dispatch_preserves_carried_state(monkeypatch):
    from kla.ops import kla_ops

    # Exercise the GPU dispatch decision without requiring a GPU for this test.
    monkeypatch.setattr(kla_ops, "_resolve_auto", lambda x: "cuda")
    layer = KLALayer(8, KLAConfig(d_state=4, backend="torch"))
    x = torch.randn(1, 7, 8)
    expected, expected_state = layer(x, return_state=True)
    layer.config.backend = "auto"
    actual, actual_state = layer(x, state=layer.init_state(1), return_state=True)
    torch.testing.assert_close(actual, expected)
    torch.testing.assert_close(actual_state.ssm.lam, expected_state.ssm.lam)


def test_removed_backends_fail_clearly():
    import pytest

    for backend in ("cuda_unsupported", "cuda_v3", "triton"):
        with pytest.raises(ValueError, match="not in this release"):
            KLALayer(8, KLAConfig(backend=backend))
