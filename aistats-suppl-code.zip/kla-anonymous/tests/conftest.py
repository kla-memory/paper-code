import pytest
import torch


@pytest.fixture(autouse=True)
def _seed():
    torch.manual_seed(0)


def pytest_generate_tests(metafunc):
    """Tests taking a ``device`` argument run on CPU and, when present, on CUDA."""
    if "device" in metafunc.fixturenames:
        devices = ["cpu"]
        if torch.cuda.is_available():
            devices.append("cuda")
        metafunc.parametrize("device", devices)
