"""Contract: the layer declares no-decay parameters; trainers consume the declaration.

Closed world: every parameter a layer tags is also declared by name, under every
parametrization and skip mode, and the name-based split agrees with the tags even
after the tags are stripped (as FSDP/DTensor wrapping and Parameter replacement do).
"""
import itertools

import pytest
import torch

from torch import nn

from kla import KLAConfig, KLALayer, KLASelectiveLayer, no_weight_decay_names, split_decay_parameters

LAYERS = (KLALayer, KLASelectiveLayer)
SKIP = ({"use_lambda_skip": False}, {"lambda_skip_mode": "scalar"}, {"lambda_skip_mode": "vector"})
OBS = ({"obs_noise_init": None}, {"obs_noise_init": "auto"})


def _layer(cls=KLALayer, **kw):
    defaults = dict(d_state=4, expand=1, backend="torch")
    if cls is KLASelectiveLayer:
        defaults["selective"] = True
    with torch.device("meta"):
        return cls(16, KLAConfig(**{**defaults, **kw}))


def _tagged(module):
    return {n for n, p in module.named_parameters() if getattr(p, "_no_weight_decay", False)}


@pytest.mark.parametrize("layer_type, skip, obs", list(itertools.product(LAYERS, SKIP, OBS)))
def test_layer_declaration_matches_tags(layer_type, skip, obs):
    layer = _layer(cls=layer_type, **skip, **obs)
    declared = layer.no_weight_decay()
    assert declared == _tagged(layer)
    assert declared <= {n for n, _ in layer.named_parameters()}
    expected = {"delta", "lambda_log", "sigma2_log"}
    if skip.get("use_lambda_skip", True):
        expected.add("lambda_skip")
    if obs["obs_noise_init"] is not None:
        expected.add("obs_noise_bias")
    assert declared == expected
    # Matrices and the conv are never declared.
    assert not any(n.endswith("proj.weight") or n.startswith("conv") for n in declared)


def test_prefix_and_model_walk():
    model = nn.Sequential(nn.Linear(16, 16), KLALayer(16, KLAConfig(d_state=4, expand=1, backend="torch")))
    names = no_weight_decay_names(model)
    assert names == {"1." + n for n in model[1].no_weight_decay()}
    assert model[1].no_weight_decay("x.y.") == {"x.y." + n for n in model[1].no_weight_decay()}


def test_split_survives_stripped_tags_and_parameter_replacement():
    model = nn.Sequential(nn.Linear(16, 16), KLALayer(16, KLAConfig(d_state=4, expand=1, backend="torch")))
    layer = model[1]
    layer.lambda_skip = nn.Parameter(layer.lambda_skip.reshape(1))  # drops the tag, keeps the name
    for p in model.parameters():
        if hasattr(p, "_no_weight_decay"):
            del p._no_weight_decay
    decay, no_decay = split_decay_parameters(model)
    excluded = {id(p) for p in no_decay}
    for name, p in model.named_parameters():
        assert (id(p) in excluded) == (name in no_weight_decay_names(model)), name
    assert id(model[0].weight) not in excluded and id(layer.in_proj.weight) not in excluded
    assert len(decay) + len(no_decay) == sum(1 for _ in model.parameters())


def test_split_fails_loudly_when_declaration_is_broken():
    layer = KLALayer(16, KLAConfig(d_state=4, expand=1, backend="torch"))
    layer._no_weight_decay_names.append("does_not_exist")
    with pytest.raises(ValueError, match="not found in model"):
        split_decay_parameters(layer)

    class Silent(nn.Module):
        def __init__(self):
            super().__init__()
            self.w = nn.Linear(4, 4)

        def no_weight_decay(self, prefix=""):
            return set()

    with pytest.raises(ValueError, match="none were excluded"):
        split_decay_parameters(Silent())
    assert split_decay_parameters(Silent(), require_declaration=False)[1] == []
    assert split_decay_parameters(nn.Linear(4, 4))[1] == []  # no declaring module: plain split


def test_mark_rejects_non_parameters():
    layer = KLALayer(16, KLAConfig(d_state=4, expand=1, backend="torch"))
    with pytest.raises(TypeError):
        layer._mark_no_weight_decay("config")
