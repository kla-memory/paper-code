"""Analytic regimes for the opt-in diagnostic replay (no CUDA required)."""
import json
import math

import pytest
import torch

from kla.ops.diagnostics import diagnose_precision_information


def inputs(length=12):
    return (torch.ones(1, length, 1), torch.ones(1, length, 1),
            torch.ones(1, length, 1), torch.tensor([[0.9]]), torch.tensor([[0.01]]))


def test_matched_reference_is_stationary_and_contractive():
    v, lv, k, a, p = inputs()
    u, kap = 0.1, 2.0
    a.fill_(math.exp(-u))
    p.fill_(math.expm1(kap*u) * -math.expm1(-(kap+2)*u))
    prior = torch.tensor([[1 / -math.expm1(-kap*u)]])
    report = diagnose_precision_information(v, lv, k, a, p, prior_precision=prior)
    assert report['longest_expanding_run'] == 0
    assert report['alpha_gt_one_fraction'] == 0
    for bound in ('finite_min', 'finite_max'):
        assert report['ranges']['lambda'][bound] == pytest.approx(prior.item(), rel=2e-6)
        assert report['ranges']['alpha_eta'][bound] == pytest.approx(math.exp(-3*u), rel=2e-6)
    assert all(s['nonfinite'] == 0 for s in report['ranges'].values())
    json.dumps(report, allow_nan=False)


def test_unobserved_unit_prior_expands_information_products():
    v, lv, k, a, p = inputs(8)
    k.zero_()
    p.zero_()
    report = diagnose_precision_information(v, lv, k, a, p)
    assert report['longest_expanding_run'] == 8
    assert report['alpha_gt_one_fraction'] == 1
    assert report['ranges']['eta_prefix_product']['finite_max'] == pytest.approx((1/0.9)**8, rel=2e-6)
    assert report['static_floors']['Q_below_floor'] == 1
    assert report['ranges']['phi']['finite_max'] == 0


def test_floor_counts_and_inputs_unchanged():
    args = list(inputs(3))
    args[-2].zero_()
    args[-1].zero_()
    args[0].requires_grad_()
    originals = [x.detach().clone() for x in args]
    report = diagnose_precision_information(*args)
    assert report['static_floors'] == dict(cell_count=1, Q_below_floor=1, a2_below_floor=1)
    assert report['longest_expanding_run'] == 0
    for x, original in zip(args, originals):
        assert torch.equal(x, original)
        assert x.grad is None


def test_nonfinite_mobius_intermediates_are_counted():
    args = list(inputs(2))
    args[1].fill_(1e30)
    args[-1].fill_(1e30)
    report = diagnose_precision_information(*args)
    assert report['ranges']['mobius_raw']['nonfinite'] > 0
    assert report['ranges']['lambda']['nonfinite'] == 2
    assert report['ranges']['lambda']['finite_min'] is None
    json.dumps(report, allow_nan=False)
    wide = diagnose_precision_information(*args, dtype=torch.float64)
    assert wide['ranges']['mobius_raw']['nonfinite'] == 0


def test_shape_validation():
    args = list(inputs())
    args[-1] = args[-1].expand(1, 12, 1, 1)
    with pytest.raises(ValueError, match='static'):
        diagnose_precision_information(*args)
