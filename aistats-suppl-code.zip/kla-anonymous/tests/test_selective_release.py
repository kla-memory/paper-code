"""Kalman–Bucy clock, recurrent state, and fused CUDA parity."""
import copy
from types import SimpleNamespace

import pytest
import torch

from kla import KLAConfig, KLASelectiveLayer, build_mixer


def config(init="exact", **overrides):
    kw = dict(d_state=8, expand=1.0, selective_rank=4, backend="torch",
              lambda_skip_mode="vector", return_variance=True)
    if init == "half_life":
        kw.update(dt_init_mode="halflife", halflife_min=4.0, halflife_max=4096.0)
    kw.update(overrides)
    return KLAConfig.kalman_bucy(**kw)


def excite(layer):
    with torch.no_grad():
        for up in (layer.sel_up_a,):
            if up is not None:
                up.weight.normal_(0, 0.2)
                up.bias.normal_(0, 0.2)


@pytest.mark.parametrize("init", ["exact", "half_life"])
def test_zero_controllers_recover_static_initialization(init):
    torch.manual_seed(3)
    cfg = config(init)
    layer = build_mixer(16, cfg)
    assert isinstance(layer, KLASelectiveLayer)
    static_cfg = copy.deepcopy(cfg)
    static_cfg.selective = False
    static = build_mixer(16, static_cfg)
    static.load_state_dict({k: v for k, v in layer.state_dict().items() if k in static.state_dict()})
    x = torch.randn(2, 17, 16)
    (y, var), state = layer(x, return_state=True)
    (ref, ref_var), ref_state = static(x, return_state=True)
    for got, expected in ((y, ref), (var, ref_var), (state.ssm.lam, ref_state.ssm.lam),
                          (state.ssm.eta, ref_state.ssm.eta)):
        torch.testing.assert_close(got, expected, rtol=2e-5, atol=2e-5)
    assert layer.sigma2_floor.item() == 0.0
    assert layer.initial_precision is not None
    for up in (layer.sel_up_a,):
        if up is not None:
            assert torch.count_nonzero(up.weight) == torch.count_nonzero(up.bias) == 0
            assert up.weight._no_reinit and up.bias._no_reinit


def test_active_controllers_gradients_and_recurrent_state():
    layer = KLASelectiveLayer(16, config(backend="auto"))
    excite(layer)
    x = torch.randn(2, 13, 16, requires_grad=True)
    (y, var), full = layer(x, return_state=True)
    (y.square().mean() + var.mean()).backward()
    for name, param in layer.named_parameters():
        assert param.grad is not None and torch.isfinite(param.grad).all(), name
    assert torch.isfinite(x.grad).all()
    with torch.no_grad():
        (prefix, _), state = layer(x[:, :5], return_state=True)
        (middle, _), state = layer(x[:, 5:9], state=state, return_state=True)
        ys = [prefix, middle]
        for t in range(9, 13):
            (out, _), state = layer(x[:, t:t+1], state=state, return_state=True)
            ys.append(out)
    torch.testing.assert_close(torch.cat(ys, dim=1), y, atol=2e-5, rtol=2e-4)
    torch.testing.assert_close(state.ssm.lam, full.ssm.lam, atol=2e-5, rtol=2e-4)
    torch.testing.assert_close(state.ssm.eta, full.ssm.eta, atol=2e-5, rtol=2e-4)


def test_closed_clock_suppresses_observation_updates():
    layer = KLASelectiveLayer(16, config())
    with torch.no_grad():
        layer.sel_up_a.bias.fill_(-40.0)
        _, state = layer(torch.randn(2, 9, 16), return_state=True)
    assert state.ssm.eta.abs().max() < 1e-6
    torch.testing.assert_close(state.ssm.lam, layer.initial_precision.expand_as(state.ssm.lam),
                               atol=1e-5, rtol=1e-5)


@pytest.mark.parametrize("init", ["exact", "half_life"])
def test_meta_reset_save_restore_and_tags(init):
    with torch.device("meta"):
        layer = KLASelectiveLayer(16, config(init))
    layer.to_empty(device="cpu")
    layer.reset_parameters()
    assert torch.isfinite(layer.delta).all()
    assert layer.delta._no_weight_decay and layer.sigma2_log._no_weight_decay
    restored = KLASelectiveLayer(16, config(init))
    restored.load_state_dict(layer.state_dict())
    x = torch.randn(1, 5, 16)
    for a, b in zip(layer(x), restored(x)):
        torch.testing.assert_close(a, b)


def test_auto_enters_fused_before_materializing(monkeypatch):
    layer = KLASelectiveLayer(16, config(backend="auto"))
    sentinel = object()
    def fused(z, state, backend):
        assert backend == "cuda_clock" and state is None
        return sentinel
    monkeypatch.setattr(layer, "_run_ssm_fused", fused)
    monkeypatch.setattr(layer, "_compute_aq", lambda z: pytest.fail("materialized dynamics"))
    fake_cuda = SimpleNamespace(is_cuda=True, dtype=torch.float32)
    assert layer._run_ssm(fake_cuda, None) is sentinel
    assert layer._fused_backend(fake_cuda, object()) is None
    assert layer._fused_backend(SimpleNamespace(is_cuda=False, dtype=torch.float32)) is None


def test_selective_builds_and_rank():
    from kla.ops import cuda_backend as cb
    from kla.ops.kla_ops import FUSED_KERNEL_VERSIONS
    assert FUSED_KERNEL_VERSIONS["cuda_selective"] == "clock"
    assert FUSED_KERNEL_VERSIONS["cuda_clock"] == "clock"
    assert "-DKLA_BWD_COALESCED_ATOMICS=1" in cb._nvcc_flags("clock")
    assert "-DKLA_BWD_COALESCED_ATOMICS=1" not in cb._nvcc_flags("clock_fast")
    assert cb.supports_prior_precision("cuda_clock")
    assert cb._csrc_dir("clock").endswith("selective_fused")
    assert KLASelectiveLayer(352, config(selective_rank=None)).selective_rank == 44


@pytest.mark.parametrize("override", [dict(backend="cuda_static"), dict(eval_backend="cuda")])
def test_unsupported_selective_settings_fail(override):
    with pytest.raises(ValueError):
        KLASelectiveLayer(16, config(**override))


requires_cuda = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")


@requires_cuda
@pytest.mark.parametrize("backend", ["cuda_clock", "cuda_clock_fast"])
@pytest.mark.parametrize("init", ["exact", "half_life"])
@pytest.mark.parametrize("length", [129, 513])
def test_gpu_full_warp_all_gradients_and_state(backend, init, length):
    torch.manual_seed(5)
    layer = KLASelectiveLayer(16, config(init, backend=backend)).cuda()
    excite(layer)
    ref = copy.deepcopy(layer)
    ref.config.backend = "torch"
    x = torch.randn(2, length, 16, device="cuda")
    dy, dv = torch.randn(2, length, 16, device="cuda"), torch.randn(2, length, 16, device="cuda")
    results = []
    for model in (layer, ref):
        xi = x.clone().requires_grad_()
        (y, var), state = model(xi, return_state=True)
        ((y * dy).sum() + (var * dv).sum()).backward()
        grads = {n: p.grad.detach().clone() for n, p in model.named_parameters() if p.grad is not None}
        results.append((y, var, state, xi.grad, grads))
    y, var, state, dx, grads = results[0]
    yr, vr, sr, dxr, gr = results[1]
    for a, b in ((y, yr), (var, vr), (state.ssm.lam, sr.ssm.lam), (state.ssm.eta, sr.ssm.eta), (dx, dxr)):
        torch.testing.assert_close(a, b, atol=2e-5, rtol=2e-4)
    assert grads.keys() == gr.keys()
    for name in grads:
        assert torch.isfinite(grads[name]).all(), name
        assert (grads[name] - gr[name]).abs().max() <= 2e-5 + 2e-4 * gr[name].abs().max(), name
    with torch.no_grad():
        next_x = torch.randn(2, 1, 16, device="cuda")
        (n, _), ns = layer(next_x, state=state, return_state=True)
        (nr, _), nrs = ref(next_x, state=sr, return_state=True)
        torch.testing.assert_close(n, nr, atol=2e-5, rtol=2e-4)
        torch.testing.assert_close(ns.ssm.lam, nrs.ssm.lam, atol=2e-5, rtol=2e-4)


@requires_cuda
def test_gpu_auto_bf16_uses_fused(monkeypatch):
    layer = KLASelectiveLayer(16, config(backend="auto")).cuda()
    excite(layer)
    monkeypatch.setattr(layer, "_compute_aq", lambda z: pytest.fail("auto materialized dynamics"))
    x = torch.randn(2, 129, 16, device="cuda", requires_grad=True)
    with torch.autocast("cuda", dtype=torch.bfloat16):
        y, var = layer(x)
    (y.float().square().mean() + var.float().mean()).backward()
    for name, p in layer.named_parameters():
        assert p.grad is not None and torch.isfinite(p.grad).all(), name
    assert torch.isfinite(x.grad).all()
