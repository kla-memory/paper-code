# Kalman Linear Attention (KLA)

Code for our anonymous AISTATS submission. The package implements the two
models from the paper:

- **Exact-init KLA** (`KLAConfig.exact()`), with learned, input-independent OU dynamics.
- **Kalman–Bucy KLA** (`KLAConfig.kalman_bucy()`), where a learned clock scales
  the timestep and the observation information on every token.

Both start from the same place: exact process-noise initialization, a learned
stationary variance, and a reference prior that matches it. The clock in the
Kalman–Bucy model is zero-initialized, so at step zero it is the exact-init
model.

There is a pure PyTorch implementation that runs anywhere, plus fused CUDA scans
for the forward and backward pass on GPU. This repository has the layers, the
kernels, their tests, and the synthetic topic-recall experiment. The pretraining
and MQAR setups will be released with the camera-ready version.

## Install

```bash
uv sync --python 3.11
uv run python -m kla                  # prints which backends work here, runs one forward
uv run python examples/smoke.py       # both models: forward, backward, chunked inference
```

Needs Python >= 3.10 and PyTorch >= 2.8. `uv sync` also installs pytest and
ninja. If you would rather use an existing environment, `uv pip install -e .`
installs just the package.

The CUDA kernels are JIT-compiled the first time a layer runs on GPU, so you
need `nvcc` and ninja for that path. See
[docs/installation_issues.md](docs/installation_issues.md) if the build
complains, and [docs/backends.md](docs/backends.md) for what each backend does
and its limits.

```bash
uv run python examples/smoke.py --device cuda
```

## Usage

```python
import torch
from kla import KLAConfig, build_mixer

config = KLAConfig.kalman_bucy(d_state=8, backend="torch")   # or KLAConfig.exact(...)
layer = build_mixer(32, config)

x = torch.randn(2, 17, 32)
y = layer(x)
y.square().mean().backward()
```

`KLAConfig()` is the same as `KLAConfig.exact()`. Defaults: `d_state=32`,
`expand=2`, normalized queries and keys, automatic observation-noise
calibration, kappa = 1, and timesteps drawn log-uniformly in `[1e-4, 0.1]` per
(channel, state) cell.

If you prefer to think in memory horizons rather than timesteps, use the
half-life mode:

```python
config = KLAConfig.exact(
    dt_init_mode="halflife",
    halflife_min=4.0, halflife_max=4096.0,
    process_noise_kappa_min=0.05, process_noise_kappa_max=0.3,
)
```

Horizon and kappa are drawn independently per cell, both log-uniform. Equal
endpoints give a constant. The formulas are in
[docs/initialization.md](docs/initialization.md).

### Continuing a sequence

Both models accept and return their state (the causal-conv buffer and the
filter state), so you can run a sequence in pieces:

```python
with torch.no_grad():
    first, state = layer(x[:, :7], return_state=True)
    rest, state = layer(x[:, 7:], state=state)
    torch.testing.assert_close(torch.cat((first, rest), dim=1), layer(x))
```

Single-token steps go through the PyTorch recurrence. The CUDA scans return the
final state detached, so if you need gradients to flow through a carried state,
use `backend="torch"`.

### Training

Build layers through `build_mixer` so the config picks the right class. If your
training code re-initializes weights model-wide, respect the `_no_reinit` flag
on the observation and clock heads. After constructing on the meta device and
calling `to_empty()`, call `reset_parameters()` before creating the optimizer.

The dynamics parameters should not get weight decay. The layer marks them, and
there is a helper to split them out:

```python
from kla import split_decay_parameters

decay, no_decay = split_decay_parameters(layer)
optimizer = torch.optim.AdamW([
    {"params": decay, "weight_decay": 0.1},
    {"params": no_decay, "weight_decay": 0.0},
], lr=1e-3)
```

## Synthetic experiment

```bash
uv run python -m examples.synthetic.run --profile smoke --output results/topic-smoke
```

The lagged topic-recall task from the paper, with the paper settings behind
`--profile paper`. See [docs/synthetic.md](docs/synthetic.md).

## Tests

```bash
uv run pytest -q                 # everything
uv run pytest -q -m "not slow"   # skip the finite-difference gradchecks
```

GPU tests are skipped when there is no CUDA device. On a GPU host,
`tests/test_backends.py`, `tests/test_selective_release.py` and
`tests/test_clock_release.py` check the kernels against the PyTorch
implementation.
