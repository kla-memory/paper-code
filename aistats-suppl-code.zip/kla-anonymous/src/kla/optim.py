"""Optimizer parameter grouping for models containing KLA layers.

The layer *declares* which of its parameters must not be weight-decayed
(:meth:`kla.KLALayer.no_weight_decay`); the trainer *decides* the policy. This
module is the one place trainers should call so the two never drift.

Convention: any module exposing ``no_weight_decay(prefix) -> set[str]`` is
consulted, so wrappers or non-KLA mixers can join the same protocol (this is the
timm convention, discovered by ``hasattr(module, "no_weight_decay")``).
"""
from __future__ import annotations

from torch import nn


def no_weight_decay_names(model: nn.Module) -> set[str]:
    """Fully qualified names declared no-decay by any module in ``model``."""
    names: set[str] = set()
    for prefix, module in model.named_modules():
        declare = getattr(module, "no_weight_decay", None)
        if callable(declare):
            names |= declare(prefix + "." if prefix else "")
    return names


def split_decay_parameters(model: nn.Module, *, require_declaration: bool = True):
    """Split trainable parameters into ``(decay, no_decay)`` lists.

    Name-based, so it is unaffected by FSDP/DTensor wrapping or by wrappers that
    replace a Parameter (which drops the ``_no_weight_decay`` attribute). A
    parameter carrying that attribute is also excluded, for modules that only tag.

    Raises if a declared name is missing from the model (a wrapper renamed or
    dropped it), or -- with ``require_declaration`` -- if the model contains a
    declaring module but nothing ended up excluded. The second check is the
    loud failure for a trainer whose grouping hook was never installed.
    """
    declared = no_weight_decay_names(model)
    params = dict(model.named_parameters())
    missing = declared - params.keys()
    if missing:
        raise ValueError(f"Declared no-weight-decay parameters not found in model: {sorted(missing)}")
    decay, no_decay = [], []
    for name, param in params.items():
        if not param.requires_grad:
            continue
        excluded = name in declared or getattr(param, "_no_weight_decay", False)
        (no_decay if excluded else decay).append(param)
    declaring = any(callable(getattr(m, "no_weight_decay", None)) for m in model.modules())
    if require_declaration and declaring and not no_decay:
        raise ValueError("Model declares no-weight-decay parameters but none were excluded")
    return decay, no_decay


__all__ = ["no_weight_decay_names", "split_decay_parameters"]
