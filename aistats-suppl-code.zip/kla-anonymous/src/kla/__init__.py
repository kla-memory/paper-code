"""Kalman Linear Attention (KLA): attention as an exact parallel Kalman filter.

Quick start::

    import torch
    from kla import KLAConfig, KLALayer

    layer = KLALayer(d_model=512, config=KLAConfig(d_state=16))
    y = layer(torch.randn(2, 128, 512))          # [2, 128, 512]

Use ``KLAConfig.exact()`` for static KLA or ``KLAConfig.kalman_bucy()``
with ``build_mixer`` for the Kalman–Bucy clock. Both use exact initialization.
Run ``python -m kla`` to print which scan backends are usable on this machine.
"""

from kla.layers.kla_selective_layer import KLASelectiveLayer
from kla.configs import KLAConfig, ModelConfig
from kla.layers import KLALayer, KLALayerState
from kla.models import SequenceModel, build_mixer, register_mixer
from kla.ops import KLAState, kla_scan, kla_scan_reference, kla_step
from kla.optim import no_weight_decay_names, split_decay_parameters

__version__ = "0.2.0"


def backend_info() -> dict:
    """Report dispatch choices; CUDA availability does not verify the JIT toolchain."""
    import torch
    from kla.ops.cuda_backend import DEFAULT_KERNEL_VERSION

    cuda = torch.cuda.is_available()
    why = "JIT on first use; needs matching nvcc and ninja" if cuda else "needs a CUDA device"
    return {
        "device": torch.cuda.get_device_name(0) if cuda else "cpu",
        "resolved_auto": "cuda" if cuda else "torch",
        "default_cuda_kernel": DEFAULT_KERNEL_VERSION,
        "default_selective_kernel": "clock",
        "backends": {
            "torch": (True, "reference and carried-state scan"),
            "cuda": (cuda, "static CUDA; " + why),
            "cuda_static": (cuda, "static CUDA; " + why),
            "cuda_static_fast": (cuda, "explicit static backup; " + why),
            "cuda_selective": (cuda, "Kalman–Bucy CUDA; " + why),
            "cuda_clock": (cuda, "Kalman–Bucy CUDA; " + why),
            "cuda_clock_fast": (cuda, "explicit selective backup; " + why),
        },
        "log_space_on": ["torch"],
    }


__all__ = [
    "KLAConfig",
    "KLALayer",
    "KLASelectiveLayer",
    "KLALayerState",
    "KLAState",
    "ModelConfig",
    "SequenceModel",
    "backend_info",
    "build_mixer",
    "register_mixer",
    "kla_scan",
    "kla_scan_reference",
    "kla_step",
    "no_weight_decay_names",
    "split_decay_parameters",
    "__version__",
]
