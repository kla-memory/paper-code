"""Configurations for static exact-init KLA and Kalman–Bucy KLA."""

from __future__ import annotations

import dataclasses
import math
from typing import Literal, Optional, Union, get_args

Backend = Literal["auto", "torch", "cuda", "cuda_static", "cuda_static_fast", "cuda_selective", "cuda_clock", "cuda_clock_fast"]
ScanImpl = Literal["auto", "associative", "doubling", "sequential"]
MobiusImpl = Literal["linear", "log"]

# How a d_inner-wide sensor signal is produced from the post-conv stream z.
#   "full"  one Linear(M, M): no bottleneck. A full-rank sensor projection.
#   "auto"  low rank M -> r -> M, with r = ceil(d_model/8).
#   int     that rank explicitly. Only *saves* when 2*rank < d_inner.
#   "conv"  (value only) v = z, no projection at all. Mamba's move.
Rank = Union[int, Literal["full", "auto"]]
ValueRank = Union[int, Literal["full", "auto", "conv"]]

@dataclasses.dataclass
class KLAConfig:
    """Configuration for the two models in this release.

    Use ``KLAConfig.exact(...)`` for static KLA or
    ``KLAConfig.kalman_bucy(...)`` for the Kalman–Bucy clock. Both use exact
    process-noise initialization, learned OU stationary variance and the
    matching reference posterior precision. ``KLAConfig()`` is static KLA.

    Dimensions, sensor projections, and timestep/horizon and kappa ranges
    remain configurable. Unsupported model variants are not included.
    """

    # --- dimensions -------------------------------------------------------
    d_state: int = 32
    """State dimension S per channel (the qk dim of the outer-product expansion)."""

    expand: float = 2.0
    """Channel expansion factor (Mamba-style). d_inner = expand * d_model."""

    # --- discretization ---------------------------------------------------
    # In the static model, the continuous transition ``a`` and process noise
    # ``p`` are learnable but time-invariant; the discretization step Δ is a
    # static learned parameter of shape [d_inner, d_state] (not input-dependent).
    dt_min: float = 1e-4
    """Lower bound of the Δ initialization range (log-uniform). How many draws
    there are is ``dt_init_per_cell``."""

    dt_init_per_cell: bool = True
    """Sample a timestep per (channel, state) when True. In loguniform mode, False shares one timestep across each channel. Halflife mode currently requires True."""

    dt_init_mode: Literal["loguniform", "halflife"] = "loguniform"
    """Initialization coordinate: loguniform timesteps or loguniform half-lives.
    Halflife mode samples H and kappa per cell, sets
    u = ln(2) / ((1 + kappa) * H), and shares the same kappa with exact
    process-noise and reference-prior initialization. It ignores dt_min,
    dt_max and dt_init_floor."""

    halflife_min: float = 8.0
    """Shortest target half-life (tokens) for ``dt_init_mode="halflife"``."""

    halflife_max: float = 8192.0
    """Longest target half-life (tokens) for ``dt_init_mode="halflife"``."""

    dt_max: float = 0.1
    """Upper bound of the Δ initialization range."""

    dt_init_floor: float = 1e-4
    """Floor applied to the sampled Δ initialization."""

    discretization: Literal["ou"] = "ou"
    """OU discretization for both supported models."""

    decay_a_init_mode: Literal["unit"] = "unit"
    """Initialize the learned continuous decay magnitude to one in every cell."""

    # --- process / observation noise --------------------------------------

    process_noise_coupling: Literal["exact"] = "exact"
    """Exact scalar Riccati initializer; constant and heuristic noise initialization are unsupported."""

    process_noise_kappa_min: float = 1.0
    """Lower positive kappa bound. Equal bounds give constant kappa; otherwise sample log-uniformly per cell."""

    process_noise_kappa_max: float = 1.0
    """Upper kappa bound; must be finite and no smaller than process_noise_kappa_min."""

    process_noise_r0: Union[float, Literal["auto"]] = "auto"
    """Per-cell observation variance r_eff = 1/phi0 the coupled/exact init is
    referenced to. ``"auto"`` derives it from this layer at init: sigma_v0 /
    E[k_s^2], with sigma_v0 = obs_noise_init (or softplus(0) + obs_var_min when
    that is unset) and E[k_s^2] = 1/d_state under qk_norm. Without qk_norm this
    reference is no longer exact for the actual sensors (``_check_phi0_assumption``
    already warns about exactly this at reset time), so rather than sample a
    forward pass to measure it, "auto" assumes the same 1/d_state reference --
    i.e. phi0 = 1, the fixed point pinned by construction under qk_norm=True +
    obs_noise_init="auto". A float overrides it directly, in sigma_v / k_s^2
    units."""

    reference_prior: Literal[True] = True
    """Start fresh sequences at phi0 / (1 - exp(-kappa*u)), with zero information vector."""

    process_noise_mode: Literal["learned"] = "learned"
    """Learn process noise. Frozen experiments freeze parameters after construction."""

    process_noise_param: Literal["sigma2"] = "sigma2"
    """Learn OU stationary variance: sigma2 = exp(sigma2_log), p_bar = sigma2 * (1 - a_bar**2)."""

    sigma2_min: Optional[float] = 0.0
    """Zero floor preserves the exact initialization target. None is accepted as a zero-floor alias."""

    obs_var_min: float = 1e-4
    """Floor added to the predicted observation variance (softplus(log_var) + floor)."""

    obs_var_max: Optional[float] = None
    """Optional clamp on the predicted observation variance."""

    obs_noise_init: Optional[Union[float, Literal["auto"]]] = "auto"
    """Baseline observation variance r0 every token sees at init (a "silent" sensor).

    ``"auto"`` (the default) sets r0 = 1/d_state, the gauge in which a token
    carries unit MEAN observation precision per state (E[k_s^2] = 1/S under
    ``qk_norm``, so E[phi] = E[k_s^2]/r0 = 1) and the process-noise couplings
    below reduce to p = kappa(kappa+2) u. It is a statement about mean
    information, not about gain: the normalised key spends a token's fixed
    budget sum_s phi = S unevenly across states on purpose.

    The steady-state process-noise initializer (``process_noise_coupling``)
    is derived once, at the reference point phi0 = E[phi] = 1, and relies on
    this exact combination -- ``qk_norm=True`` (also the default) and
    ``obs_noise_init="auto"`` -- to make phi0 = 1 hold by construction rather
    than approximately. Without both, ``KLALayer`` warns at reset time that
    the initializer's phi0 = 1 assumption is not exact for the configured
    sensors.

    When set (to ``"auto"`` or a float), the layer adds a per-channel bias
    ``obs_noise_bias`` [d_inner] to the log-variance pre-activation,
    initialised to softplus^-1(r0 - obs_var_min), and ZEROES the head's
    output weight (``var_expand`` under a low-rank head, the sigma rows of
    ``sensor_proj`` under ``var_rank="full"``). So at init sigma_v == r0
    exactly, for every token and channel -- not merely in expectation -- and
    the input-dependent part grows from silence, LoRA-style. That makes r0
    the scale every process-noise coupling is referenced to (see
    ``process_noise_kappa_min``/``process_noise_kappa_max``), rather than an
    accidental one. Must lie in (obs_var_min, obs_var_max].

    ``None`` restores the uncalibrated observation head: the log-variance
    head is a plain random projection, so the per-token variance is
    softplus(W z) + floor, whose MEDIAN is softplus(0) = 0.693 but whose mean
    is higher (softplus is convex) and which varies token to token from step
    0. The ``obs_noise_bias`` tensor exists only when this is set, so
    checkpoints trained under ``None`` (before this became the default, or
    with it explicitly off) load unchanged -- a missing key falls back to the
    plain projection with a warning rather than inventing a silent-sensor
    baseline the checkpoint never had."""

    # --- sensor path shape: the "plain" and "mamba" blocks -----------------
    # Two projection controls. The two named blocks are just presets over them:
    #
    #   plain block   value_rank="full", var_rank="full"
    #   mamba block   value_rank="conv", var_rank="auto"   <- defaults
    #
    # Neither touches the scan: both emit v [B,L,M], Lambda^v [B,L,M],
    # k/q [B,L,S], so kla_scan cannot tell them apart and no backend, kernel or
    # backward changes. That is the difference from `selective`, which changes
    # a/p from rank-2 to rank-4 and *is* visible to the scan.
    block_type: Optional[Literal["plain", "mamba"]] = None
    """Named sensor preset. ``None`` keeps the explicit rank controls.

    ``"plain"`` fixes full value and observation-noise projections;
    ``"mamba"`` fixes ``value_rank="conv"`` and ``var_rank="auto"``.
    When a named preset is selected, conflicting explicit ranks are rejected by
    :class:`~kla.layers.KLALayer` instead of silently changing the preset.
    """

    value_rank: ValueRank = "conv"
    """How the value ``v`` is produced from the post-conv stream ``z``.

    ``v`` is d_inner wide, so this is the single most expensive projection in
    the layer: "full" costs M^2 per block. "conv" (v = z) is Mamba's move and
    costs nothing at all.

    CAUTION on an integer / "auto" here: unlike the variance, ``v`` is the signal
    being *filtered*, and a low-rank map confines it to a fixed r-dimensional
    subspace of the channel space for every token. The read-out is not hard
    capped at rank r (the ``eta * 1/lambda`` gain is elementwise and nonlinear,
    as is softplus on the variance), but it is a real restriction on what the
    filter can observe. Untested; "full" and "conv" are the two supported
    choices."""

    var_rank: Rank = "auto"
    """Observation-noise projection rank: full, explicit integer, or auto = ceil(d_model / 8)."""

    # --- projections / normalization --------------------------------------
    qk_norm: bool = True
    """L2-normalize the observation map k (key) and readout q (query) per token.
    Helps when stacking many layers."""

    bias: bool = False
    """Use bias terms in the linear projections."""

    # --- short conv -------------------------------------------------------
    use_conv: bool = True
    """Apply a depthwise causal conv1d after the input projection (Mamba-style)."""

    conv_kernel_size: int = 4
    """Kernel size of the causal conv."""

    conv_activation: Literal["silu", "relu", "gelu"] = "silu"
    """Activation applied after the causal conv."""

    # --- gating / skip -----------------------------------------------------
    use_gating: bool = True
    """Project a parallel gate branch in in_proj and multiply it into the SSM output
    (element-wise multiplicative gating)."""

    gating_activation: Literal["silu", "gelu", "relu"] = "silu"
    """Gate activation."""

    use_lambda_skip: bool = True
    """Add a learned λ-weighted skip connection from the post-conv activations."""

    lambda_skip_mode: Literal["scalar", "vector"] = "scalar"
    """Whether the λ skip weight is a scalar or per-channel vector."""

    lambda_skip_init: float = -1.0
    """Initial value of the λ skip weight."""

    # --- probabilistic outputs --------------------------------------------
    return_variance: bool = False
    """Also return the propagated output variance (needed for the reparametrisation
    trick / multi-sample losses)."""

    decode_from_prior: bool = False
    """Output the one-step-ahead prior prediction instead of the filtered posterior."""

    # --- selective (input-dependent) dynamics -------------------------------
    selective: bool = False
    """False selects static exact-init KLA; True selects Kalman–Bucy KLA in build_mixer."""

    selective_rank: Optional[int] = None
    """Bottleneck for selective dynamics only; None = ceil(d_model / 8).
    Sensor bottlenecks are controlled independently by value_rank and var_rank."""

    norm_softplus_c: float = 0.0
    """Bias c of the normalized-softplus clock gain."""

    # --- numerics ----------------------------------------------------------

    # --- hardware / speed tricks -------------------------------------------
    backend: Backend = "auto"
    """Auto selects the appropriate static or fused Kalman–Bucy CUDA scan
    on supported CUDA inputs and PyTorch otherwise. Explicit CUDA backends
    require d_state <= 64. Carried-state execution uses the PyTorch path."""

    eval_backend: Optional[Backend] = None
    """Override backend when autograd is off. None uses backend everywhere."""

    scan_impl: ScanImpl = "auto"
    """Parallel-scan implementation used by the torch backend.
    "associative" = torch._higher_order_ops.associative_scan,
    "doubling" = vectorized Hillis-Steele doubling, "sequential" = reference loop."""

    mobius_impl: MobiusImpl = "linear"
    """Precision-scan representation for the PyTorch reference: linear or log space. CUDA uses linear space."""

    checkpoint_ssm: bool = False
    """Recompute the SSM scan in backward (activation checkpointing) to save memory.

    In ``KLASelectiveLayer`` the checkpoint also covers the per-token dynamics
    (``_compute_aq``): a_bar / p_bar are ``[B, L, M, S]`` there, and every
    tensor on the way to them would otherwise be kept for backward -- at
    d_model 512, T 512, batch 128 that is ~6 GiB per layer even on the factored
    sigma2 path, ~20 GiB on the generic one. With the flag only ``z`` is kept."""

    @classmethod
    def exact(cls, **kwargs) -> "KLAConfig":
        """Build a static exact-init configuration with explicit caller overrides."""
        return cls(selective=False, **kwargs)

    @classmethod
    def kalman_bucy(cls, **kwargs) -> "KLAConfig":
        """Build a Kalman–Bucy configuration; the clock starts at unit gain."""
        return cls(selective=True, **kwargs)

    def __post_init__(self) -> None:
        self.validate()

    def validate(self) -> None:
        """Reject unsupported variants before allocating model parameters.

        Layers repeat this check because dataclass configurations are mutable.
        """
        unexpected = set(vars(self)) - {field.name for field in dataclasses.fields(self)}
        if unexpected:
            raise ValueError(f"Unknown configuration fields: {', '.join(sorted(unexpected))}")
        fixed = {
            "discretization": "ou", "decay_a_init_mode": "unit",
            "process_noise_coupling": "exact", "process_noise_param": "sigma2",
            "process_noise_mode": "learned", "reference_prior": True,
        }
        for name, expected in fixed.items():
            actual = getattr(self, name)
            if actual != expected or (isinstance(expected, bool) and type(actual) is not bool):
                raise ValueError(
                    f"{name}={actual!r} is not supported in this release; "
                    f"use {name}={expected!r}. Only exact-init KLA and Kalman–Bucy KLA are supported."
                )
        if self.sigma2_min not in (None, 0.0):
            raise ValueError("sigma2_min must be 0.0 or None to preserve exact initialization")
        if type(self.selective) is not bool or type(self.dt_init_per_cell) is not bool:
            raise ValueError("selective and dt_init_per_cell must be booleans")
        if not isinstance(self.d_state, int) or isinstance(self.d_state, bool) or self.d_state <= 0:
            raise ValueError("d_state must be a positive integer")
        if not math.isfinite(self.expand) or self.expand <= 0:
            raise ValueError("expand must be finite and positive")
        lo, hi = self.process_noise_kappa_min, self.process_noise_kappa_max
        if not (math.isfinite(lo) and math.isfinite(hi) and 0 < lo <= hi):
            raise ValueError("need finite 0 < process_noise_kappa_min <= process_noise_kappa_max")
        if self.dt_init_mode == "loguniform":
            lo, hi, floor = self.dt_min, self.dt_max, self.dt_init_floor
            if not (all(math.isfinite(v) for v in (lo, hi, floor)) and 0 < floor <= lo <= hi):
                raise ValueError("need finite 0 < dt_init_floor <= dt_min <= dt_max")
        elif self.dt_init_mode == "halflife":
            lo, hi = self.halflife_min, self.halflife_max
            if not (math.isfinite(lo) and math.isfinite(hi) and 0 < lo <= hi):
                raise ValueError("need finite 0 < halflife_min <= halflife_max")
            if not self.dt_init_per_cell:
                raise ValueError("halflife initialization in this release requires dt_init_per_cell=True")
        else:
            raise ValueError("dt_init_mode must be 'loguniform' or 'halflife'")
        if not math.isfinite(self.norm_softplus_c):
            raise ValueError("norm_softplus_c must be finite")
        if self.selective_rank is not None and (
            not isinstance(self.selective_rank, int) or isinstance(self.selective_rank, bool)
            or self.selective_rank <= 0
        ):
            raise ValueError("selective_rank must be a positive integer or None")
        for name in ("backend", "eval_backend"):
            value = getattr(self, name)
            if value not in get_args(Backend) and not (name == "eval_backend" and value is None):
                raise ValueError(f"{name}={value!r} is not in this release of kla")


    def d_inner(self, d_model: int) -> int:
        return int(self.expand * d_model)

@dataclasses.dataclass
class ModelConfig:
    """High-level sequence model: embedding + N blocks (mixer [+ MLP]) + LM head."""

    vocab_size: int = 50304
    d_model: int = 512
    n_layers: int = 6

    mlp: Literal["none", "swiglu", "gelu"] = "swiglu"
    """Channel mixer interleaved after each sequence mixer. "none" = mixer-only stack
    (the original MAD setups alternate mixer/swiglu)."""

    mlp_ratio: float = 4.0
    norm_eps: float = 1e-5
    tie_embeddings: bool = False
    logit_softcap: Optional[float] = None
    """Optional tanh soft-capping of the output logits."""
