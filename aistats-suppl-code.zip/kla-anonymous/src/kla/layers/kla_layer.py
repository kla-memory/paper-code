"""Unified Kalman Linear Attention layer.

Static exact-init KLA configured by :class:`kla.configs.KLAConfig`:

    x [B,L,D] → in_proj → (z, gate) [B,L,d_inner]
    z → causal conv → sensor_proj → (v, log σ²_v, k, q)   (paper notation)
    a, p, Δ → static (time-invariant) discrete dynamics (a_bar, p_bar)
    → KLA scan (information-form Kalman filter)  → y [B,L,d_inner]
    y → λ-skip + gating → out_proj → [B,L,D]

Projections follow the KLA paper: ``v`` is the observed value, ``σ²_v`` its
per-token observation-noise variance (via softplus of ``log σ²_v``), ``k`` the
observation map (key), and ``q`` the readout (query). ``qk_norm`` l2-normalizes
``k`` and ``q``. The scan op (:func:`kla.ops.kla_scan`) takes the same paper
notation ``(v, Λ^v, k, q, a, p)`` and folds the value into its natural
parameter ``v·Λ^v`` internally.

The heavy lifting (the parallel filter scan) is delegated to
:func:`kla.ops.kla_scan`, which dispatches on ``config.backend``.
"""

from __future__ import annotations

import math
import warnings
from typing import NamedTuple, Optional, get_args

import torch
import torch.nn as nn
import torch.nn.functional as F

from kla.configs import Backend, KLAConfig
from kla.layers.common import (
    CausalConv1d,
    p_exact_init,
    get_activation,
    inv_softplus_dt_init,
    kappa_init,
    halflife_dt_init,
    l2_norm,
)
from kla.ops import KLAState, kla_scan, kla_step


def _inv_softplus(y: float) -> float:
    """x such that softplus(x) == y, for y > 0."""
    return math.log(math.expm1(y))



class KLALayerState(NamedTuple):
    """Full recurrent state of one layer: conv window + filter state."""

    conv: Optional[torch.Tensor]  # [B, d_inner, K-1]
    ssm: KLAState  # (lam, eta), each [B, d_inner, d_state]


class KLALayer(nn.Module):
    def __init__(self, d_model: int, config: KLAConfig | None = None):
        super().__init__()
        config = config if config is not None else KLAConfig()
        config.validate()
        self.config = config
        self.d_model = d_model
        self.d_inner = config.d_inner(d_model)
        self.d_state = config.d_state
        # Names of parameters excluded from weight decay. Declared by the layer
        # (the owner of their meaning), consumed by trainers via
        # ``no_weight_decay()``. Kept as names because tensor attributes do not
        # survive FSDP/DTensor wrapping or Parameter replacement.
        self._no_weight_decay_names: list[str] = []

        M, S = self.d_inner, self.d_state

        proj_out = self.d_inner * 2 if config.use_gating else self.d_inner
        self.in_proj = nn.Linear(d_model, proj_out, bias=config.bias)

        self.conv = (
            CausalConv1d(self.d_inner, config.conv_kernel_size, config.conv_activation)
            if config.use_conv
            else None
        )

        # Sensor projection → v (M), log σ²_v (M), k (S), q (S).
        #
        # The two d_inner-wide signals (v and log σ²_v) can each be emitted at
        # full width, through a low-rank bottleneck, or -- for v only -- not at
        # all (v = z, Mamba's move). Only the WIDTHS of this one Linear change;
        # the four outputs keep their shapes, so nothing downstream of here
        # (scan, backward, any backend) is affected.
        auto_rank = math.ceil(d_model / 8)
        value_rank, var_rank = config.value_rank, config.var_rank
        if config.block_type is not None:
            if config.block_type not in ("plain", "mamba"):
                raise ValueError("block_type must be 'plain' or 'mamba'")
            expected = (("full", "full") if config.block_type == "plain"
                        else ("conv", "auto"))
            # The historical defaults are accepted as an unspecified value so
            # KLAConfig(block_type="mamba") remains concise. Any non-default
            # rank is an intentional override and must agree with the preset.
            if ((value_rank, var_rank) != ("full", "full")
                    and (value_rank, var_rank) != expected):
                raise ValueError(
                    f"block_type={config.block_type!r} fixes "
                    f"value_rank={expected[0]!r}, var_rank={expected[1]!r}; "
                    f"got value_rank={value_rank!r}, var_rank={var_rank!r}"
                )
            value_rank, var_rank = expected
        self.block_type = config.block_type or (
            "mamba" if (value_rank, var_rank) == ("conv", "auto") else "plain"
        )
        self._value_rank = auto_rank if value_rank == "auto" else value_rank
        self._var_rank = auto_rank if var_rank == "auto" else var_rank

        # Width this projection emits for each of the two wide signals.
        self._w_value = 0 if self._value_rank == "conv" else (
            M if self._value_rank == "full" else int(self._value_rank)
        )
        self._w_var = M if self._var_rank == "full" else int(self._var_rank)

        self.sensor_proj = nn.Linear(
            self.d_inner, self._w_value + self._w_var + 2 * S, bias=config.bias
        )
        # Up-projections, present only for the low-rank settings.
        self.value_expand = (
            nn.Linear(int(self._value_rank), M, bias=config.bias)
            if self._value_rank not in ("full", "conv") else None
        )
        self.var_expand = (
            nn.Linear(int(self._var_rank), M, bias=config.bias)
            if self._var_rank != "full" else None
        )
        # Silent-sensor baseline r0 (KLAConfig.obs_noise_init): a per-channel
        # bias on the log-variance pre-activation. Config-gated so the tensor is
        # absent -- and the state_dict unchanged -- when the knob is off.
        self.obs_noise_bias: Optional[nn.Parameter] = None
        if config.obs_noise_init is not None:
            r0, lo, hi = self._obs_noise_r0(), config.obs_var_min, config.obs_var_max
            if not (r0 > lo) or (hi is not None and r0 > hi):
                raise ValueError(
                    f"obs_noise_init={r0!r} must lie in (obs_var_min={lo!r}, "
                    f"obs_var_max={hi!r}]: softplus(.) + obs_var_min cannot reach it."
                )
            self.obs_noise_bias = nn.Parameter(torch.empty(M))
            self._mark_no_weight_decay("obs_noise_bias")
        # Discretization step Δ: static learned parameter (paper: a, p time-invariant).
        self.delta = nn.Parameter(torch.empty(M, S))
        self._mark_no_weight_decay("delta")

        if config.selective and type(self) is KLALayer:
            raise ValueError("selective=True requires build_mixer or KLASelectiveLayer, not KLALayer.")
        for field in ("backend", "eval_backend"):
            name = getattr(config, field)
            if name is not None and name not in get_args(Backend):
                raise ValueError(
                    f"{field}={name!r} is not in this release of kla; choose one of {get_args(Backend)}"
                )
            if not (name is not None and name.startswith("cuda")):
                continue
            from kla.ops.cuda_backend import supports_prior_precision  # lazy import

            if not supports_prior_precision(name):
                # The v3-family and selective kernels take the prior natively; the older ones
                # hard-code lambda_0 = 1 in their Mobius readout. Fail here rather than mid-forward
                # (for eval_backend that would be the first validation, possibly hours in).
                raise ValueError(
                    f"{field}={name!r} runs only the unit prior lambda_0 = 1, but this "
                    "layer requires an exact reference prior. Use a supported "
                    "CUDA backend, 'torch' or 'auto'."
                )
        self.register_buffer(
            "initial_precision", torch.empty(M, S)
        )

        # Continuous-time transition: a = -exp(lambda_log) (always negative)
        self.lambda_log = nn.Parameter(torch.empty(M, S))
        self._mark_no_weight_decay("lambda_log")

        self.register_buffer("sigma2_floor", torch.tensor(0.0, dtype=torch.float32))
        self.sigma2_log = nn.Parameter(torch.empty(M, S))
        self._mark_no_weight_decay("sigma2_log")

        if config.use_lambda_skip:
            if config.lambda_skip_mode == "vector":
                self.lambda_skip = nn.Parameter(torch.empty(M))
            else:
                self.lambda_skip = nn.Parameter(torch.empty(()))
            # Residual gain, the analogue of Mamba's D (which FLA/mamba_ssm tag
            # the same way). Decay would pull it from lambda_skip_init toward 0,
            # i.e. switch the skip path off; a gain has no capacity to regularize.
            self._mark_no_weight_decay("lambda_skip")
        else:
            self.lambda_skip = None

        self.gate_act = get_activation(config.gating_activation) if config.use_gating else None
        self.out_proj = nn.Linear(self.d_inner, d_model, bias=config.bias)

        self.reset_parameters()

    def _load_from_state_dict(self, state_dict, prefix, local_metadata, strict,
                              missing_keys, unexpected_keys, error_msgs):
        # Never silently reinterpret a shifted-variance or unit-prior checkpoint.
        floor = state_dict.get(prefix + "sigma2_floor")
        if floor is not None and not floor.is_meta and torch.count_nonzero(floor).item():
            error_msgs.append("This release requires a zero sigma2_floor checkpoint")
        super()._load_from_state_dict(
            state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs
        )


    # -- optimizer declaration ------------------------------------------------
    # The layer owns the *meaning* of its parameters (timescale, noise variance,
    # residual gain), so it declares which ones must not be weight-decayed. The
    # trainer owns the *policy* (which optimizer, which LR) and consumes this via
    # ``no_weight_decay()`` -- the same convention timm models use, which its
    # optimizer factory discovers with ``hasattr(model, "no_weight_decay")``.
    # ``kla.optim.split_decay_parameters`` walks a whole model this way.

    def _mark_no_weight_decay(self, name: str) -> None:
        """Declare ``self.<name>`` as excluded from weight decay.

        Sets the Mamba/FLA-style ``_no_weight_decay`` attribute for consumers
        that only read tags, and records the name for consumers that need
        something FSDP/DTensor wrapping and Parameter replacement cannot lose.
        Idempotent, so a subclass may re-declare a parameter it rebuilds.
        """
        param = getattr(self, name)
        if not isinstance(param, nn.Parameter):
            raise TypeError(f"{name!r} is not a learnable parameter of {type(self).__name__}")
        param._no_weight_decay = True
        if name not in self._no_weight_decay_names:
            self._no_weight_decay_names.append(name)

    def no_weight_decay(self, prefix: str = "") -> set[str]:
        """Fully qualified names of this layer's parameters that must not be
        weight-decayed. ``prefix`` is the layer's own qualified name plus a
        trailing dot, as ``nn.Module.named_modules`` would yield it."""
        return {prefix + name for name in self._no_weight_decay_names}

    def _check_phi0_assumption(self) -> None:
        """Warn when the configured sensors don't pin phi0 = E[phi] = 1.

        The exact process-noise initializer (see
        ``KLAConfig.obs_noise_init``) is derived once, at the reference point
        phi0 = 1, and needs ``qk_norm=True`` + ``obs_noise_init="auto"`` for
        that to hold exactly rather than approximately: qk_norm gives
        E[k_s^2] = 1/S, and ``obs_noise_init="auto"`` pins Lambda^v = S for
        every token (see ``_reset_obs_noise_head``), so E[phi] = 1 by
        construction. Without both, phi0 is whatever the (untrained) sensors
        happen to produce -- not wrong, just not exactly 1 -- so this warns
        rather than raising."""
        cfg = self.config
        if cfg.qk_norm and cfg.obs_noise_init == "auto":
            return
        missing = []
        if not cfg.qk_norm:
            missing.append("qk_norm=True")
        if cfg.obs_noise_init != "auto":
            missing.append('obs_noise_init="auto"')
        warnings.warn(
            f"KLALayer's process-noise initializer assumes phi0 = E[phi] = 1, "
            f"which holds exactly only under qk_norm=True and "
            f"obs_noise_init=\"auto\". This config is missing {' and '.join(missing)}, "
            f"so phi0 will differ from 1 for the actual sensors.",
            stacklevel=2,
        )

    @torch.no_grad()
    def reset_parameters(self):
        """Initialize the exact reference bank, including meta-device construction."""
        cfg = self.config
        cfg.validate()
        for name in self._no_weight_decay_names:
            self._mark_no_weight_decay(name)
        self._check_phi0_assumption()
        self.sigma2_floor.zero_()
        M, S = self.d_inner, self.d_state
        for mod in self.modules():
            if isinstance(mod, (nn.Linear, CausalConv1d)):
                mod.reset_parameters()
        self.lambda_log.zero_()
        self._init_kappa = None
        if cfg.dt_init_mode == "halflife":
            self._init_kappa = kappa_init((M, S), cfg)
            delta0, _ = halflife_dt_init(
                cfg.halflife_min, cfg.halflife_max, self._init_kappa, torch.ones(M, S)
            )
            self.delta.copy_(delta0)
        else:
            self.delta.copy_(inv_softplus_dt_init(
                M, S, cfg.dt_min, cfg.dt_max, cfg.dt_init_floor, cfg.dt_init_per_cell
            ))
        self._reset_exact_process_noise()
        if self.lambda_skip is not None:
            self.lambda_skip.fill_(cfg.lambda_skip_init)
        self._reset_obs_noise_head()
        self._init_kappa = None

    def _draw_kappa(self, u: torch.Tensor) -> torch.Tensor:
        """Reuse the horizon initializer's kappa draw for noise and precision."""
        k = getattr(self, "_init_kappa", None)
        return (k if k is not None else kappa_init(tuple(u.shape), self.config)).to(u)

    def _obs_noise_r0(self) -> Optional[float]:
        """``obs_noise_init`` resolved to a float (``"auto"`` = 1/d_state)."""
        r0 = self.config.obs_noise_init
        if r0 is None:
            return None
        return 1.0 / self.d_state if r0 == "auto" else float(r0)

    @torch.no_grad()
    def _effective_r_eff(self) -> float:
        """Per-cell observation variance sigma_v / k_s^2 = 1/phi0 the coupled/exact
        init is referenced to (``process_noise_r0``). ``"auto"``: sigma_v0 over
        E[k_s^2] = 1/d_state, exactly under qk_norm, else the phi0 = 1 reference
        pinned by Task 1 (``_check_phi0_assumption`` already warns when that
        isn't exact for the actual sensors) rather than measured by sampling a
        forward pass. Runs AFTER the sensor head has been initialised."""
        r0 = self.config.process_noise_r0
        if r0 != "auto":
            return float(r0)
        sigma_v0 = self._obs_noise_r0()
        if sigma_v0 is None:
            sigma_v0 = math.log(2.0) + self.config.obs_var_min   # softplus(0) + floor
        k2_mean = 1.0 / self.d_state
        return sigma_v0 / k2_mean

    def _inverse_discretize_p(self, p_bar: torch.Tensor, delta: torch.Tensor, a: torch.Tensor):
        """Continuous diffusion giving p_bar under OU discretization."""
        lam_pos = a.abs().clamp_min(1e-8)
        return p_bar * (2.0 * lam_pos) / (-torch.expm1(-2.0 * lam_pos * delta))

    @torch.no_grad()
    def _reset_exact_process_noise(self):
        a = -torch.exp(self.lambda_log.float())
        delta = F.softplus(self.delta.float()) + 1e-7
        u = a.abs() * delta
        kappa = self._draw_kappa(u)
        phi0 = 1.0 / self._effective_r_eff()
        self.initial_precision.copy_(phi0 / (-torch.expm1(-kappa * u)))
        p_bar = p_exact_init(u, kappa, phi0=phi0)
        self._write_sigma2_from_p(self._inverse_discretize_p(p_bar, delta, a))


    @torch.no_grad()
    def _write_sigma2_from_p(self, p: torch.Tensor):
        lam_pos = self.lambda_log.float().exp()
        sigma2 = p.to(lam_pos) / (2.0 * lam_pos)
        self.sigma2_log.copy_(sigma2.clamp_min(1e-30).log())



    def _sigma2(self) -> torch.Tensor:
        """Learned positive OU stationary variance."""
        return torch.exp(self.sigma2_log.float())

    @torch.no_grad()
    def _reset_obs_noise_head(self):
        """Silence the input-dependent part of the observation-noise head and
        pin its baseline to ``obs_noise_init`` (no-op when that knob is off).

        Zero the OUT projection, never the in (the LoRA/ReZero shape the
        selective residual also uses): with the low-rank head that is
        ``var_expand.weight``; with ``var_rank="full"`` there is no separate
        out projection, so the sigma rows of ``sensor_proj`` are zeroed instead.
        Either way the bias alone sets sigma_v, so softplus(b) + floor == r0 for
        every token. ``_no_reinit`` keeps SequenceModel's init walk from
        re-randomising the zeroed weight (under ``full`` that flag has to sit on
        the whole ``sensor_proj.weight``, so v/k/q rows keep this layer's Kaiming
        init there rather than the walk's normal(0.02)). With ``bias=True`` the
        head's bias is zeroed and flagged the same way.
        """
        if self.obs_noise_bias is None:
            return
        cfg = self.config
        self.obs_noise_bias.fill_(_inv_softplus(self._obs_noise_r0() - cfg.obs_var_min))
        if self.var_expand is not None:
            nn.init.zeros_(self.var_expand.weight)
            self.var_expand.weight._no_reinit = True
            head_bias = self.var_expand.bias
        else:
            lo, hi = self._w_value, self._w_value + self._w_var
            self.sensor_proj.weight[lo:hi].zero_()
            self.sensor_proj.weight._no_reinit = True
            head_bias = self.sensor_proj.bias
        # With bias=True the projection's own bias would still add to obs_noise_bias
        # (and move sigma_v off r0), so it is zeroed and protected like the weight.
        # Under "full" the flag covers the whole tensor, so zero all of it: the v/k/q
        # rows then keep what the model's init walk would have set (zeros) anyway.
        if head_bias is not None:
            nn.init.zeros_(head_bias)
            head_bias._no_reinit = True

    # ------------------------------------------------------------------ state

    def _scan_backend(self) -> str:
        """Use eval_backend when gradients are disabled, otherwise backend."""
        cfg = self.config
        if cfg.eval_backend is not None and not torch.is_grad_enabled():
            return cfg.eval_backend
        return cfg.backend

    def _initial_ssm_state(self, batch: int, device=None) -> KLAState:
        """Fresh posterior state, before prediction; filter state is float32."""
        if device is None:
            device = self.delta.device
        lam = self.initial_precision.to(device=device, dtype=torch.float32)
        lam = lam.unsqueeze(0).expand(batch, -1, -1).clone()
        return KLAState(lam=lam, eta=torch.zeros_like(lam))

    def init_state(self, batch: int, device=None, dtype=None) -> KLALayerState:
        if device is None:
            device = self.delta.device
        conv = self.conv.init_state(batch, device=device, dtype=dtype) if self.conv else None
        return KLALayerState(conv=conv, ssm=self._initial_ssm_state(batch, device=device))

    # ------------------------------------------------------------- parameters

    def _continuous_params(self, detach_rate: bool = True):
        """Continuous decay and diffusion implied by stationary variance.

        Consumers discretizing p must retain its rate gradient; diagnostics may
        detach it. The scan computes the OU variance directly in _compute_aq.
        """
        a = -torch.exp(self.lambda_log.float())
        rate = a.abs().detach() if detach_rate else a.abs()
        return a, 2.0 * rate * self._sigma2()

    def _discretize(self, delta: torch.Tensor, a: torch.Tensor, p: torch.Tensor):
        """OU transition and process variance, broadcast over cells."""
        a_bar = torch.exp(delta * a)
        lam_pos = a.abs().clamp_min(1e-8)
        p_bar = (p / (2.0 * lam_pos)) * (-torch.expm1(-2.0 * lam_pos * delta))
        return a_bar, p_bar

    @torch.no_grad()
    def dynamics_summary(self, phi0: Optional[float] = None) -> dict[str, torch.Tensor]:
        """Per-cell memory coordinates of the static tables, each ``[M, S]``.

        Reads the current parameters (init or trained) and solves the scalar
        Kalman fixed point at constant sensor information ``phi0`` (default: the
        ``1 / r_eff`` the coupled init is referenced to, i.e. 1 under the
        default sensor calibration). Returned keys:

        ``u``          leak per step ``|a| Delta``
        ``a_bar``      discrete decay ``exp(-u)``
        ``p_bar``      discrete process noise
        ``gain``       steady-state Kalman gain ``K*`` (fraction of a token written)
        ``kappa``      ``-log(1 - K*) / u``: register (<< 1), balanced (1), tracker (>> 1)
        ``half_life``  ``ln2 / ((1 + kappa) u)``, updates until a stored contribution halves
        ``precision``  steady-state posterior precision ``phi0 / K*``

        On an exact-coupled layer at init, ``kappa`` recovers the configured
        value and ``half_life`` the prescribed reference horizon. After training,
        they describe the learned tables at the reference observation information.
        For a selective layer this is the zero-controller (static) reference.
        """
        a_bar, p_bar = KLALayer._compute_aq(self)
        a_bar, p_bar = a_bar.double(), p_bar.double()
        delta = F.softplus(self.delta.double()) + 1e-7
        lam_pos = self.lambda_log.double().exp()
        u = lam_pos * delta
        r0 = (1.0 / phi0) if phi0 is not None else float(self._effective_r_eff())
        # Steady predicted variance s of  s = a_bar^2 s r0/(s+r0) + p_bar:
        #   s^2 + (r0 (1 - a_bar^2) - p_bar) s - p_bar r0 = 0
        b = r0 * (-torch.expm1(torch.log(a_bar) * 2.0)) - p_bar
        s = 0.5 * (-b + torch.sqrt(b * b + 4.0 * p_bar * r0))
        gain = (s / (s + r0)).clamp(0.0, 1.0 - 1e-12)
        kappa = -torch.log1p(-gain) / u
        half_life = math.log(2.0) / ((1.0 + kappa) * u)
        precision = (1.0 / r0) / gain.clamp_min(1e-300)
        f = lambda t: t.float()
        return {
            "u": f(u), "a_bar": f(a_bar), "p_bar": f(p_bar), "gain": f(gain),
            "kappa": f(kappa), "half_life": f(half_life), "precision": f(precision),
        }

    def _compute_aq(self):
        """Static OU transition and process variance, each [M, S]."""
        delta = F.softplus(self.delta.float()) + 1e-7
        a = -torch.exp(self.lambda_log.float())
        a_bar = torch.exp(delta * a)
        p_bar = self._sigma2() * (-torch.expm1(2.0 * delta * a))
        return a_bar, p_bar

    # ------------------------------------------------------------ projections

    def _project_sensors(self, z: torch.Tensor):
        """z [B, L, d_inner] → (v, lambda_v [B,L,M], k [B,L,S], q [B,L,S]).

        Paper notation: v = observed value, σ²_v = observation-noise variance,
        Λ^v = 1/σ²_v = value precision, k = observation map (key), q = readout
        (query). The value enters the filter only via v·Λ^v, but that fold is
        done inside the scan ops, so raw ``v`` is passed through here.
        """
        cfg = self.config
        M, S = self.d_inner, self.d_state

        v, log_sigma_v, k, q = torch.split(
            self.sensor_proj(z), [self._w_value, self._w_var, S, S], dim=-1
        )
        # v: taken straight from z ("conv"), lifted from a low-rank code, or
        # already full width. log σ²_v: lifted or already full width.
        if self._value_rank == "conv":
            v = z                       # [B, L, M] -- the width _w_value is 0
        elif self.value_expand is not None:
            v = self.value_expand(v)
        if self.var_expand is not None:
            log_sigma_v = self.var_expand(log_sigma_v)
        if self.obs_noise_bias is not None:
            log_sigma_v = log_sigma_v + self.obs_noise_bias

        if cfg.qk_norm:
            k = l2_norm(k)
            q = l2_norm(q)

        sigma_v = F.softplus(log_sigma_v.float()) + cfg.obs_var_min  # observation-noise variance
        if cfg.obs_var_max is not None:
            sigma_v = sigma_v.clamp_max(cfg.obs_var_max)

        lambda_v = 1.0 / sigma_v  # value precision Λ^v, [B, L, M]
        return v.float(), lambda_v, k.float(), q.float()

    # ----------------------------------------------------------------- compute

    def _run_ssm(self, z: torch.Tensor, ssm_state: KLAState | None):
        cfg = self.config
        # v = value, lambda_v = value precision Λ^v, k = key, q = readout (paper notation).
        v, lambda_v, k, q = self._project_sensors(z)
        a_bar, p_bar = self._compute_aq()  # discretized decay + process noise, [M, S]

        # A fresh sequence starts from the reference prior when the layer has one (else the
        # unit prior). It goes to the scan as `prior_precision`: native in the v3 CUDA kernels,
        # an equivalent initial state everywhere else.
        prior = self.initial_precision if ssm_state is None else None

        def scan(v, lambda_v, k, q, lam0, eta0):
            state = None if lam0 is None else KLAState(lam=lam0, eta=eta0)
            return kla_scan(
                v, lambda_v, k, q, a_bar, p_bar,
                initial_state=state,
                prior_precision=prior,
                backend=self._scan_backend(),
                scan_impl=cfg.scan_impl,
                mobius_impl=cfg.mobius_impl,
                decode_from_prior=cfg.decode_from_prior,
            )

        lam0 = ssm_state.lam if ssm_state is not None else None
        eta0 = ssm_state.eta if ssm_state is not None else None
        with torch.autocast(device_type=z.device.type, enabled=False):
            if cfg.checkpoint_ssm and torch.is_grad_enabled() and self.training:
                y, y_var, new_state = torch.utils.checkpoint.checkpoint(
                    scan, v, lambda_v, k, q, lam0, eta0,
                    use_reentrant=False,
                )
            else:
                y, y_var, new_state = scan(v, lambda_v, k, q, lam0, eta0)
        return y, y_var, new_state

    def _run_ssm_step(self, z: torch.Tensor, ssm_state: KLAState):
        """Single-token decode path. z: [B, 1, d_inner]."""
        cfg = self.config
        v, lambda_v, k, q = self._project_sensors(z)
        a_bar, p_bar = self._compute_aq()  # discretized decay + process noise, [M, S]
        with torch.autocast(device_type=z.device.type, enabled=False):
            y, y_var, new_state = kla_step(
                v[:, 0], lambda_v[:, 0], k[:, 0], q[:, 0], a_bar, p_bar,
                ssm_state, decode_from_prior=cfg.decode_from_prior,
            )
        return y.unsqueeze(1), y_var.unsqueeze(1), new_state

    def forward(
        self,
        x: torch.Tensor,
        state: KLALayerState | None = None,
        return_state: bool = False,
    ):
        """x: [B, L, d_model].

        Returns ``out`` — or ``(out, new_state)`` when ``return_state`` or a
        ``state`` is passed — where ``out`` is ``y`` or ``(y, y_var)`` when
        ``config.return_variance``.
        """
        cfg = self.config
        B, L, _ = x.shape
        emit_state = return_state or state is not None

        projected = self.in_proj(x)
        if cfg.use_gating:
            z, gate = projected.chunk(2, dim=-1)
        else:
            z, gate = projected, None

        conv_state = state.conv if state is not None else None
        if self.conv is not None:
            z, conv_state = self.conv(z, conv_state)

        residual = z

        ssm_state = state.ssm if state is not None else None
        if state is not None and L == 1:
            y, y_var, ssm_state = self._run_ssm_step(z, ssm_state)
        else:
            y, y_var, ssm_state = self._run_ssm(z, ssm_state)

        y = y.to(x.dtype)
        if y_var is not None:           # the log-linear scan carries no variance
            y_var = y_var.to(x.dtype)

        if self.lambda_skip is not None:
            y = y + self.lambda_skip * residual

        if gate is not None:
            g = self.gate_act(gate)
            y = y * g
            if y_var is not None:
                y_var = y_var * g.pow(2)

        out = self.out_proj(y)
        if cfg.return_variance:
            out_var = F.linear(y_var, self.out_proj.weight.pow(2))
            result = (out, out_var)
        else:
            result = out

        if emit_state:
            return result, KLALayerState(conv=conv_state, ssm=ssm_state)
        return result
