"""Kalman–Bucy KLA: a shared channel clock scales dynamics and information.

The learned per-cell OU tables and exact initializer are inherited from KLALayer.
One normalized-softplus clock per token and channel rescales the timestep and
observation precision. Process variance follows the OU map at learned sigma2.
"""
from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from kla.configs import KLAConfig
from kla.layers.kla_layer import KLALayer


class KLASelectiveLayer(KLALayer):
    """Kalman–Bucy clock with the static layer's sensor and output paths."""

    def __init__(self, d_model: int, config: KLAConfig | None = None):
        self._selective_ready = False
        config = config if config is not None else KLAConfig.kalman_bucy()
        config.validate()
        from kla.ops.kla_ops import FUSED_KERNEL_VERSIONS
        for field in ("backend", "eval_backend"):
            name = getattr(config, field)
            if name not in (None, "auto", "torch", *FUSED_KERNEL_VERSIONS):
                raise ValueError(f"{field}={name!r} is not a Kalman–Bucy backend")
            if name in FUSED_KERNEL_VERSIONS and config.decode_from_prior:
                raise ValueError("Selective CUDA does not support decode_from_prior; use auto or torch.")
        super().__init__(d_model, config)
        r = config.selective_rank if config.selective_rank is not None else math.ceil(d_model / 8)
        self.selective_rank = r
        self.sel_down = nn.Linear(self.d_inner, r, bias=False)
        self.sel_up_a = nn.Linear(r, self.d_inner, bias=True)
        self._selective_ready = True
        self.reset_parameters()

    def _load_from_state_dict(self, state_dict, prefix, local_metadata, strict,
                              missing_keys, unexpected_keys, error_msgs):
        # Older clock-only checkpoints allocated an unused second bottleneck.
        # Retain their active rows; reject checkpoints with a noise controller.
        if any(k.startswith(prefix + "sel_up_p.") for k in state_dict):
            error_msgs.append("Process-noise controller checkpoints are not supported")
        key = prefix + "sel_down.weight"
        weight = state_dict.get(key)
        if weight is not None and weight.shape == (2 * self.selective_rank, self.d_inner):
            state_dict[key] = weight[:self.selective_rank].clone()
        super()._load_from_state_dict(
            state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs
        )

    @torch.no_grad()
    def reset_parameters(self):
        super().reset_parameters()
        if getattr(self, "_selective_ready", False):
            nn.init.zeros_(self.sel_up_a.weight)
            nn.init.zeros_(self.sel_up_a.bias)
            self.sel_up_a.weight._no_reinit = True
            self.sel_up_a.bias._no_reinit = True

    def _clock_logits(self, z: torch.Tensor) -> torch.Tensor:
        z = z.to(self.sel_down.weight.dtype)
        return self.sel_up_a(self.sel_down(z)).float()

    @staticmethod
    def norm_softplus_gain(z: torch.Tensor, c: float) -> torch.Tensor:
        """Positive gain with G(0)=1 and d log G / dz at zero equal to one."""
        c_t = torch.as_tensor(c, dtype=z.dtype, device=z.device)
        sp_c = F.softplus(c_t)
        alpha = sp_c / torch.sigmoid(c_t)
        return F.softplus(c_t + alpha * z) / sp_c

    def _warp_information(self, z: torch.Tensor, lambda_v: torch.Tensor,
                          za: Optional[torch.Tensor] = None) -> torch.Tensor:
        if za is None:
            za = self._clock_logits(z)
        gain = self.norm_softplus_gain(za, self.config.norm_softplus_c)
        return lambda_v * gain.to(lambda_v.dtype)

    def _compute_aq(self, z: Optional[torch.Tensor] = None):
        """Clocked OU transition and process variance, each [B, L, M, S]."""
        if z is None:
            raise ValueError("Kalman–Bucy dynamics need the post-convolution sequence")
        gain = self.norm_softplus_gain(self._clock_logits(z), self.config.norm_softplus_c).unsqueeze(-1)
        delta_t = (F.softplus(self.delta.float()) + 1e-7) * gain
        a0 = -torch.exp(self.lambda_log.float())
        u = delta_t * a0
        return torch.exp(u), self._sigma2() * (-torch.expm1(2.0 * u))

    def _fused_backend(self, z=None, ssm_state=None) -> Optional[str]:
        """Resolve before materializing per-token dynamics; auto handles CPU/state."""
        from kla.ops.kla_ops import FUSED_KERNEL_VERSIONS

        backend = self._scan_backend()
        if backend == "auto":
            x = self.delta if z is None else z
            if (not x.is_cuda or x.dtype == torch.float64 or ssm_state is not None
                    or self.d_state > 64 or self.config.decode_from_prior):
                return None
            return "cuda_clock"
        return backend if backend in FUSED_KERNEL_VERSIONS else None

    def _run_ssm_fused(self, z: torch.Tensor, ssm_state, backend: str):
        """Fused clock dynamics: no per-token [B, L, M, S] allocation."""
        from kla.ops import kla_scan_fused

        if ssm_state is not None:
            raise NotImplementedError("the fused CUDA kernel does not take a carried state")
        v, lambda_v, k, q = self._project_sensors(z)
        za = self._clock_logits(z)
        lambda_v = self._warp_information(z, lambda_v, za=za)
        a0 = -torch.exp(self.lambda_log.float())
        delta = F.softplus(self.delta.float()) + 1e-7
        with torch.autocast(device_type=z.device.type, enabled=False):
            return kla_scan_fused(
                v, lambda_v, k, q, za, a0, self._sigma2(), delta,
                backend=backend, prior_precision=self.initial_precision,
                norm_softplus_c=self.config.norm_softplus_c,
            )

    def _run_ssm(self, z: torch.Tensor, ssm_state):
        from kla.ops import KLAState, kla_scan

        cfg = self.config
        fused = self._fused_backend(z, ssm_state)
        if fused is not None:
            return self._run_ssm_fused(z, ssm_state, fused)
        v, lambda_v, k, q = self._project_sensors(z)

        # Reference prior for a fresh sequence, as in KLALayer._run_ssm.
        prior = self.initial_precision if ssm_state is None else None

        # The per-token dynamics are built INSIDE the (optionally checkpointed)
        # closure: a_bar / p_bar and every intermediate on the way to them are
        # [B, L, M, S], and under checkpoint_ssm they are recomputed in backward
        # from z [B, L, M] instead of being kept -- the static layer has nothing
        # comparable, its dynamics are [M, S].
        def scan(z, v, lambda_v, k, q, lam0, eta0):
            a_bar, p_bar = self._compute_aq(z)
            lambda_v = self._warp_information(z, lambda_v)
            state = None if lam0 is None else KLAState(lam=lam0, eta=eta0)
            return kla_scan(
                v, lambda_v, k, q, a_bar, p_bar,
                initial_state=state,
                prior_precision=prior,
                backend=self._scan_backend(),
                scan_impl=cfg.scan_impl,
                mobius_impl=cfg.mobius_impl,
                decode_from_prior=cfg.decode_from_prior,
            )

        lam0 = ssm_state.lam if ssm_state is not None else None
        eta0 = ssm_state.eta if ssm_state is not None else None
        with torch.autocast(device_type=z.device.type, enabled=False):
            if cfg.checkpoint_ssm and torch.is_grad_enabled() and self.training:
                y, y_var, new_state = torch.utils.checkpoint.checkpoint(
                    scan, z, v, lambda_v, k, q, lam0, eta0, use_reentrant=False,
                )
            else:
                y, y_var, new_state = scan(z, v, lambda_v, k, q, lam0, eta0)
        return y, y_var, new_state

    def _run_ssm_step(self, z: torch.Tensor, ssm_state):
        from kla.ops import kla_step

        cfg = self.config
        v, lambda_v, k, q = self._project_sensors(z)
        lambda_v = self._warp_information(z, lambda_v)
        a_bar, p_bar = self._compute_aq(z)
        with torch.autocast(device_type=z.device.type, enabled=False):
            y, y_var, new_state = kla_step(
                v[:, 0], lambda_v[:, 0], k[:, 0], q[:, 0],
                a_bar[:, 0], p_bar[:, 0],
                ssm_state, decode_from_prior=cfg.decode_from_prior,
            )
        return y.unsqueeze(1), y_var.unsqueeze(1), new_state
