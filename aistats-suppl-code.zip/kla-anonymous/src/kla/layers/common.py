"""Shared building blocks for KLA and baseline layers."""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

_ACTIVATIONS = {
    "silu": F.silu,
    "gelu": F.gelu,
    "relu": F.relu,
}


def get_activation(name: str):
    try:
        return _ACTIVATIONS[name]
    except KeyError:
        raise ValueError(f"Unknown activation {name!r}; expected one of {sorted(_ACTIVATIONS)}") from None


def l2_norm(x: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    """L2-normalize over the last dim (pure torch; portable across platforms)."""
    return x / x.norm(dim=-1, keepdim=True).clamp_min(eps)


def inv_softplus_dt_init(
    M: int,
    S: int,
    dt_min: float,
    dt_max: float,
    dt_init_floor: float,
    per_cell: bool = True,
) -> torch.Tensor:
    """Sample log-uniform timesteps and store their inverse-softplus values.

    With per_cell=True, each (channel, state) cell has an independent draw.
    Otherwise, each channel shares one timestep across its states. Initial
    decay magnitude is one, so the passive-decay half-life is ln(2)/Delta;
    the filter's effective horizon also depends on observation information.
    Reject a floor above dt_min so it cannot silently truncate the range.
    """
    import math

    if dt_min < dt_init_floor:
        raise ValueError(
            f"dt_min={dt_min:g} is below dt_init_floor={dt_init_floor:g}, so the "
            f"clamp would discard it and Delta would start no lower than "
            f"{dt_init_floor:g} (half-life {math.log(2)/dt_init_floor:,.0f} tokens, "
            f"not {math.log(2)/dt_min:,.0f}). Lower dt_init_floor too."
        )
    u = torch.rand(M, S) if per_cell else torch.rand(M).unsqueeze(-1).expand(M, S)
    dt = torch.exp(u * (math.log(dt_max) - math.log(dt_min)) + math.log(dt_min))
    dt = dt.clamp_min(dt_init_floor)
    return dt + torch.log(-torch.expm1(-dt))


def inv_softplus(x: torch.Tensor) -> torch.Tensor:
    """Inverse of ``F.softplus`` for positive ``x`` (``log(expm1(x))``, stable)."""
    return x + torch.log(-torch.expm1(-x))


def halflife_dt_init(
    halflife_min: float,
    halflife_max: float,
    kappa: torch.Tensor,
    lam_pos: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Δ (pre-softplus) that realises a prescribed half-life per cell.

    Draws ``H`` log-uniform over ``[halflife_min, halflife_max]`` with the shape
    of ``kappa``, then ``u = ln2 / ((1 + kappa) H)`` and ``Delta = u / |a|``
    (``lam_pos = |a|``), so that under the exact process-noise init at the same
    ``kappa`` a stored contribution is attenuated by ``exp(-(1+kappa) u l)``
    and halves after exactly ``H`` updates (``KLAConfig.dt_init_mode``).
    Returns ``(delta_pre_softplus, H)``.
    """
    import math

    if not (0 < halflife_min <= halflife_max):
        raise ValueError(
            f"need 0 < halflife_min <= halflife_max (got {halflife_min!r}, {halflife_max!r})"
        )
    if halflife_min == halflife_max:          # a constant H: every cell the same horizon
        H = torch.full(tuple(kappa.shape), float(halflife_min)).to(kappa)
    else:
        H = log_uniform_init(tuple(kappa.shape), halflife_min, halflife_max).exp().to(kappa)
    u = math.log(2.0) / ((1.0 + kappa) * H)
    dt = u / lam_pos.to(u)
    return inv_softplus(dt), H




def log_uniform_init(shape: tuple[int, ...], lo: float, hi: float) -> torch.Tensor:
    """Draw uniformly in log space over [log(lo), log(hi)].

    Exponentiating the result gives a log-uniform positive value.
    """
    import math

    if not (0.0 < lo < hi):
        raise ValueError(f"need 0 < lo < hi, got lo={lo:g} hi={hi:g}")
    return torch.rand(*shape) * (math.log(hi) - math.log(lo)) + math.log(lo)




class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        x = x.float()
        x = x * torch.rsqrt(x.pow(2).mean(dim=-1, keepdim=True) + self.eps)
        return (x * self.weight.float()).to(dtype)


class CausalConv1d(nn.Module):
    """Depthwise causal conv over the time axis with explicit state handling.

    Input/output are [B, L, D]. The recurrent state is the last
    ``kernel_size - 1`` pre-conv inputs, shaped [B, D, kernel_size - 1].
    """

    def __init__(self, dim: int, kernel_size: int, activation: str = "silu", bias: bool = True):
        super().__init__()
        self.dim = dim
        self.kernel_size = kernel_size
        self.act = get_activation(activation)
        self.weight = nn.Parameter(torch.empty(dim, 1, kernel_size))
        self.bias = nn.Parameter(torch.empty(dim)) if bias else None
        self.reset_parameters()

    @torch.no_grad()
    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=5**0.5)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def init_state(self, batch: int, device=None, dtype=None) -> torch.Tensor:
        return torch.zeros(batch, self.dim, self.kernel_size - 1, device=device, dtype=dtype)

    def forward(self, x: torch.Tensor, conv_state: torch.Tensor | None = None):
        """Returns (y [B, L, D], new_conv_state)."""
        B, L, D = x.shape
        x_t = x.transpose(1, 2)  # [B, D, L]
        if conv_state is None:
            conv_state = self.init_state(B, device=x.device, dtype=x_t.dtype)
        x_pad = torch.cat((conv_state.to(x_t.dtype), x_t), dim=-1)
        y = F.conv1d(x_pad, self.weight, self.bias, groups=self.dim)
        new_state = x_pad[..., x_pad.shape[-1] - (self.kernel_size - 1):]
        return self.act(y).transpose(1, 2), new_state


class MLP(nn.Module):
    """Channel mixer: SwiGLU or plain GELU MLP."""

    def __init__(self, dim: int, ratio: float = 4.0, kind: str = "swiglu", bias: bool = False):
        super().__init__()
        hidden = int(dim * ratio)
        self.kind = kind
        if kind == "swiglu":
            hidden = int(2 * hidden / 3)
            self.w12 = nn.Linear(dim, 2 * hidden, bias=bias)
            self.w3 = nn.Linear(hidden, dim, bias=bias)
        elif kind == "gelu":
            self.w1 = nn.Linear(dim, hidden, bias=bias)
            self.w2 = nn.Linear(hidden, dim, bias=bias)
        else:
            raise ValueError(f"Unknown MLP kind {kind!r}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.kind == "swiglu":
            gate, up = self.w12(x).chunk(2, dim=-1)
            return self.w3(F.silu(gate) * up)
        return self.w2(F.gelu(self.w1(x)))


def kappa_init(shape: tuple[int, ...], cfg) -> torch.Tensor:
    """Constant kappa or independent log-uniform kappa values per cell."""
    lo, hi = cfg.process_noise_kappa_min, cfg.process_noise_kappa_max
    if lo <= 0:
        raise ValueError(f"process_noise_kappa_min must be > 0 (got {lo!r})")
    if hi < lo:
        raise ValueError(
            f"process_noise_kappa_max ({hi!r}) must be >= process_noise_kappa_min ({lo!r})"
        )
    if hi == lo:
        return torch.full(shape, float(lo))
    return log_uniform_init(shape, lo, hi).exp()


def p_exact_init(u: torch.Tensor, kappa: torch.Tensor, phi0: float = 1.0) -> torch.Tensor:
    """Discrete process noise p_bar at the exact scalar-DARE steady state.

    ``u = |a| * Delta`` is a cell's leak per step; ``kappa`` its role
    coordinate (the steady-state Kalman gain is ``K* = 1 - exp(-kappa u)``:
    kappa << 1 registers -- almost all forgetting is leak, not overwrite --
    kappa = 1 balances the two, kappa >> 1 tracks). ``phi0`` is the sensor
    information this is referenced to: phi0 = 1 is the fixed point pinned by
    construction under ``qk_norm=True`` + ``obs_noise_init="auto"`` (see
    ``KLALayer._check_phi0_assumption``); the observation variance per unit
    key energy the DARE is solved at is r0 = 1/phi0.

    Derivation. The scalar Kalman fixed point ``s = abar^2 s r0/(s+r0) + p_bar``
    at target gain ``K = s/(s+r0)`` and decay ``abar = exp(-u)`` gives, solved
    for p_bar (Eq. 4.5, exponential form -- this is what a direct DARE inverse
    looks like, and what a reader unfamiliar with the sinh identity below can
    check against a scalar Riccati solver):

        K = 1 - exp(-kappa u)
        p_bar = r0 * K * (1 / (1 - K) - abar^2)                        # Eq. 4.5

    Equation 4.8 rewrites this in sinh form. Writing ``c = kappa u`` and
    expanding ``K = 1-e^{-c}``, ``abar^2 = e^{-2u}``, then grouping the four
    resulting exponential terms into two symmetric pairs gives, EXACTLY the
    same value (verified both symbolically and numerically):

        p_bar = 4 * r0 * exp(-u) * sinh(c/2) * sinh(u + c/2)           # Eq. 4.8

    Evaluating that product literally is not overflow-safe: each ``sinh(x)``
    overflows float32 once ``x`` passes ~89 even when the whole expression fits
    (u=100, kappa=0.01 gives 1.72, not inf). Writing ``sinh(x) = e^x (1 - e^{-2x}) / 2``,
    the four ``e^{+-}`` factors combine analytically to ``e^{c}``, so the same
    value is computed as

        p_bar = r0 * expm1(c) * (-expm1(-(c + 2u)))

    -- Eq. 4.8 with the exponents merged before they are exponentiated. No factor
    overflows unless the answer itself does (c > ~88, a cell that forgets
    ``e^-88`` per step), there is no ``1/(1-K)`` to blow up as ``K -> 1``, and
    ``expm1`` keeps full relative accuracy as ``u -> 0`` where the naive
    exponential form cancels between two near-1 exponentials -- the regimes this
    initializer has to cover at once across a Delta ladder.
    """
    r0 = 1.0 / phi0
    c = kappa * u
    return r0 * torch.expm1(c) * (-torch.expm1(-(c + 2.0 * u)))
