"""Opt-in, sequential stability replay for the CUDA v3 precision/information path.

This is not kernel instrumentation: the parallel association tree, FMA rounding,
and backward intermediates are not reproduced. No hooks or training overhead.
"""
from __future__ import annotations

import torch

from kla.ops.kla_ops import EPS, P_MIN


class _Stats:
    def __init__(self, sample):
        self.low = sample.new_tensor(float("inf"))
        self.high = sample.new_tensor(float("-inf"))
        self.bad = torch.zeros((), device=sample.device, dtype=torch.int64)
        self.count = 0

    def add(self, x):
        finite = torch.isfinite(x)
        self.low = torch.minimum(self.low, x.masked_fill(~finite, float("inf")).amin())
        self.high = torch.maximum(self.high, x.masked_fill(~finite, float("-inf")).amax())
        self.bad += (~finite).sum()
        self.count += x.numel()

    def report(self):
        bad = self.bad.item()
        return dict(count=self.count, nonfinite=bad,
                    finite_min=self.low.item() if bad < self.count else None,
                    finite_max=self.high.item() if bad < self.count else None)


@torch.no_grad()
def diagnose_precision_information(v, lambda_v, k, a, p, *, prior_precision=None,
                                   dtype=torch.float32):
    """Return JSON-ready summaries from a detached, bounded-memory debug replay.

    Inputs are the *discretized scan inputs*: v/lambda_v [B,L,D], k [B,L,N],
    a = exp(-u) and p = Q [D,N]. prior_precision is optional [D,N]; eta0=0.
    Run on a representative batch (or explicit slices) outside the training
    hot path. All inputs must share a device. CPU replay is supported.

    The default float32 replay uses v3's Q/a² floors, trace-normalized Möbius
    composition, normalized homogeneous prior readout, and guarded eta coefficient. float64
    is an optional comparison with the same floors, not an unfloored oracle.
    Range summaries exclude nonfinites and count them separately. Floor counts
    count static cells; time-dependent counters count (batch,time,channel,state).
    No gradients, input mutation, or full [B,L,D,N] history is retained.
    """
    if dtype not in (torch.float32, torch.float64):
        raise ValueError("dtype must be float32 or float64")
    if v.ndim != 3 or lambda_v.shape != v.shape or k.ndim != 3 or k.shape[:2] != v.shape[:2]:
        raise ValueError("expected v/lambda_v [B,L,D] and k [B,L,N]")
    B, L, D = v.shape
    N = k.shape[-1]
    if min(B, L, D, N) < 1 or a.shape != (D, N) or p.shape != (D, N):
        raise ValueError("nonempty inputs and static a/p [D,N] required")
    inputs = [v, lambda_v, k, a, p]
    if prior_precision is not None:
        if prior_precision.shape != (D, N):
            raise ValueError("prior_precision must have shape [D,N]")
        inputs.append(prior_precision)
    if any(x.device != v.device for x in inputs):
        raise ValueError("all inputs must share a device")
    v, lambda_v, k, a, p = [x.detach().to(dtype=dtype) for x in inputs[:5]]
    prior = (torch.ones_like(a) if prior_precision is None
             else prior_precision.detach().to(dtype=dtype))
    names = ("phi", "denominator", "alpha_eta", "lambda", "eta", "mean",
             "mobius_raw", "mobius_prefix", "eta_prefix_product")
    stats = {name: _Stats(a) for name in names}
    input_stats = {}
    for name, x in zip(("v", "lambda_v", "k", "a", "Q", "prior_precision"),
                       (v, lambda_v, k, a, p, prior)):
        s = _Stats(a)
        s.add(x)
        input_stats[name] = s.report()
    a2_raw = a.square()
    a2, Q = a2_raw.clamp_min(EPS), p.clamp_min(P_MIN)
    prior_scale = prior.clamp_min(1)
    h1, h2 = prior / prior_scale, 1 / prior_scale
    lam = prior.expand(B, D, N)
    eta = torch.zeros_like(lam)
    one, zero = torch.ones_like(lam), torch.zeros_like(lam)
    A, C, F, H = one, zero, zero, one  # [[A,C],[F,H]]
    product = one
    run = torch.zeros_like(lam, dtype=torch.int64)
    longest = run.clone()
    counters = {name: torch.zeros((), device=a.device, dtype=torch.int64)
                for name in ("alpha_gt_one", "denominator_floor", "trace_floor",
                             "lambda_nonpositive", "prefix_denominator_nonpositive")}
    for t in range(L):
        phi = k[:, t, None, :].square() * lambda_v[:, t, :, None]
        r = (v[:, t] * lambda_v[:, t])[:, :, None] * k[:, t, None, :]
        den_raw = a2 + Q * lam
        den = den_raw.clamp_min(EPS)
        alpha = a / den
        expanding = alpha > 1
        run = torch.where(expanding, run + 1, 0)
        longest = torch.maximum(longest, run)
        counters["alpha_gt_one"] += expanding.sum()
        counters["denominator_floor"] += (den_raw < EPS).sum()
        # New leaf times old prefix, matching v3's unnormalized safe leaf.
        l11, l12 = 1 + phi * Q, phi * a2
        raw = torch.stack((l11*A + l12*F, l11*C + l12*H,
                           Q*A + a2*F, Q*C + a2*H))
        trace = raw[0] + raw[3]
        counters["trace_floor"] += (trace < EPS).sum()
        prefix = raw * trace.clamp_min(EPS).reciprocal()
        A, C, F, H = prefix.unbind(0)
        prefix_den = F * h1 + H * h2
        counters["prefix_denominator_nonpositive"] += (prefix_den <= 0).sum()
        lam = (A * h1 + C * h2) / prefix_den
        eta = alpha * eta + r
        product = alpha * product
        counters["lambda_nonpositive"] += (lam <= 0).sum()
        for name, x in zip(names, (phi, den_raw, alpha, lam, eta, eta/lam,
                                   raw, prefix, product)):
            stats[name].add(x)
    total = B * L * D * N
    counts = {name: x.item() for name, x in counters.items()}
    return {
        "mode": "sequential_v3_replay", "dtype": str(dtype),
        "shape": [B, L, D, N], "time_cell_count": total,
        "inputs": input_stats,
        "ranges": {name: s.report() for name, s in stats.items()},
        "counts": counts,
        "alpha_gt_one_fraction": counts["alpha_gt_one"] / total,
        "longest_expanding_run": longest.max().item(),
        "static_floors": {"cell_count": D*N,
                          "Q_below_floor": (p < P_MIN).sum().item(),
                          "a2_below_floor": (a2_raw < EPS).sum().item()},
    }
