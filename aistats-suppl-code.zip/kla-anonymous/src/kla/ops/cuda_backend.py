"""Static and fused Kalman–Bucy CUDA scans with explicit backup builds.

Static builds use v3 sources; selective builds use selective_fused sources.
All use CUB Mobius stitching and fast math.
The default builds additionally enable coalesced backward dh/dw atomics. Each build has
its own JIT cache. Both accept a reference prior and return a detached final
filter state. Carried-state scans and float64 reference work use torch.
CUDA scans require d_state <= 64 and a matching CUDA toolkit plus ninja.
"""

from __future__ import annotations

import functools
import glob
import os
from typing import Optional

import torch

from kla.ops.kla_ops import P_MIN, KLAState

_KERNELS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kernels", "cuda")

KERNEL_VERSIONS = ("static", "static_fast", "clock", "clock_fast")
DEFAULT_SELECTIVE_KERNEL_VERSION = "clock"
DEFAULT_KERNEL_VERSION = "static"      # what backend="cuda" selects
_V3_TREE = ("static", "static_fast")
SELECTIVE_VERSIONS: tuple[str, ...] = ()  # per-token kernels: not in this release
FUSED_VERSIONS = ("clock", "clock_fast")
_FINAL_STATE_VERSIONS = _V3_TREE          # the final state is the last-chunk boundary
_LAM0_ARG_VERSIONS = _V3_TREE             # the extension takes a trailing lam0 (prior precision)
PRIOR_PRECISION_VERSIONS = (*_V3_TREE, *FUSED_VERSIONS)  # accept a non-unit prior


def supports_prior_precision(backend: str) -> bool:
    """Whether ``kla_scan(..., backend=backend, prior_precision=...)`` runs natively in the
    kernel: the v3-family and selective CUDA backends (``"cuda"`` is ``DEFAULT_KERNEL_VERSION``)."""
    if backend == "cuda_selective":
        return DEFAULT_SELECTIVE_KERNEL_VERSION in PRIOR_PRECISION_VERSIONS
    if backend == "cuda":
        return DEFAULT_KERNEL_VERSION in PRIOR_PRECISION_VERSIONS
    return backend.startswith("cuda_") and backend[len("cuda_"):] in PRIOR_PRECISION_VERSIONS


def _csrc_dir(version: str) -> str:
    """Source directory for one kernel version (see the module docstring)."""
    if version not in KERNEL_VERSIONS:
        raise ValueError(
            f"Unknown CUDA kernel version {version!r}; expected one of {list(KERNEL_VERSIONS)}"
        )
    return os.path.join(_KERNELS_DIR, "selective_fused" if version in FUSED_VERSIONS else "v3")


def _cxx_std() -> str:
    """C++ standard for the JIT build. torch >= 2.13's extension headers need C++20
    (nvcc then fails on them under C++17); older torch builds were C++17 and some
    toolchains reject C++20, so keep 17 there. ``NVCC_APPEND_FLAGS=-std=...`` still
    overrides (nvcc takes the last ``-std``)."""
    import re

    m = re.match(r"(\d+)\.(\d+)", torch.__version__)
    major, minor = (int(m.group(1)), int(m.group(2))) if m else (0, 0)
    return "c++20" if (major, minor) >= (2, 13) else "c++17"


# Matches the original kla_matmul_scan_v2.1 setup.py / interface build flags
# (the -std flag is added per torch version by _nvcc_flags / _cxx_std).
_NVCC_FLAGS = [
    "-O3",
    "--use_fast_math",
    # cu13 toolchains commonly mix nvcc and cccl/runtime header minor versions
    # (e.g. nvcc 13.2 against torch's bundled cu13.0 redist) — skip CCCL's
    # CTK-version compat assertion, which only guards header/compiler skew.
    "-DCCCL_DISABLE_CTK_COMPATIBILITY_CHECK",
    "-U__CUDA_NO_HALF_OPERATORS__",
    "-U__CUDA_NO_HALF_CONVERSIONS__",
    "-U__CUDA_NO_BFLOAT16_OPERATORS__",
    "-U__CUDA_NO_BFLOAT16_CONVERSIONS__",
    "--expt-relaxed-constexpr",
    "--expt-extended-lambda",
]

def _nvcc_flags(version: str) -> list[str]:
    _csrc_dir(version)
    flags = [_NVCC_FLAGS[0], f"-std={_cxx_std()}", *_NVCC_FLAGS[1:],
             "--ptxas-options=-v", "-DKLA_MOBIUS_CUB_STITCH=1"]
    if version in ("static", "clock"):
        flags.append("-DKLA_BWD_COALESCED_ATOMICS=1")
    return flags


MAX_DSTATE = 64


def _extra_include_paths(version: str) -> list[str]:
    """Include dirs the build needs beyond CUDA_HOME.

    torch's extension headers pull in cusparse/cublas/… ; the matching redist
    headers ship under ``site-packages/nvidia/*/include`` (CUDA 12 and 13)
    (the system CUDA toolkit often omits them). CUDA 13 also moved
    the cub/cccl headers under ``$CUDA_HOME/include/cccl``; add it when present.
    """
    paths = [_csrc_dir(version)]
    site = os.path.dirname(os.path.dirname(torch.__file__))  # site-packages
    paths.extend(
        path for path in sorted(glob.glob(os.path.join(site, "nvidia", "*", "include")))
        if os.path.isdir(path)
    )
    cuda_home = os.environ.get("CUDA_HOME") or os.environ.get("KLA_CUDA_HOME")
    if cuda_home:
        cccl = os.path.join(cuda_home, "include", "cccl")
        if os.path.isdir(cccl):
            paths.append(cccl)
    return paths


def _clear_stale_lock(name: str, max_age_s: float = 600.0) -> None:
    """torch's JIT loader waits forever on ``<build_dir>/lock``. A process killed
    mid-compile leaves that lock behind with no ``.so``, and the next process then
    hangs silently. A lock older than ``max_age_s`` with no built module beside it
    is stale: remove the half-built directory so the build restarts."""
    import shutil
    import time

    root = os.environ.get("TORCH_EXTENSIONS_DIR")
    if not root:
        try:
            from torch.utils.cpp_extension import _get_build_directory  # type: ignore[attr-defined]
            root = os.path.dirname(_get_build_directory(name, verbose=False))
        except Exception:  # pragma: no cover
            return
    build = os.path.join(root, name)
    lock = os.path.join(build, "lock")
    if (os.path.exists(lock) and not glob.glob(os.path.join(build, "*.so"))
            and time.time() - os.path.getmtime(lock) > max_age_s):
        shutil.rmtree(build, ignore_errors=True)


@functools.cache
def _load_extension(version: str = DEFAULT_KERNEL_VERSION):
    """JIT-compile and cache one kernel version's extension (first use only).

    Each version gets its own extension name, so torch caches their builds
    separately and all versions can be loaded into the same process.
    """
    if os.environ.get("KLA_CUDA_HOME") and not os.environ.get("CUDA_HOME"):
        os.environ["CUDA_HOME"] = os.environ["KLA_CUDA_HOME"]

    csrc = _csrc_dir(version)
    sources = [
        os.path.join(csrc, f)
        for f in sorted(os.listdir(csrc))
        if f.endswith((".cu", ".cpp"))
    ] if os.path.isdir(csrc) else []
    if not sources:
        raise NotImplementedError(
            f"No CUDA kernel sources found under {csrc} — "
            "use backend='torch'."
        )

    from torch.utils.cpp_extension import load

    _clear_stale_lock(f"kla_matmul_scan_cuda_{version}" + ("_kb_v1" if version in FUSED_VERSIONS else ""))
    return load(
        name=f"kla_matmul_scan_cuda_{version}" + ("_kb_v1" if version in FUSED_VERSIONS else ""),
        sources=sources,
        extra_cuda_cflags=_nvcc_flags(version),
        extra_cflags=["-O3", f"-std={_cxx_std()}"],
        extra_include_paths=_extra_include_paths(version),
        verbose=os.environ.get("KLA_JIT_VERBOSE", "0") == "1",
    )


def _to_cuda_scan_layout(x: torch.Tensor) -> torch.Tensor:
    """Convert [B,L,C] to [B,C,L] with the kernel's strict unit time stride."""
    x = x.transpose(1, 2).contiguous()
    # contiguous() may be a no-op when L=1: PyTorch ignores singleton strides
    # for contiguity, but the native binding explicitly requires stride(-1)=1.
    if x.stride(-1) != 1:
        x = torch.empty(x.shape, dtype=x.dtype, device=x.device).copy_(x)
    return x


class _KLAMatmulScanFn(torch.autograd.Function):
    """Autograd wrapper over the vendored fwd/bwd CUDA kernels.

    Operates on the kernel's native layout: model-axis tensors ``[B, M, L]`` and
    state-axis tensors ``[B, S, L]`` (the caller transposes from ``[B, L, ...]``).
    """

    @staticmethod
    def forward(ctx, mu_sigma_inv, sigma_inv, h, w, a, q, lam0, version):
        ext = _load_extension(version)
        ctx.version = version  # backward must compile against the same kernel
        msi = _to_cuda_scan_layout(mu_sigma_inv)  # [B, M, L]
        si = _to_cuda_scan_layout(sigma_inv)
        h_t = _to_cuda_scan_layout(h)  # [B, S, L]
        w_t = _to_cuda_scan_layout(w)
        if version in SELECTIVE_VERSIONS:
            a = a.permute(0, 2, 3, 1).contiguous()  # [B,M,S,L]
            q = q.permute(0, 2, 3, 1).contiguous()
        else:
            a = a.contiguous()
            q = q.contiguous()

        # lam0: [M, S] prior precision (constant, no gradient) or an empty tensor = unit prior.
        # Only the v3 source tree takes it; the other trees keep their original signature.
        tail = (lam0,) if version in _LAM0_ARG_VERSIONS else ()
        y_t, yvar_t, mob_b, lin_b, lam_b = ext.fwd(msi, si, h_t, w_t, a, q, *tail)
        ctx.save_for_backward(msi, si, h_t, w_t, a, q, mob_b, lin_b, lam_b, lam0)
        # Final state (posterior precision, information) after the last token. The forward
        # writes both at every chunk end; the padded tail of the last chunk is the identity
        # in the Mobius and the linear scan, so the last chunk's boundary IS the state after
        # token L. Only the trees that pad this way are trusted; the older ones return None.
        if version in _FINAL_STATE_VERSIONS:
            lam_fin, eta_fin = lam_b[:, -1].clone(), lin_b[:, -1].clone()
            ctx.mark_non_differentiable(lam_fin, eta_fin)
        else:
            lam_fin = eta_fin = None
        return y_t.transpose(1, 2).contiguous(), yvar_t.transpose(1, 2).contiguous(), lam_fin, eta_fin

    @staticmethod
    def backward(ctx, dy, dyvar, _dlam_fin=None, _deta_fin=None):
        ext = _load_extension(ctx.version)
        msi, si, h_t, w_t, a, q, mob_b, lin_b, lam_b, lam0 = ctx.saved_tensors
        dy_t = _to_cuda_scan_layout(dy)
        dyvar_t = _to_cuda_scan_layout(dyvar)

        tail = (lam0,) if ctx.version in _LAM0_ARG_VERSIONS else ()
        dmsi, dsi, dh, dw, da, dq = ext.bwd(
            dy_t, dyvar_t, msi, si, h_t, w_t, a, q, mob_b, lin_b, lam_b, *tail
        )
        if ctx.version in SELECTIVE_VERSIONS:
            da = da.permute(0, 3, 1, 2).contiguous()
            dq = dq.permute(0, 3, 1, 2).contiguous()
        return (
            dmsi.transpose(1, 2).contiguous(),
            dsi.transpose(1, 2).contiguous(),
            dh.transpose(1, 2).contiguous(),
            dw.transpose(1, 2).contiguous(),
            da,
            dq,
            None,  # lam0 (a constant prior: no gradient)
            None,  # version (non-tensor)
        )


def _unsupported(msg: str) -> "NotImplementedError":
    return NotImplementedError(
        f"The CUDA KLA backend {msg}. Use backend='torch' for this case."
    )


def kla_scan_cuda(
    v: torch.Tensor,  # [B, L, M]
    lambda_v: torch.Tensor,  # [B, L, M]  value precision Λ^v
    k: torch.Tensor,  # [B, L, S]
    q: torch.Tensor,  # [B, L, S]  readout (query)
    a: torch.Tensor,  # [M, S] (static only)
    p: torch.Tensor,  # process noise
    initial_state: Optional[KLAState] = None,
    decode_from_prior: bool = False,
    kernel_version: str = DEFAULT_KERNEL_VERSION,
    prior_precision: Optional[torch.Tensor] = None,  # [M, S] lambda_0, v3 family only
):
    """CUDA KLA scan. Same return contract as :func:`kla.ops.kla_scan_torch`. The final
    state is returned (detached, float32, ``[B, M, S]``) by the v3 family and
    ``selective_v3``; the older kernels return ``None`` for it.

    ``kernel_version`` defaults to ``static``. Select
    ``static_fast`` explicitly to use the backup.
    """
    if not v.is_cuda:
        raise _unsupported("requires CUDA tensors")
    if kernel_version in SELECTIVE_VERSIONS:
        B, L, M = v.shape
        target = (B, L, M, k.shape[-1])
        for name, x in (("a", a), ("p", p)):
            if tuple(x.shape) not in ((M, k.shape[-1]), target):
                raise ValueError(f"{name} must have shape [M,S] or [B,L,M,S]")
        a = a.expand(target)
        p = p.expand(target)
    elif a.dim() != 2 or p.dim() != 2:
        raise _unsupported("expects a/p of shape [M, S]")
    if decode_from_prior:
        raise _unsupported("does not support decode_from_prior")
    if initial_state is not None:
        raise _unsupported("supports only the zero/unit initial state (no carried prefill state)")
    S = k.shape[2]
    if S > MAX_DSTATE:
        raise _unsupported(f"supports d_state <= {MAX_DSTATE} (got {S})")
    if prior_precision is not None:
        if kernel_version not in PRIOR_PRECISION_VERSIONS:
            raise _unsupported(
                f"kernel {kernel_version!r} runs only the unit prior lambda_0 = 1; "
                f"prior_precision needs one of {list(PRIOR_PRECISION_VERSIONS)}"
            )
        if tuple(prior_precision.shape) != (v.shape[2], S):
            raise ValueError(f"prior_precision must have shape [M, S] = {(v.shape[2], S)}, "
                             f"got {tuple(prior_precision.shape)}")
        # A constant of the scan: the kernel returns no gradient for it.
        lam0 = prior_precision.detach().to(device=v.device, dtype=torch.float32).contiguous()
    else:
        lam0 = torch.empty(0, device=v.device, dtype=torch.float32)  # empty = unit prior

    # Run in float32 (the kernel's native dtype). The kernel consumes the folded
    # information mean v·Λ^v, so pre-fold it here (the vendored kernel is unchanged).
    msi = (v.float() * lambda_v.float()).contiguous()  # v·Λ^v, [B, L, M]
    si = lambda_v.float().contiguous()  # Λ^v
    k3 = k.float().contiguous()  # [B, L, S]
    q = q.float().contiguous()
    a = a.float()
    # Floor the process noise exactly as _broadcast_ap does for the torch path.
    # The kernel has no internal guard, so a non-positive p makes (a² + p·λ) cross
    # zero and the Möbius recursion diverge to NaN -- where the torch path would
    # stay finite on the same input.
    p = p.float().clamp_min(P_MIN)

    # kernel_version is the last forward arg (backward returns None for it), so
    # both passes compile against the same kernel.
    y, y_var, lam_fin, eta_fin = _KLAMatmulScanFn.apply(msi, si, k3, q, a, p, lam0, kernel_version)
    return y, y_var, (None if lam_fin is None else KLAState(lam=lam_fin, eta=eta_fin))


class _KLAFusedScanFn(torch.autograd.Function):
    """Autograd wrapper over the fused time-varying kernels (``FUSED_VERSIONS``).

    Native layout as :class:`_KLAMatmulScanFn`; the dynamics arrive as the per-token
    controllers ``za`` ``[B, M, L]`` and the tables ``a0``/``sigma2``/``delta``
    ``[M, S]``, and their gradients come back in the same shapes -- nothing of size
    ``[B, L, M, S]`` exists on either side of the call.
    """

    @staticmethod
    def forward(ctx, mu_sigma_inv, sigma_inv, h, w, za, a0, sigma2, delta, lam0,
                version, norm_softplus_c, p_min):
        ext = _load_extension(version)
        ctx.version = version
        ctx.scalars = (norm_softplus_c, p_min)
        msi = _to_cuda_scan_layout(mu_sigma_inv)  # [B, M, L]
        si = _to_cuda_scan_layout(sigma_inv)
        h_t = _to_cuda_scan_layout(h)  # [B, S, L]
        w_t = _to_cuda_scan_layout(w)
        za_t = _to_cuda_scan_layout(za)  # [B, M, L]
        a0c, s2c, dlc = a0.contiguous(), sigma2.contiguous(), delta.contiguous()
        y_t, yvar_t, mob_b, lin_b, lam_b = ext.fwd(
            msi, si, h_t, w_t, za_t, a0c, s2c, dlc, lam0, norm_softplus_c, p_min)
        ctx.save_for_backward(msi, si, h_t, w_t, za_t, a0c, s2c, dlc, mob_b, lin_b, lam_b, lam0)
        lam_fin, eta_fin = lam_b[:, -1].clone(), lin_b[:, -1].clone()
        ctx.mark_non_differentiable(lam_fin, eta_fin)
        return y_t.transpose(1, 2).contiguous(), yvar_t.transpose(1, 2).contiguous(), lam_fin, eta_fin

    @staticmethod
    def backward(ctx, dy, dyvar, _dlam_fin=None, _deta_fin=None):
        ext = _load_extension(ctx.version)
        msi, si, h_t, w_t, za_t, a0c, s2c, dlc, mob_b, lin_b, lam_b, lam0 = ctx.saved_tensors
        dy_t = _to_cuda_scan_layout(dy)
        dyvar_t = _to_cuda_scan_layout(dyvar)
        dmsi, dsi, dh, dw, dza, da0, ds2, ddl = ext.bwd(
            dy_t, dyvar_t, msi, si, h_t, w_t, za_t, a0c, s2c, dlc,
            mob_b, lin_b, lam_b, lam0, *ctx.scalars)
        return (
            dmsi.transpose(1, 2).contiguous(),
            dsi.transpose(1, 2).contiguous(),
            dh.transpose(1, 2).contiguous(),
            dw.transpose(1, 2).contiguous(),
            dza.transpose(1, 2).contiguous(),
            da0, ds2, ddl,
            None,  # lam0 (constant prior)
            None, None, None,  # version and scalars
        )


def kla_scan_cuda_fused(
    v: torch.Tensor,  # [B, L, M]
    lambda_v: torch.Tensor,  # [B, L, M]
    k: torch.Tensor,  # [B, L, S]
    q: torch.Tensor,  # [B, L, S]
    za: torch.Tensor,  # [B, L, M]  controller pre-activation for a
    a0: torch.Tensor,  # [M, S] continuous decay, < 0
    sigma2: torch.Tensor,  # [M, S] stationary variance
    delta: torch.Tensor,  # [M, S] step
    *,
    kernel_version: str = DEFAULT_SELECTIVE_KERNEL_VERSION,
    prior_precision: Optional[torch.Tensor] = None,
    norm_softplus_c: float = 0.0,
):
    """Fused Kalman-Bucy dynamics with a normalized softplus timestep clock.

    Forms ``a = exp(delta * a0 * G(za))`` and ``p = sigma2 * (1-a**2)``
    in registers, with a numerical process-noise floor. Observation information
    must already include the same clock gain. Returns y, variance, and state.
    """
    if kernel_version not in FUSED_VERSIONS:
        raise ValueError(f"kernel_version must be one of {list(FUSED_VERSIONS)}, got {kernel_version!r}")
    if not v.is_cuda:
        raise _unsupported("requires CUDA tensors")
    B, L, M = v.shape
    S = k.shape[2]
    if S > MAX_DSTATE:
        raise _unsupported(f"supports d_state <= {MAX_DSTATE} (got {S})")
    for name, x, shape in (("za", za, (B, L, M)), ("a0", a0, (M, S)), ("sigma2", sigma2, (M, S)), ("delta", delta, (M, S))):
        if tuple(x.shape) != shape:
            raise ValueError(f"{name} must have shape {shape}, got {tuple(x.shape)}")
    if prior_precision is not None:
        if tuple(prior_precision.shape) != (M, S):
            raise ValueError(f"prior_precision must have shape [M, S] = {(M, S)}, got {tuple(prior_precision.shape)}")
        lam0 = prior_precision.detach().to(device=v.device, dtype=torch.float32).contiguous()
    else:
        lam0 = torch.empty(0, device=v.device, dtype=torch.float32)

    msi = (v.float() * lambda_v.float()).contiguous()
    si = lambda_v.float().contiguous()
    k3 = k.float().contiguous()
    q3 = q.float().contiguous()
    y, y_var, lam_fin, eta_fin = _KLAFusedScanFn.apply(
        msi, si, k3, q3, za.float(),
        a0.float(), sigma2.float(), delta.float(), lam0,
        kernel_version, float(norm_softplus_c), float(P_MIN))
    return y, y_var, KLAState(lam=lam_fin, eta=eta_fin)
