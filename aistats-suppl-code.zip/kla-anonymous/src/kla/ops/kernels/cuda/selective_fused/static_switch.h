#pragma once
#include "../v3/static_switch.h"
