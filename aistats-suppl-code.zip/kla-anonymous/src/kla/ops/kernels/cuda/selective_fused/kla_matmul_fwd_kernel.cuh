// Fused Kalman-Bucy clock dynamics and forward scan.
#pragma once

#include <cub/block/block_load.cuh>
#include <cub/block/block_store.cuh>
#include <cub/block/block_scan.cuh>

#include "kla_matmul_scan.h"
#include "kla_matmul_scan_common.h"
#include "kla_matmul_scan_ops.cuh"
#include "static_switch.h"

// =============================================================================
// Kernel traits
// =============================================================================
template<int kNThreads_, int kNItems_, bool kIsEvenLen_, typename input_t_>
struct KLA_Matmul_fwd_kernel_traits {
    static_assert(kNItems_ % 4 == 0);
    using input_t = input_t_;
    static constexpr int kNThreads = kNThreads_;
    static constexpr int kNItems   = kNItems_;
    static constexpr int kNBytes   = sizeof(input_t);
    static constexpr int kNElts    = kNBytes == 4 ? 4 : constexpr_min(8, kNItems);
    static constexpr int kNLoads   = kNItems / kNElts;
    static constexpr bool kIsEvenLen = kIsEvenLen_;
    static constexpr int kMinBlocks  = kNThreads < 128 ? 5 : 3;
    static constexpr int kChunkSize  = kNThreads * kNItems;

    using vec_t = typename BytesToType<kNBytes * kNElts>::Type;

#if defined(KLA_MOBIUS_CUB_STITCH)
    using MobiusBlockScanT = cub::BlockScan<float4, kNThreads, cub::BLOCK_SCAN_WARP_SCANS>;
#endif
    using BlockLoadT      = cub::BlockLoad<input_t, kNThreads, kNItems, cub::BLOCK_LOAD_WARP_TRANSPOSE>;
    using BlockStoreT     = cub::BlockStore<input_t, kNThreads, kNItems, cub::BLOCK_STORE_WARP_TRANSPOSE>;
    using LinearBlockScanT = cub::BlockScan<float2, kNThreads, cub::BLOCK_SCAN_WARP_SCANS>;

    static constexpr int kSmemIOSize = (int)custom_max({
        sizeof(typename BlockLoadT::TempStorage),
        sizeof(typename BlockStoreT::TempStorage)
    });
    static constexpr int kSmemScanSize = (int)custom_max({
#if defined(KLA_MOBIUS_CUB_STITCH)
        sizeof(typename MobiusBlockScanT::TempStorage),
#else
        (size_t)(kNThreads * sizeof(float4)),
#endif
        sizeof(typename LinearBlockScanT::TempStorage)
    });
    static constexpr int kSmemSizeRaw = kSmemIOSize + kSmemScanSize;
    static constexpr int kSmemSize = (kSmemSizeRaw + 15) & ~15;
};

// =============================================================================
// Forward kernel
// =============================================================================
template<typename Ktraits>
__global__ __launch_bounds__(Ktraits::kNThreads, Ktraits::kMinBlocks)
void kla_matmul_fwd_kernel(KLAMatmulParamsFwd params) {

    constexpr int  kNThreads  = Ktraits::kNThreads;
    constexpr int  kNItems    = Ktraits::kNItems;
    constexpr int  kChunkSize = Ktraits::kChunkSize;
    constexpr bool kIsEvenLen = Ktraits::kIsEvenLen;
    using input_t = typename Ktraits::input_t;

    extern __shared__ char smem_[];

    auto &smem_load  = reinterpret_cast<typename Ktraits::BlockLoadT::TempStorage &>(smem_);
    auto &smem_store = reinterpret_cast<typename Ktraits::BlockStoreT::TempStorage &>(smem_);

#if defined(KLA_MOBIUS_CUB_STITCH)
    auto &smem_mob_scan = *reinterpret_cast<typename Ktraits::MobiusBlockScanT::TempStorage *>(
        smem_ + Ktraits::kSmemIOSize);
#else
    float4 *smem_mob_scratch = reinterpret_cast<float4 *>(smem_ + Ktraits::kSmemIOSize);
#endif
    auto &smem_lin_scan = *reinterpret_cast<typename Ktraits::LinearBlockScanT::TempStorage *>(
        smem_ + Ktraits::kSmemIOSize);

    float4 *smem_mob_prefix   = reinterpret_cast<float4 *>(smem_ + Ktraits::kSmemSize);
    float2 *smem_lin_prefix   = reinterpret_cast<float2 *>(smem_mob_prefix + MAX_DSTATE);
    float  *smem_lambda_shift = reinterpret_cast<float *>(smem_lin_prefix + MAX_DSTATE);

    const int batch_id = blockIdx.x;
    const int m_id     = blockIdx.y;

    input_t *mu_sig = reinterpret_cast<input_t *>(params.mu_sigma_inv_ptr)
        + batch_id * params.mu_sigma_inv_batch_stride
        + m_id     * params.mu_sigma_inv_d_stride;
    input_t *sig_inv = reinterpret_cast<input_t *>(params.sigma_inv_ptr)
        + batch_id * params.sigma_inv_batch_stride
        + m_id     * params.sigma_inv_d_stride;
    input_t *za_in = reinterpret_cast<input_t *>(params.za_ptr)
        + batch_id * params.za_batch_stride
        + m_id     * params.za_d_stride;

    input_t *h_base = reinterpret_cast<input_t *>(params.h_ptr)
        + batch_id * params.h_batch_stride;
    input_t *w_base = reinterpret_cast<input_t *>(params.w_ptr)
        + batch_id * params.w_batch_stride;

    input_t *y_out = reinterpret_cast<input_t *>(params.y_ptr)
        + batch_id * params.y_batch_stride
        + m_id     * params.y_d_stride;
    input_t *yvar_out = reinterpret_cast<input_t *>(params.yvar_ptr)
        + batch_id * params.yvar_batch_stride
        + m_id     * params.yvar_d_stride;

    const float *a0_tab     = reinterpret_cast<const float *>(params.a0_ptr)     + m_id * params.d_state;
    const float *sigma2_tab = reinterpret_cast<const float *>(params.sigma2_ptr) + m_id * params.d_state;
    const float *delta_tab  = reinterpret_cast<const float *>(params.delta_ptr)  + m_id * params.d_state;

    for (int chunk = 0; chunk < params.n_chunks; ++chunk) {
        const int seqlen_remaining = params.seqlen - chunk * kChunkSize;

        // =================================================================
        // Model-axis inputs, shared across the state loop:
        //   mu_sig, sig_inv (as selective_v3) and the controllers za.
        // =================================================================
        input_t mu_sig_vals[kNItems], sig_inv_vals[kNItems], za_vals[kNItems];

        __syncthreads();
        load_input<Ktraits>(mu_sig + chunk * kChunkSize, mu_sig_vals, smem_load, seqlen_remaining);
        __syncthreads();
        load_input<Ktraits>(sig_inv + chunk * kChunkSize, sig_inv_vals, smem_load, seqlen_remaining);
        __syncthreads();
        load_input<Ktraits>(za_in + chunk * kChunkSize, za_vals, smem_load, seqlen_remaining);


        float mu_sig_f[kNItems], sig_inv_f[kNItems];
        // Normalized softplus clock gain, constant over state dimensions.
        // Padded positions load z = 0 -> G = 1; they are masked to identity below anyway.
        float Ga[kNItems];
        #pragma unroll
        for (int i = 0; i < kNItems; ++i) {
            mu_sig_f[i]  = float(mu_sig_vals[i]);
            sig_inv_f[i] = float(sig_inv_vals[i]);
            float dG_unused;
            fused_gain(params.clock_bias, float(za_vals[i]), Ga[i], dG_unused);
        }

        float y_accum[kNItems]    = {0};
        float yvar_accum[kNItems] = {0};

        __syncthreads();
        for (int state_idx = 0; state_idx < params.d_state; ++state_idx) {

            // --- Per-token dynamics for this (m, s), in registers ---
            //   u = delta a0 G_a (<= 0), abar = e^u, pbar = sigma2 (1 - abar^2)
            // The v3 leaf is a²-scaled, so an abar underflowing to 0 is exact.
            const float a0s  = a0_tab[state_idx];
            const float sig2 = sigma2_tab[state_idx];
            const float dlt  = delta_tab[state_idx];
            const float c0   = dlt * a0s;
            float a_s[kNItems], q_s[kNItems], a2[kNItems];
            #pragma unroll
            for (int i = 0; i < kNItems; ++i) {
                const float u    = c0 * Ga[i];
                const float abar = expf(u);
                const float w    = -expm1f(2.0f * u);
                a_s[i] = abar;
                q_s[i] = fmaxf(sig2 * w, params.p_min);
                a2[i]  = fmaxf(abar * abar, KLA_EPS);
            }

            const float lam0 = (params.lam0_ptr != nullptr)
                ? reinterpret_cast<const float *>(params.lam0_ptr)[m_id * params.d_state + state_idx]
                : 1.0f;

            // --- State-axis inputs h, w [B, S, L] ---
            input_t h_raw[kNItems], w_raw[kNItems];
            __syncthreads();
            load_input<Ktraits>(
                h_base + state_idx * params.h_dstate_stride + chunk * kChunkSize,
                h_raw, smem_load, seqlen_remaining);
            __syncthreads();
            load_input<Ktraits>(
                w_base + state_idx * params.w_dstate_stride + chunk * kChunkSize,
                w_raw, smem_load, seqlen_remaining);

            float h_f[kNItems], w_f[kNItems];
            #pragma unroll
            for (int i = 0; i < kNItems; ++i) {
                h_f[i] = float(h_raw[i]);
                w_f[i] = float(w_raw[i]);
            }

            // Stage 1: observation statistics
            float phi[kNItems], r[kNItems], raw_phi[kNItems];
            #pragma unroll
            for (int i = 0; i < kNItems; ++i) {
                compute_phi_r(h_f[i], sig_inv_f[i], mu_sig_f[i], phi[i], r[i], raw_phi[i]);
            }

            // Stage 2: Möbius scan (identical to selective_v3 from here on)
            float4 mob_data[kNItems];
            #pragma unroll
            for (int i = 0; i < kNItems; ++i) {
                mob_data[i] = build_leaf_matrix(phi[i], q_s[i], a2[i]);
                if constexpr (!kIsEvenLen) {
                    if (threadIdx.x * kNItems + i >= seqlen_remaining)
                        mob_data[i] = matmul_identity();
                }
            }

            float4 mob_carry;
            if (chunk > 0)
                mob_carry = smem_mob_prefix[state_idx];
            else
                mob_carry = matmul_identity();
            const float prev_chunk_lambda = extract_lambda_lin(mob_carry, lam0);

            {
                TraceNormMatMulOp op;
                float4 thread_agg = matmul_identity();
                #pragma unroll
                for (int i = 0; i < kNItems; ++i) {
                    thread_agg = op(thread_agg, mob_data[i]);
                    mob_data[i] = thread_agg;
                }

#if defined(KLA_MOBIUS_CUB_STITCH)
                MatmulPrefixCallbackOp mob_prefix_op(mob_carry);
                float4 my_prefix;
                __syncthreads();
                typename Ktraits::MobiusBlockScanT(smem_mob_scan).ExclusiveScan(
                    thread_agg, my_prefix, op, mob_prefix_op);
                if (threadIdx.x == 0)
                    smem_mob_prefix[state_idx] = mob_prefix_op.running_prefix;
                __syncthreads();
#else
                __syncthreads();
                smem_mob_scratch[threadIdx.x] = thread_agg;
                __syncthreads();
                if (threadIdx.x == 0) {
                    float4 carry = mob_carry;
                    for (int t = 0; t < kNThreads; ++t) {
                        float4 old_agg = smem_mob_scratch[t];
                        smem_mob_scratch[t] = carry;
                        carry = op(carry, old_agg);
                    }
                    smem_mob_prefix[state_idx] = carry;
                }
                __syncthreads();
                float4 my_prefix = smem_mob_scratch[threadIdx.x];
#endif
                #pragma unroll
                for (int i = 0; i < kNItems; ++i) {
                    mob_data[i] = op(my_prefix, mob_data[i]);
                }
            }

            float lambda_vals[kNItems];
            #pragma unroll
            for (int i = 0; i < kNItems; ++i) {
                lambda_vals[i] = extract_lambda_lin(mob_data[i], lam0);
            }

            if (threadIdx.x == kNThreads - 1) {
                float4 *mob_bnd = reinterpret_cast<float4 *>(params.mob_boundary_ptr);
                float  *lam_bnd = reinterpret_cast<float *>(params.lam_boundary_ptr);
                const int bnd_idx = ((batch_id * params.n_chunks + chunk)
                                     * params.d_model + m_id)
                                    * params.d_state + state_idx;
                mob_bnd[bnd_idx] = mob_data[kNItems - 1];
                lam_bnd[bnd_idx] = lambda_vals[kNItems - 1];
            }

            // Stage 3: linear scan for η
            float prev_lambda[kNItems];
            __syncthreads();
            smem_lambda_shift[threadIdx.x] = lambda_vals[kNItems - 1];
            __syncthreads();
            #pragma unroll
            for (int i = 0; i < kNItems; ++i) {
                if (i > 0) {
                    prev_lambda[i] = lambda_vals[i - 1];
                } else if (threadIdx.x > 0) {
                    prev_lambda[0] = smem_lambda_shift[threadIdx.x - 1];
                } else {
                    prev_lambda[0] = prev_chunk_lambda;
                }
            }

            float2 lin_data[kNItems];
            float  denom_vals[kNItems];
            #pragma unroll
            for (int i = 0; i < kNItems; ++i) {
                lin_data[i] = build_linear_input(
                    a_s[i], a2[i], q_s[i], prev_lambda[i], r[i], denom_vals[i]);
                if constexpr (!kIsEvenLen) {
                    if (threadIdx.x * kNItems + i >= seqlen_remaining)
                        lin_data[i] = linear_identity();
                }
            }

            float2 lin_running_prefix;
            if (chunk > 0 && threadIdx.x % 32 == 0)
                lin_running_prefix = smem_lin_prefix[state_idx];
            else
                lin_running_prefix = linear_identity();
            LinearPrefixCallbackOp lin_prefix_op(lin_running_prefix);

            __syncthreads();
            typename Ktraits::LinearBlockScanT(smem_lin_scan).InclusiveScan(
                lin_data, lin_data, LinearScanOp(), lin_prefix_op);

            if (threadIdx.x == 0) {
                smem_lin_prefix[state_idx] = lin_prefix_op.running_prefix;
            }

            if (threadIdx.x == kNThreads - 1) {
                float *lin_bnd = reinterpret_cast<float *>(params.lin_boundary_ptr);
                const int bnd_idx = ((batch_id * params.n_chunks + chunk)
                                     * params.d_model + m_id)
                                    * params.d_state + state_idx;
                lin_bnd[bnd_idx] = lin_data[kNItems - 1].y;
            }

            // Stage 4: posterior contraction
            #pragma unroll
            for (int i = 0; i < kNItems; ++i) {
                const float eta_i = lin_data[i].y;
                const float lam_i = lambda_vals[i];
                const float m_i   = eta_i / lam_i;
                y_accum[i]    += m_i * w_f[i];
                yvar_accum[i] += (1.0f / lam_i) * w_f[i] * w_f[i];
            }

        }  // end for state_idx

        input_t y_out_vals[kNItems], yvar_out_vals[kNItems];
        #pragma unroll
        for (int i = 0; i < kNItems; ++i) {
            y_out_vals[i]    = input_t(y_accum[i]);
            yvar_out_vals[i] = input_t(yvar_accum[i]);
        }

        __syncthreads();
        store_output<Ktraits>(y_out + chunk * kChunkSize, y_out_vals, smem_store, seqlen_remaining);
        __syncthreads();
        store_output<Ktraits>(yvar_out + chunk * kChunkSize, yvar_out_vals, smem_store, seqlen_remaining);

    }  // end for chunk
}

// =============================================================================
// Launch dispatch
// =============================================================================
template<int kNThreads, int kNItems, typename input_t>
void kla_matmul_fwd_launch(KLAMatmulParamsFwd &params, cudaStream_t stream) {
    BOOL_SWITCH(params.seqlen % (kNThreads * kNItems) == 0, kIsEvenLen, [&] {
        using Ktraits = KLA_Matmul_fwd_kernel_traits<kNThreads, kNItems, kIsEvenLen, input_t>;

        constexpr int kSmemSize = Ktraits::kSmemSize
            + MAX_DSTATE * sizeof(float4)
            + MAX_DSTATE * sizeof(float2)
            + Ktraits::kNThreads * sizeof(float);

        dim3 grid(params.batch, params.d_model);
        auto kernel = &kla_matmul_fwd_kernel<Ktraits>;

        if (kSmemSize >= 48 * 1024) {
            C10_CUDA_CHECK(cudaFuncSetAttribute(
                kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, kSmemSize));
        }
        kernel<<<grid, Ktraits::kNThreads, kSmemSize, stream>>>(params);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    });
}

template<typename input_t>
void kla_matmul_fwd_cuda(KLAMatmulParamsFwd &params, cudaStream_t stream) {
    if (params.seqlen <= 128) {
        kla_matmul_fwd_launch<32, 4, input_t>(params, stream);
    } else {
        kla_matmul_fwd_launch<64, 8, input_t>(params, stream);
    }
}
