/******************************************************************************
 * KLA Matmul Scan — Launch Wrappers + PyTorch Binding
 *   selective_fused/kla_matmul_scan.cu
 *
 * Fused time-varying version: the per-token dynamics are formed inside the
 * kernels from za [B,M,L] and a0, sigma2, delta [M,S]; no [B,M,S,L]
 * tensor crosses this interface in either direction.
 ******************************************************************************/

#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAException.h>
#include <c10/cuda/CUDAGuard.h>

#include "kla_matmul_scan.h"
#include "kla_matmul_fwd_kernel.cuh"
#include "kla_matmul_bwd_kernel.cuh"
#include "static_switch.h"

#define CHECK_SHAPE(x, ...) \
    TORCH_CHECK(x.sizes() == torch::IntArrayRef({__VA_ARGS__}), \
                #x " must have shape (" #__VA_ARGS__ ")")

namespace {

void check_tables(const at::Tensor &a0, const at::Tensor &sigma2, const at::Tensor &delta,
                  int d_model, int d_state, const at::Device &dev) {
    for (const auto &x : {a0, sigma2, delta}) {
        TORCH_CHECK(x.device() == dev && x.scalar_type() == at::kFloat && x.is_contiguous(),
                    "a0/sigma2/delta must be contiguous float32 tensors on the input device");
    }
    CHECK_SHAPE(a0, d_model, d_state);
    CHECK_SHAPE(sigma2, d_model, d_state);
    CHECK_SHAPE(delta, d_model, d_state);
}

void check_model_axis(const at::Tensor &x, int batch, int d_model, int seqlen, const at::Device &dev, const char *name) {
    TORCH_CHECK(x.device() == dev && x.scalar_type() == at::kFloat, name, " must be float32 on the input device");
    TORCH_CHECK(x.dim() == 3 && x.stride(-1) == 1, name, " must be [B, M, L] with unit time stride");
    CHECK_SHAPE(x, batch, d_model, seqlen);
}


}  // namespace

// =============================================================================
// forward
// =============================================================================
std::vector<at::Tensor> kla_matmul_fwd(
    const at::Tensor &mu_sigma_inv,   // (B, M, L)
    const at::Tensor &sigma_inv,      // (B, M, L)
    const at::Tensor &h,              // (B, S, L)
    const at::Tensor &w,              // (B, S, L)
    const at::Tensor &za,             // (B, M, L) controller for a
    const at::Tensor &a0,             // (M, S) continuous decay, < 0
    const at::Tensor &sigma2,         // (M, S) stationary variance
    const at::Tensor &delta,          // (M, S) step
    const at::Tensor &lam0,           // (M, S) prior precision, or empty for the unit prior
    double clock_bias, double p_min
) {
    TORCH_CHECK(mu_sigma_inv.is_cuda());
    TORCH_CHECK(mu_sigma_inv.dim() == 3 && sigma_inv.dim() == 3 && h.dim() == 3 && w.dim() == 3);
    TORCH_CHECK(mu_sigma_inv.stride(-1) == 1 && sigma_inv.stride(-1) == 1);
    TORCH_CHECK(h.stride(-1) == 1 && w.stride(-1) == 1);

    const int batch   = mu_sigma_inv.size(0);
    const int d_model = mu_sigma_inv.size(1);
    const int seqlen  = mu_sigma_inv.size(2);
    const int d_state = h.size(1);
    const auto dev = mu_sigma_inv.device();

    CHECK_SHAPE(mu_sigma_inv, batch, d_model, seqlen);
    CHECK_SHAPE(sigma_inv, batch, d_model, seqlen);
    CHECK_SHAPE(h, batch, d_state, seqlen);
    CHECK_SHAPE(w, batch, d_state, seqlen);
    TORCH_CHECK(d_state <= MAX_DSTATE, "d_state must be <= ", MAX_DSTATE);
    TORCH_CHECK(seqlen > 0 && d_model > 0 && batch > 0 && d_state > 0);
    for (const auto &x : {mu_sigma_inv, sigma_inv, h, w}) {
        TORCH_CHECK(x.device() == dev && x.scalar_type() == at::kFloat);
    }
    check_model_axis(za, batch, d_model, seqlen, dev, "za");
    check_tables(a0, sigma2, delta, d_model, d_state, dev);

    int kChunkSize;
    if (seqlen <= 128) kChunkSize = 32 * 4;
    else               kChunkSize = 64 * 8;
    const int n_chunks = (seqlen + kChunkSize - 1) / kChunkSize;

    auto opts     = mu_sigma_inv.options();
    auto opts_f32 = opts.dtype(torch::kFloat32);

    at::Tensor y    = torch::empty({batch, d_model, seqlen}, opts);
    at::Tensor yvar = torch::empty({batch, d_model, seqlen}, opts);
    at::Tensor mob_boundary = torch::empty({batch, n_chunks, d_model, d_state, 4}, opts_f32);
    at::Tensor lin_boundary = torch::empty({batch, n_chunks, d_model, d_state}, opts_f32);
    at::Tensor lam_boundary = torch::empty({batch, n_chunks, d_model, d_state}, opts_f32);

    KLAMatmulParamsFwd params;
    memset(&params, 0, sizeof(params));
    params.batch = batch; params.seqlen = seqlen; params.d_model = d_model;
    params.d_state = d_state; params.n_chunks = n_chunks;

    params.mu_sigma_inv_ptr          = mu_sigma_inv.data_ptr();
    params.mu_sigma_inv_batch_stride = mu_sigma_inv.stride(0);
    params.mu_sigma_inv_d_stride     = mu_sigma_inv.stride(1);
    params.sigma_inv_ptr          = sigma_inv.data_ptr();
    params.sigma_inv_batch_stride = sigma_inv.stride(0);
    params.sigma_inv_d_stride     = sigma_inv.stride(1);
    params.h_ptr = h.data_ptr(); params.h_batch_stride = h.stride(0); params.h_dstate_stride = h.stride(1);
    params.w_ptr = w.data_ptr(); params.w_batch_stride = w.stride(0); params.w_dstate_stride = w.stride(1);

    params.za_ptr = za.data_ptr(); params.za_batch_stride = za.stride(0); params.za_d_stride = za.stride(1);

    params.a0_ptr = a0.data_ptr(); params.sigma2_ptr = sigma2.data_ptr(); params.delta_ptr = delta.data_ptr();
    params.clock_bias = float(clock_bias); params.p_min = float(p_min);

    params.y_ptr = y.data_ptr(); params.y_batch_stride = y.stride(0); params.y_d_stride = y.stride(1);
    params.yvar_ptr = yvar.data_ptr(); params.yvar_batch_stride = yvar.stride(0); params.yvar_d_stride = yvar.stride(1);
    params.mob_boundary_ptr = mob_boundary.data_ptr();
    params.lin_boundary_ptr = lin_boundary.data_ptr();
    params.lam_boundary_ptr = lam_boundary.data_ptr();

    if (lam0.numel() > 0) {
        TORCH_CHECK(lam0.is_cuda() && lam0.scalar_type() == torch::kFloat32 && lam0.is_contiguous(),
                    "lam0 must be a contiguous float32 CUDA tensor");
        CHECK_SHAPE(lam0, d_model, d_state);
        params.lam0_ptr = lam0.data_ptr();
    }

    at::cuda::CUDAGuard device_guard{dev};
    auto stream = at::cuda::getCurrentCUDAStream().stream();
    kla_matmul_fwd_cuda<float>(params, stream);

    return {y, yvar, mob_boundary, lin_boundary, lam_boundary};
}

// =============================================================================
// backward
// =============================================================================
std::vector<at::Tensor> kla_matmul_bwd(
    const at::Tensor &dy, const at::Tensor &dyvar,
    const at::Tensor &mu_sigma_inv, const at::Tensor &sigma_inv,
    const at::Tensor &h, const at::Tensor &w,
    const at::Tensor &za,
    const at::Tensor &a0, const at::Tensor &sigma2, const at::Tensor &delta,
    const at::Tensor &mob_boundary, const at::Tensor &lin_boundary, const at::Tensor &lam_boundary,
    const at::Tensor &lam0,
    double clock_bias, double p_min
) {
    const int batch   = dy.size(0);
    const int d_model = dy.size(1);
    const int seqlen  = dy.size(2);
    const int d_state = h.size(1);
    const int n_chunks = mob_boundary.size(1);
    const auto dev = dy.device();
    check_model_axis(za, batch, d_model, seqlen, dev, "za");
    check_tables(a0, sigma2, delta, d_model, d_state, dev);

    auto opts     = dy.options();
    auto opts_f32 = opts.dtype(torch::kFloat32);

    at::Tensor dmu_sigma_inv = torch::empty({batch, d_model, seqlen}, opts);
    at::Tensor dsigma_inv    = torch::empty({batch, d_model, seqlen}, opts);
    at::Tensor dza = torch::empty({batch, d_model, seqlen}, opts);
    at::Tensor dh = torch::zeros({batch, d_state, seqlen}, opts_f32);
    at::Tensor dw = torch::zeros({batch, d_state, seqlen}, opts_f32);
    at::Tensor da0     = torch::zeros({d_model, d_state}, opts_f32);
    at::Tensor dsigma2 = torch::zeros({d_model, d_state}, opts_f32);
    at::Tensor ddelta  = torch::zeros({d_model, d_state}, opts_f32);

    KLAMatmulParamsBwd params;
    memset(&params, 0, sizeof(params));
    params.batch = batch; params.seqlen = seqlen; params.d_model = d_model;
    params.d_state = d_state; params.n_chunks = n_chunks;

    params.dy_ptr = dy.data_ptr(); params.dy_batch_stride = dy.stride(0); params.dy_d_stride = dy.stride(1);
    params.dyvar_ptr = dyvar.data_ptr(); params.dyvar_batch_stride = dyvar.stride(0); params.dyvar_d_stride = dyvar.stride(1);
    params.mu_sigma_inv_ptr          = mu_sigma_inv.data_ptr();
    params.mu_sigma_inv_batch_stride = mu_sigma_inv.stride(0);
    params.mu_sigma_inv_d_stride     = mu_sigma_inv.stride(1);
    params.sigma_inv_ptr          = sigma_inv.data_ptr();
    params.sigma_inv_batch_stride = sigma_inv.stride(0);
    params.sigma_inv_d_stride     = sigma_inv.stride(1);
    params.h_ptr = h.data_ptr(); params.h_batch_stride = h.stride(0); params.h_dstate_stride = h.stride(1);
    params.w_ptr = w.data_ptr(); params.w_batch_stride = w.stride(0); params.w_dstate_stride = w.stride(1);

    params.za_ptr = za.data_ptr(); params.za_batch_stride = za.stride(0); params.za_d_stride = za.stride(1);

    params.a0_ptr = a0.data_ptr(); params.sigma2_ptr = sigma2.data_ptr(); params.delta_ptr = delta.data_ptr();
    params.clock_bias = float(clock_bias); params.p_min = float(p_min);

    params.mob_boundary_ptr = mob_boundary.data_ptr();
    params.lin_boundary_ptr = lin_boundary.data_ptr();
    params.lam_boundary_ptr = lam_boundary.data_ptr();
    if (lam0.numel() > 0) {
        TORCH_CHECK(lam0.is_cuda() && lam0.scalar_type() == torch::kFloat32 && lam0.is_contiguous(),
                    "lam0 must be a contiguous float32 CUDA tensor");
        CHECK_SHAPE(lam0, d_model, d_state);
        params.lam0_ptr = lam0.data_ptr();
    }

    params.dmu_sigma_inv_ptr = dmu_sigma_inv.data_ptr();
    params.dmu_batch_stride  = dmu_sigma_inv.stride(0);
    params.dmu_d_stride      = dmu_sigma_inv.stride(1);
    params.dsigma_inv_ptr = dsigma_inv.data_ptr();
    params.dsig_batch_stride = dsigma_inv.stride(0);
    params.dsig_d_stride     = dsigma_inv.stride(1);
    params.dza_ptr = dza.data_ptr(); params.dza_batch_stride = dza.stride(0); params.dza_d_stride = dza.stride(1);
    params.dh_ptr = dh.data_ptr(); params.dh_batch_stride = dh.stride(0); params.dh_dstate_stride = dh.stride(1);
    params.dw_ptr = dw.data_ptr(); params.dw_batch_stride = dw.stride(0); params.dw_dstate_stride = dw.stride(1);
    params.da0_ptr = da0.data_ptr(); params.dsigma2_ptr = dsigma2.data_ptr(); params.ddelta_ptr = ddelta.data_ptr();

    at::cuda::CUDAGuard device_guard{dev};
    auto stream = at::cuda::getCurrentCUDAStream().stream();
    kla_matmul_bwd_cuda<float>(params, stream);

    return {dmu_sigma_inv, dsigma_inv, dh, dw, dza, da0, dsigma2, ddelta};
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("fwd", &kla_matmul_fwd, "KLA fused time-varying scan forward (CUDA)");
    m.def("bwd", &kla_matmul_bwd, "KLA fused time-varying scan backward (CUDA)");
}
