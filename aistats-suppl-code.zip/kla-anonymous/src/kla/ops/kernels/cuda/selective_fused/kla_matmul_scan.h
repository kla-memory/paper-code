// Fused Kalman-Bucy clock: u = delta * a0 * G(za), p = sigma2 * (1-exp(2u)).
#pragma once

#include <math.h>

#define MAX_DSTATE 64
#define KLA_EPS     1e-12f
#define KLA_LOG_EPS 1e-30f

__device__ __forceinline__ float kla_softplus(float x) { return x > 20.0f ? x : log1pf(expf(x)); }
__device__ __forceinline__ float kla_sigmoid(float x) { return 1.0f / (1.0f + expf(-x)); }

// Normalized softplus clock, with G(0) = G'(0) = 1.
__device__ __forceinline__ void fused_gain(float c, float z, float &G, float &dG) {
    const float sp_c = kla_softplus(c);
    const float alpha = sp_c * (1.0f + expf(-c));
    const float x = c + alpha * z;
    G = kla_softplus(x) / sp_c;
    dG = alpha * kla_sigmoid(x) / sp_c;
}

// =============================================================================
// Forward parameters
// =============================================================================
struct KLAMatmulParamsFwd {
    int batch;
    int seqlen;
    int d_model;
    int d_state;
    int n_chunks;

    // Inputs: model-axis [B, M, L]
    void *mu_sigma_inv_ptr;
    int mu_sigma_inv_batch_stride;
    int mu_sigma_inv_d_stride;

    void *sigma_inv_ptr;
    int sigma_inv_batch_stride;
    int sigma_inv_d_stride;

    // Inputs: state-axis [B, S, L]
    void *h_ptr;
    int h_batch_stride;
    int h_dstate_stride;

    void *w_ptr;
    int w_batch_stride;
    int w_dstate_stride;

    void *za_ptr;
    int za_batch_stride;
    int za_d_stride;


    // Static tables [M, S], contiguous float32
    void *a0_ptr;       // continuous decay a0 < 0
    void *sigma2_ptr;   // stationary variance
    void *delta_ptr;    // positive timestep

    float clock_bias;
    float p_min;        // pbar floor (the wrapper's P_MIN clamp)

    // Outputs: [B, M, L]
    void *y_ptr;
    int y_batch_stride;
    int y_d_stride;

    void *yvar_ptr;
    int yvar_batch_stride;
    int yvar_d_stride;

    // Boundary states (cross-chunk carries)
    void *mob_boundary_ptr;   // [B, n_chunks, M, S, 4]
    void *lin_boundary_ptr;   // [B, n_chunks, M, S]
    void *lam_boundary_ptr;   // [B, n_chunks, M, S]

    // Prior precision lambda_0 [M, S] (float32), or nullptr for the unit prior.
    void *lam0_ptr;
};

// =============================================================================
// Backward parameters
// =============================================================================
struct KLAMatmulParamsBwd {
    int batch;
    int seqlen;
    int d_model;
    int d_state;
    int n_chunks;

    // Upstream gradients: [B, M, L]
    void *dy_ptr;
    int dy_batch_stride;
    int dy_d_stride;

    void *dyvar_ptr;
    int dyvar_batch_stride;
    int dyvar_d_stride;

    // Saved inputs: model-axis [B, M, L]
    void *mu_sigma_inv_ptr;
    int mu_sigma_inv_batch_stride;
    int mu_sigma_inv_d_stride;

    void *sigma_inv_ptr;
    int sigma_inv_batch_stride;
    int sigma_inv_d_stride;

    // Saved inputs: state-axis [B, S, L]
    void *h_ptr;
    int h_batch_stride;
    int h_dstate_stride;

    void *w_ptr;
    int w_batch_stride;
    int w_dstate_stride;

    void *za_ptr;
    int za_batch_stride;
    int za_d_stride;


    // Static tables [M, S]
    void *a0_ptr;
    void *sigma2_ptr;
    void *delta_ptr;

    float clock_bias;
    float p_min;

    // Boundary states (from forward)
    void *mob_boundary_ptr;
    void *lin_boundary_ptr;
    void *lam_boundary_ptr;

    // Prior precision lambda_0 [M, S] (float32), or nullptr for the unit prior.
    void *lam0_ptr;

    // Output gradients: model-axis [B, M, L]
    void *dmu_sigma_inv_ptr;
    int dmu_batch_stride;
    int dmu_d_stride;

    void *dsigma_inv_ptr;
    int dsig_batch_stride;
    int dsig_d_stride;

    void *dza_ptr;
    int dza_batch_stride;
    int dza_d_stride;


    // Output gradients: state-axis [B, S, L] (atomicAdd over M)
    void *dh_ptr;
    int dh_batch_stride;
    int dh_dstate_stride;

    void *dw_ptr;
    int dw_batch_stride;
    int dw_dstate_stride;

    // Output gradients: static tables [M, S], contiguous, zero-initialised (atomicAdd over B)
    void *da0_ptr;
    void *dsigma2_ptr;
    void *ddelta_ptr;
};
