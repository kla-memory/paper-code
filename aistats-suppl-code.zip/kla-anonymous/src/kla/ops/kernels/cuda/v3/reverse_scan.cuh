/******************************************************************************
 * BlockReverseScan — Reverse (right-to-left) inclusive prefix scan
 *
 * Default 4-phase implementation (v3/v3_1):
 *   Phase 1: per-thread reverse sequential scan (registers)
 *   Phase 2: write per-thread aggregates to smem (reversed order)
 *   Phase 3: single-thread sequential scan over aggregates (thread 0)
 *   Phase 4: apply exclusive prefix to local results
 *
 * v3_2 (KLA_REVERSE_WARP_STITCH): retain the local fold/apply, but use
 * warp shuffles for the aggregate suffix scan. The 64-thread case exchanges
 * the right warp's total and thread 0's entering carry through shared memory.
 * Only thread 0's prefix_op.running_prefix is read/updated, as in v3.
 * Callers must synchronize before reusing TempStorage, as in the default path.
 *
 * scan_op convention: scan_op(older_aggregate, newer_input)
 *   In a reverse scan, the "newer" element is further LEFT (smaller index).
 *   The aggregate accumulated from the right is "older".
 *
 * This gives the correct reverse recurrence:
 *   η_total[l] = η_dir[l] + α[l+1] · η_total[l+1]
 *
 * where input[l] = (α[l+1], η_dir[l]) and LinearScanOp produces:
 *   (input.x * agg.x, input.x * agg.y + input.y)
 * = (α[l+1] * α_product, α[l+1] * η_accumulated + η_dir[l])  ✓
 ******************************************************************************/
#pragma once

#include <cuda_runtime.h>
#include <type_traits>

template<typename scan_t, int kNThreads>
struct BlockReverseScan {

    struct TempStorage {
        scan_t thread_aggregates[kNThreads];
    };

    TempStorage &temp_storage;

    __device__ BlockReverseScan(TempStorage &ts) : temp_storage(ts) {}

    template<int kNItems, typename ScanOp, typename PrefixOp>
    __device__ void InclusiveReverseScan(
        scan_t (&input)[kNItems],
        scan_t (&output)[kNItems],
        ScanOp scan_op,
        PrefixOp &prefix_op
    ) {
        const int tid = threadIdx.x;

        // Phase 1: per-thread reverse sequential scan
        scan_t local_aggregate = prefix_op.identity();

        #pragma unroll
        for (int i = kNItems - 1; i >= 0; --i) {
            local_aggregate = scan_op(local_aggregate, input[i]);
            output[i] = local_aggregate;
        }

#if defined(KLA_REVERSE_WARP_STITCH)
        static_assert(std::is_same<scan_t, float2>::value,
                      "The warp reverse stitch currently supports float2 only");
        static_assert(kNThreads == 32 || kNThreads == 64,
                      "The warp reverse stitch supports one or two full warps");
        constexpr unsigned mask = 0xffffffffu;
        const int lane = tid % 32;

        // Inclusive suffix of thread aggregates inside each warp. Pull from
        // the RIGHT: that aggregate is older in reverse-scan traversal order.
        scan_t aggregate = local_aggregate;
        #pragma unroll
        for (int offset = 1; offset < 32; offset <<= 1) {
            scan_t right = make_float2(
                __shfl_down_sync(mask, aggregate.x, offset),
                __shfl_down_sync(mask, aggregate.y, offset));
            if (lane + offset < 32)
                aggregate = scan_op(right, aggregate);
        }

        scan_t entering;
        if constexpr (kNThreads == 32) {
            // Preserve the original contract: other lanes need not have a
            // valid incoming prefix. All lanes participate in both shuffles.
            scan_t seed = tid == 0 ? prefix_op.running_prefix : prefix_op.identity();
            entering = make_float2(__shfl_sync(mask, seed.x, 0),
                                  __shfl_sync(mask, seed.y, 0));
        } else {
            if (tid == 32) temp_storage.thread_aggregates[0] = aggregate;
            if (tid == 0) temp_storage.thread_aggregates[1] = prefix_op.running_prefix;
            __syncthreads();
            entering = temp_storage.thread_aggregates[1];
            if (tid < 32)
                entering = scan_op(entering, temp_storage.thread_aggregates[0]);
        }

        // Shift the inclusive suffix once to exclude our own aggregate.
        scan_t right_prefix = make_float2(
            __shfl_down_sync(mask, aggregate.x, 1),
            __shfl_down_sync(mask, aggregate.y, 1));
        scan_t my_prefix = lane == 31 ? entering : scan_op(entering, right_prefix);
        if (tid == 0)
            prefix_op.running_prefix = scan_op(entering, aggregate);
#else
        // Phase 2: write per-thread aggregates in REVERSED order
        int reversed_tid = kNThreads - 1 - tid;
        temp_storage.thread_aggregates[reversed_tid] = local_aggregate;
        __syncthreads();

        // Phase 3: single-thread sequential scan (thread 0)
        // Aggregates are stored in reversed order:
        //   [0] = rightmost thread's aggregate (oldest)
        //   [kNThreads-1] = leftmost thread's aggregate (newest)
        if (tid == 0) {
            scan_t carry = prefix_op.running_prefix;

            for (int t = 0; t < kNThreads; ++t) {
                scan_t thread_agg = temp_storage.thread_aggregates[t];
                temp_storage.thread_aggregates[t] = carry;
                carry = scan_op(carry, thread_agg);
            }

            prefix_op.running_prefix = carry;
        }
        __syncthreads();

        // Phase 4: apply exclusive prefix to local results
        scan_t my_prefix = temp_storage.thread_aggregates[reversed_tid];
#endif

        #pragma unroll
        for (int i = 0; i < kNItems; ++i) {
            output[i] = scan_op(my_prefix, output[i]);
        }
    }
};
