"""CUDA sources for the static and fused Kalman–Bucy scans.

Built lazily via torch.utils.cpp_extension by kla.ops.cuda_backend. Importing
kla does not require a CUDA device or compiler; the PyTorch path runs on CPU.
"""
