# Models and initialization

Both models are built through the same entry point:

```python
from kla import KLAConfig, build_mixer

static = build_mixer(64, KLAConfig.exact(d_state=32, backend="torch"))
clock  = build_mixer(64, KLAConfig.kalman_bucy(d_state=32, backend="torch"))
```

`KLAConfig()` is `KLAConfig.exact()`. You can also construct `KLALayer` and
`KLASelectiveLayer` (the Kalman–Bucy layer) directly; `selective=True` in the
config picks the latter through `build_mixer`.

Both models use OU dynamics with unit initial decay magnitude, a learned
stationary variance `sigma2`, exact process-noise initialization, and a
reference posterior precision that matches it. In the Kalman–Bucy model the
clock starts at unit gain and scales both the timestep and the observation
information; `sigma2` stays a plain learned parameter.

## Timesteps

By default every `(inner channel, state)` cell gets its own timestep, drawn
log-uniformly from `[1e-4, 0.1]`, with kappa fixed at one. `dt_init_floor`
must not exceed `dt_min`.

## Horizons

If you would rather prescribe memory horizons, either model accepts:

```python
config = KLAConfig.kalman_bucy(
    dt_init_mode="halflife",
    halflife_min=4.0, halflife_max=4096.0,
    process_noise_kappa_min=0.05, process_noise_kappa_max=0.3,
)
```

Horizon `H` and kappa are drawn independently per cell, each log-uniform; equal
endpoints give a constant. This mode ignores the timestep range and floor and
requires `dt_init_per_cell=True`.

With `u = |a| * Delta` and `phi0` the reference sensor information:

```text
u       = log(2) / ((1 + kappa) * H)
p_bar   = (1 - exp(-kappa*u)) * (exp(kappa*u) - exp(-2*u)) / phi0
lambda0 = phi0 / (1 - exp(-kappa*u))
sigma2  = p_bar / (1 - exp(-2*u))
```

The same kappa draw sets the timestep, the process noise and the reference
precision. With normalized keys and automatic observation-noise calibration,
`phi0 = 1`. Kappa below one means a token overwrites less relative to passive
decay. These are targets for the reference model at initialization; trained
horizons will drift.

The reference precision is stored in checkpoints and used as the prior for
fresh sequences. The variance floor defaults to zero. A nonzero floor, ceiling
or noise-calibration multiplier is rejected because it would move the fixed
point the formulas above are built around.

Options that are not part of this release (other process-noise
initializations and parameterizations, HiPPO decay init, other selective modes)
raise on construction.
