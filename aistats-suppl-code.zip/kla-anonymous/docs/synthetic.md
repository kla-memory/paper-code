# Synthetic topic recall

A small, self-contained experiment: one KLA layer has to remember which latent
topic was active `lag` steps ago. Data is generated on the fly, so there is
nothing to download. Run everything from the checkout root.

## Quick check on CPU

```bash
uv run python -m examples.synthetic.run --profile smoke --output results/topic-smoke
uv run python -m examples.synthetic.run --profile smoke --model kalman_bucy --output results/topic-clock-smoke
```

The smoke profile uses lag 8, width 8, state size 4, batch size 4, 20 steps and
8 validation/test examples. It checks that everything runs; it says nothing
about performance. Each run wants a fresh output directory and refuses to
overwrite one. Add `--device cuda` for GPU.

## Task

There are eight topics with four tokens each (vocabulary 32). At every step the
topic switches to a different one with probability `4 / lag`. Each token is
drawn from the current topic's block, or, with probability 0.5, uniformly from
the whole vocabulary. At time `t >= lag` the target is the topic that was active
at `t - lag`; positions before `lag` are masked out. Training minimizes
cross-entropy and we report error rate (lower is better). Chance is 0.875.
The `current_topic_oracle` number in the results is the error you would get by
answering with the true current topic. It is a diagnostic, not a model.

Every example is a deterministic function of (task spec, split, seed, index),
and train, validation and test use separate random streams. Training draws
fresh examples at every step; validation and test sets are fixed.

## Model and options

Embedding, a constant feature channel, one KLA mixer (no multiplicative gating),
and a linear readout.

| Argument | Meaning |
| --- | --- |
| `--model` | `exact` or `kalman_bucy` |
| `--init` | `loguniform` timesteps or `halflife` horizons |
| `--dt-min`, `--dt-max` | Timestep range, default `[0.001, 0.1]` |
| `--horizon-min`, `--horizon-max` | Horizon range, default `[8, 8192]` |
| `--kappa-min`, `--kappa-max` | Default `1, 1`; a range is sampled log-uniformly per cell |
| `--arm` | `trainable`, or `frozen` (exact KLA only) |

The frozen arm fixes the dynamics (`delta`, `lambda_log`, `sigma2_log`) and the
observation-noise head, so the memory keeps its initialization while the
embedding, keys, queries, values, convolution and readout train. It is a way to
ask how much the initialization alone buys you.

## Paper settings

`--profile paper` sets the following (any of them can be overridden):

| Setting | Value |
| --- | --- |
| Width / expansion / state size | 64 / 2 / 32 |
| Sequence length | `min(4 * lag, 16384)` |
| Optimizer | Adam, lr 0.001, no weight decay |
| Batch size / max steps | 16 / 6000 |
| Gradient clipping | global norm 1.0 |
| Validation | every 100 steps, 64 examples |
| Early stopping | 10 evaluations without improvement |
| Test | 128 examples, at the best validation checkpoint |
| Lags | 256, 1024, 4096, 8192 |
| Seeds | 42, 43, 44 |

For example, one long-lag frozen run with horizon initialization:

```bash
uv run python -m examples.synthetic.run --profile paper \
  --model exact --init halflife --arm frozen --lag 8192 --seed 42 \
  --device cuda --output results/topic-horizon-frozen-l8192-s42
```

Sweep lags and seeds, and compare `--init loguniform` against `--init halflife`
for both arms. For the timestep sweep use `--dt-min` of 0.01, 0.001, 0.0001 or
0.00001; the init floor follows automatically. For constant kappa, set both
endpoints to the same value (0.1, 0.5, 1, 3).

## Outputs

Each run writes:

- `config.json`: the resolved run, mixer and data settings
- `history.jsonl`: step, training loss and validation error at each evaluation
- `model_best.pt`: state dict at the best validation step
- `result.json`: test metrics, chosen step, parameter count, frozen parameter
  names, data fingerprints, and the dynamics summary at init, best and end

Step zero is evaluated too, so it can be selected if training never improves.
Test data is never used for checkpoint selection.

To aggregate runs:

```bash
uv run python -m examples.synthetic.summarize results --output results-summary
# with learning-curve plots (needs matplotlib):
uv sync --extra plot
uv run python -m examples.synthetic.summarize results --output results-plots --plot
```

This writes `summary.csv` (test mean and standard deviation over seeds, per
configuration) and `groups.json` (the full settings behind each short group id).
Runs are grouped only when every setting except the seed matches, and a
duplicate seed is an error. Plots show one figure per lag, with individual
seeds as thin lines and the mean across seeds as a thick line.

## Tests

```bash
uv run pytest -q tests/test_synthetic.py
```
