# Scan backends

Every layer takes a `backend` argument.

| Backend | What it is |
| --- | --- |
| `torch` | Pure PyTorch. Runs on CPU or GPU, any `d_state`, float64 if you want it, and gradients flow through a carried filter state. |
| `cuda`, `cuda_static` | Fused CUDA scan for exact-init KLA. |
| `cuda_selective`, `cuda_clock` | Fused CUDA scan for Kalman–Bucy KLA. The per-token dynamics are formed inside the kernel, so the `[B,L,M,S]` dynamics tensor is never materialized. |
| `cuda_static_fast`, `cuda_clock_fast` | Alternative JIT builds of the same two kernels, without the coalesced backward atomics. Use them only if the default build gives you trouble; they have to be selected explicitly. |
| `auto` (default) | CUDA when the input is supported, PyTorch otherwise. |

Limits of the CUDA kernels: `d_state <= 64`, float32 arithmetic internally, and
the final filter state is returned detached. `auto` falls back to PyTorch for
carried filter states, float64 inputs, `d_state > 64`, and
`decode_from_prior=True`; the explicit CUDA backends raise instead. Single-token
steps always use the PyTorch recurrence. A static CUDA backend cannot run the
Kalman–Bucy layer.

Table gradients (`a0`, `sigma2`, `Delta`) are accumulated across tokens and
batch with atomics, so the last few bits can differ between runs.

## What the Kalman–Bucy kernel computes

The kernel gets the clock logits `z[B,L,M]` and the learned tables `a0[M,S]`,
`sigma2[M,S]`, `Delta[M,S]`. With clock bias `c`:

```text
alpha = softplus(c) / sigmoid(c)
G(z)  = softplus(c + alpha*z) / softplus(c)
u     = Delta * a0 * G(z)
a_bar = exp(u)
p_bar = sigma2 * (-expm1(2*u))
```

The layer scales the observation precision by the same gain `G(z)`. Since
`G(0) = G'(0) = 1`, a zero-initialized clock head gives back the exact-init
model exactly. There is one clock projection and nothing else: no separate
process-noise controller.

## Tests

`tests/test_backends.py` compares the static kernel's forward and backward with
the sequential PyTorch reference, including edge cases.
`tests/test_selective_release.py` and `tests/test_clock_release.py` do the same
for the clock kernel: outputs, variances, parameter gradients, final states,
chunk boundaries, and recurrent continuation. They skip without a GPU, so a
green CPU run says nothing about the kernels.
