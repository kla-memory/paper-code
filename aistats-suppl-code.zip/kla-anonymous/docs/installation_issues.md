# Installation troubleshooting

Start with:

```bash
uv sync --python 3.11
uv run python -m kla
```

The second command prints which backends are available and runs one small
forward pass. On a GPU it also triggers the static CUDA build, so most install
problems show up here rather than in a training run.

## Make sure you are importing this checkout

```bash
uv run python -c "import kla, torch; print(kla.__file__); print(torch.__version__, torch.version.cuda, torch.cuda.is_available())"
```

If the path points somewhere else, you have an older install in another
environment. Running through `uv run` from this directory avoids that.

## CPU only

`backend="torch"` needs no compiler. To exercise both models on CPU:

```bash
uv run python examples/smoke.py --device cpu
```

## CUDA

You need a PyTorch build that matches your driver, and a CUDA toolkit that
matches that PyTorch build. The toolkit must include `nvcc`; a driver alone is
not enough. The extension also needs ninja, a host C++ compiler the toolkit
accepts, and the Python development headers.

```bash
nvcc --version
uv run ninja --version
uv run python -c "import torch; print(torch.version.cuda)"
```

If the toolkit is not on the default search path, set `CUDA_HOME` before
starting Python (`KLA_CUDA_HOME` works too when `CUDA_HOME` is unset). The build
uses C++17, or C++20 with PyTorch >= 2.13.

To compile both kernels and run forward and backward with the compiler output
visible:

```bash
KLA_JIT_VERBOSE=1 uv run python examples/smoke.py --device cuda
```

| Symptom | Check |
| --- | --- |
| CUDA not available | GPU visible to the process, driver, and whether the installed PyTorch has CUDA |
| `nvcc` or CUDA headers missing | Toolkit install and `CUDA_HOME` |
| ninja missing | `uv sync` with the default dev group |
| Host compiler or C++ standard error | Compiler compatibility with the toolkit and the PyTorch headers |
| `Python.h` missing | Development headers for the interpreter in this environment |
| Unsupported state size or configuration | Limits in [backends.md](backends.md) |

A failed build raises; the package never silently switches kernels. If you want
the PyTorch path, ask for it with `backend="torch"`.
